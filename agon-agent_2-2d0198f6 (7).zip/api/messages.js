import { supabase, route, HttpError, requireAuth, rateLimit, body, int, signalUser, thumbOf, enc, dec, listingImages, safeListingImage, safeAvatar } from './_lib.js';

// Mesaj içerikleri veritabanında şifreli saklanır; yalnızca sohbetin taraflarına sunucu üzerinden çözülerek gösterilir.

const cleanText = (v) => {
  const t = String(v || '').replace(/\r/g, '').trim();
  if (t.length < 1) throw new HttpError(400, 'Mesaj boş olamaz.', 'body');
  if (t.length > 2000) throw new HttpError(400, 'Mesaj en fazla 2000 karakter olabilir.', 'body');
  return t;
};

const isUuid = (v) => /^[0-9a-f-]{36}$/i.test(String(v || ''));

async function loadConversation(id, uid) {
  if (!isUuid(id)) throw new HttpError(400, 'Geçersiz sohbet.');
  const r = await supabase.from('conversations').select('*').eq('id', id).maybeSingle();
  if (r.error) throw r.error;
  // Yalnızca sohbetin iki tarafı erişebilir.
  if (!r.data || (r.data.buyer_id !== uid && r.data.seller_id !== uid)) throw new HttpError(404, 'Sohbet bulunamadı.', 'NOT_FOUND');
  return r.data;
}

async function addMessage(conv, senderId, text) {
  await rateLimit(`msg:${senderId}`, 30, 60, 'Çok hızlı mesaj gönderiyorsunuz. Lütfen biraz bekleyin.');
  const isBuyer = conv.buyer_id === senderId;
  const recipientId = isBuyer ? conv.seller_id : conv.buyer_id;
  const rp = await supabase.from('profiles').select('rt_key,is_blocked').eq('id', recipientId).maybeSingle();
  if (rp.error) throw rp.error;
  if (!rp.data) throw new HttpError(410, 'Karşı tarafın hesabı artık mevcut değil.');
  const ins = await supabase.from('messages').insert({ conversation_id: conv.id, sender_id: senderId, body: enc(text) }).select('id,conversation_id,sender_id,created_at').single();
  if (ins.error) throw ins.error;
  ins.data.body = text;
  const field = isBuyer ? 'seller_unread' : 'buyer_unread';
  const up = await supabase.from('conversations').update({
    last_message: enc(text.slice(0, 140)),
    last_message_at: ins.data.created_at,
    last_sender_id: senderId,
    [field]: (conv[field] || 0) + 1,
  }).eq('id', conv.id);
  if (up.error) throw up.error;
  await signalUser(rp.data.rt_key, { conversation_id: conv.id, message_id: ins.data.id });
  return ins.data;
}

async function list(req, res, auth) {
  const uid = auth.user.id;
  const r = await supabase.from('conversations').select('*').or(`buyer_id.eq.${uid},seller_id.eq.${uid}`)
    .order('last_message_at', { ascending: false, nullsFirst: false }).limit(200);
  if (r.error) throw r.error;
  const otherIds = [...new Set(r.data.map((c) => (c.buyer_id === uid ? c.seller_id : c.buyer_id)))];
  const people = otherIds.length
    ? await supabase.from('profiles').select('id,full_name,avatar_url').in('id', otherIds)
    : { data: [], error: null };
  if (people.error) throw people.error;
  const byId = new Map(people.data.map((p) => [p.id, p]));
  return res.status(200).json({
    items: r.data.map((c) => {
      const otherId = c.buyer_id === uid ? c.seller_id : c.buyer_id;
      const o = byId.get(otherId);
      return {
        id: c.id,
        listing_id: c.listing_id,
        listing_title: c.listing_title,
        listing_image: safeListingImage(c.listing_image),
        other: { id: otherId, full_name: o?.full_name || 'PAZARLA üyesi', avatar_url: safeAvatar(o?.avatar_url) },
        last_message: dec(c.last_message),
        last_message_at: c.last_message_at,
        last_from_me: c.last_sender_id === uid,
        unread: c.buyer_id === uid ? c.buyer_unread || 0 : c.seller_unread || 0,
        role: c.buyer_id === uid ? 'buyer' : 'seller',
      };
    }),
  });
}

async function thread(req, res, auth) {
  const uid = auth.user.id;
  const conv = await loadConversation(req.query.id, uid);
  const after = int(req.query.after);
  let q = supabase.from('messages').select('id,sender_id,body,created_at').eq('conversation_id', conv.id);
  if (after) q = q.gt('id', after).order('id', { ascending: true }).limit(200);
  else q = q.order('id', { ascending: false }).limit(200);
  const m = await q;
  if (m.error) throw m.error;
  const messages = (after ? m.data : m.data.reverse()).map((x) => ({ ...x, body: dec(x.body) })).filter((x) => x.body); // sunucunun şifrelemediği (sahte) mesajlar gösterilmez
  const mine = conv.buyer_id === uid ? 'buyer_unread' : 'seller_unread';
  if ((conv[mine] || 0) > 0) {
    const u = await supabase.from('conversations').update({ [mine]: 0 }).eq('id', conv.id);
    if (u.error) throw u.error;
  }
  if (after) return res.status(200).json({ messages });
  const otherId = conv.buyer_id === uid ? conv.seller_id : conv.buyer_id;
  const [o, l] = await Promise.all([
    supabase.from('profiles').select('id,full_name,avatar_url').eq('id', otherId).maybeSingle(),
    conv.listing_id
      ? supabase.from('listings').select('id,title,price,currency,status,images').eq('id', conv.listing_id).maybeSingle()
      : Promise.resolve({ data: null, error: null }),
  ]);
  if (o.error) throw o.error;
  if (l.error) throw l.error;
  return res.status(200).json({
    conversation: {
      id: conv.id,
      listing_id: conv.listing_id,
      listing_title: l.data?.title || conv.listing_title,
      listing_image: l.data ? thumbOf(listingImages(l.data.images)[0]) : safeListingImage(conv.listing_image),
      listing_price: l.data ? Number(l.data.price) : null,
      listing_currency: l.data?.currency || null,
      listing_active: l.data?.status === 'active',
      other: { id: otherId, full_name: o.data?.full_name || 'PAZARLA üyesi', avatar_url: safeAvatar(o.data?.avatar_url), exists: !!o.data },
      role: conv.buyer_id === uid ? 'buyer' : 'seller',
    },
    messages,
  });
}

async function start(req, res, auth) {
  const uid = auth.user.id;
  const b = body(req);
  const listingId = int(b.listing_id);
  const text = cleanText(b.body);
  const l = await supabase.from('listings').select('id,user_id,title,images,status').eq('id', listingId).maybeSingle();
  if (l.error) throw l.error;
  if (!l.data || l.data.status !== 'active') throw new HttpError(404, 'İlan yayında değil.', 'NOT_FOUND');
  if (l.data.user_id === uid) throw new HttpError(400, 'Kendi ilanınıza mesaj gönderemezsiniz.');
  const ex = await supabase.from('conversations').select('*').eq('listing_id', listingId).eq('buyer_id', uid).limit(1);
  if (ex.error) throw ex.error;
  let conv = ex.data[0];
  if (!conv) {
    await rateLimit(`conv:${uid}`, 20, 3600, 'Kısa sürede çok fazla yeni sohbet başlattınız. Lütfen daha sonra tekrar deneyin.');
    const ins = await supabase.from('conversations').insert({
      listing_id: listingId,
      listing_title: l.data.title,
      listing_image: thumbOf(listingImages(l.data.images)[0]),
      buyer_id: uid,
      seller_id: l.data.user_id,
      buyer_unread: 0,
      seller_unread: 0,
    }).select('*').single();
    if (ins.error) throw ins.error;
    conv = ins.data;
  }
  const message = await addMessage(conv, uid, text);
  return res.status(201).json({ conversation_id: conv.id, message });
}

async function send(req, res, auth) {
  const b = body(req);
  const text = cleanText(b.body);
  const conv = await loadConversation(b.conversation_id, auth.user.id);
  const message = await addMessage(conv, auth.user.id, text);
  return res.status(201).json({ message });
}

async function unread(req, res, auth) {
  const uid = auth.user.id;
  const r = await supabase.from('conversations').select('buyer_id,buyer_unread,seller_unread').or(`buyer_id.eq.${uid},seller_id.eq.${uid}`);
  if (r.error) throw r.error;
  return res.status(200).json({ unread: r.data.reduce((n, c) => n + (c.buyer_id === uid ? c.buyer_unread || 0 : c.seller_unread || 0), 0) });
}

export default route(async (req, res) => {
  const action = String(req.query.action || '');
  const k = `${req.method} ${action}`;
  const readOnly = req.method === 'GET';
  const auth = await requireAuth(req, { allowBlocked: readOnly });
  if (k === 'GET conversations') return list(req, res, auth);
  if (k === 'GET thread') return thread(req, res, auth);
  if (k === 'GET unread') return unread(req, res, auth);
  if (k === 'POST start') return start(req, res, auth);
  if (k === 'POST send') return send(req, res, auth);
  throw new HttpError(400, 'Geçersiz istek.');
});
