import {
  supabase, route, HttpError, requireAdmin, getSettings, getPaytr, setSecret, deleteSecret, body, int,
  toCard, deleteListingRows, AD_PLACEMENTS, originOf, publicPrefix, BUCKETS, isAdmin, enc, dec, SUPABASE_URL, settingRow, bannersDigest, safeAvatar, safeEqual, notify, ANDROID_PACKAGE, ANDROID_UPLOAD_FINGERPRINT, FINGERPRINT_RE, rlsSelfCheck,
} from './_lib.js';
import { categoryMismatch } from './_category-hints.js';
import { SOURCE_ZIP, ANDROID_ZIP, ANDROID_INFO, ANDROID_FILES } from './_source-link.js';
import { ANDROID_KEY_PASSWORD } from './_android-key.js';
import { LOCKDOWN_SQL, TABLES_SQL, SEED_SQL } from './_setup-sql.js';

// E-posta adresleri profil tablosunda tutulmaz; yalnızca yönetici ekranları için kimlik servisinden okunur.
async function emailMap() {
  const map = new Map();
  for (let page = 1; page <= 10; page++) {
    const r = await supabase.auth.admin.listUsers({ page, perPage: 1000 });
    if (r.error) throw r.error;
    for (const u of r.data.users) map.set(u.id, u.email || '');
    if (r.data.users.length < 1000) break;
  }
  return map;
}

// Sunucunun anahtarı gerçekten yetkili (service role) anahtar mı? Kimlik yönetimi uçları yalnızca o anahtarla çalışır.
async function serverKeyCheck() {
  try {
    const r = await supabase.auth.admin.listUsers({ page: 1, perPage: 1 });
    return !r.error;
  } catch {
    return false;
  }
}

// Güvenlik kodu, bu veritabanında bulunan ek (yalnızca denetim için açılmış) tabloları da kapsayacak şekilde verilir.
// Tablo yoksa satır eklenmez; ekleme yapılamazsa kod olduğu gibi verilir.
const EXTRA_TABLES = ['pz_diag', 'pz_rls_probe'];
const MARKER = '\n\n-- Sonuç\n';
async function lockdownSql() {
  if (LOCKDOWN_SQL.split(MARKER).length !== 2) return LOCKDOWN_SQL;
  const lines = [];
  for (const t of EXTRA_TABLES) {
    try {
      const r = await supabase.from(t).select('id').limit(1);
      if (!r.error) lines.push(`create policy dis_erisim_kapali on public.${t} as restrictive for all to anon, authenticated using (false) with check (false);`);
    } catch { /* tablo yok ya da okunamadı: satır eklenmez */ }
  }
  return lines.length ? LOCKDOWN_SQL.replace(MARKER, `\n${lines.join('\n')}${MARKER}`) : LOCKDOWN_SQL;
}

const cnt = async (q) => {
  const r = await q;
  if (r.error) throw r.error;
  return r.count || 0;
};
const lc = () => supabase.from('listings').select('id', { count: 'exact', head: true });
const pc = () => supabase.from('profiles').select('id', { count: 'exact', head: true });
const cleanQ = (v) => String(v || '').replace(/[^\p{L}\p{N}@._\- ]/gu, '').trim().slice(0, 60);

async function stats(req, res) {
  const today = new Date(); today.setUTCHours(0, 0, 0, 0);
  const since = new Date(Date.now() - 13 * 864e5); since.setUTCHours(0, 0, 0, 0);
  const monthStart = new Date(); monthStart.setUTCDate(1); monthStart.setUTCHours(0, 0, 0, 0);
  const [users, usersToday, blocked, suspicious, lTotal, lActive, lPending, lPayment, lRejected, lReview, lPassive, openReports, paid, recentL, recentU, convs, paytr, settings] = await Promise.all([
    cnt(pc()), cnt(pc().gte('created_at', today.toISOString())), cnt(pc().eq('is_blocked', true)), cnt(pc().eq('is_suspicious', true)),
    cnt(lc()), cnt(lc().eq('status', 'active')), cnt(lc().eq('status', 'pending')), cnt(lc().eq('status', 'pending_payment')),
    cnt(lc().eq('status', 'rejected')), cnt(lc().in('status', ['under_review', 'suspended'])), cnt(lc().eq('status', 'passive')),
    cnt(supabase.from('reports').select('id', { count: 'exact', head: true }).eq('status', 'open')),
    supabase.from('payments').select('amount,paid_at,test_mode,type').eq('status', 'paid').limit(10000),
    supabase.from('listings').select('created_at').gte('created_at', since.toISOString()).limit(10000),
    supabase.from('profiles').select('created_at').gte('created_at', since.toISOString()).limit(10000),
    cnt(supabase.from('conversations').select('id', { count: 'exact', head: true })),
    getPaytr(),
    getSettings(),
  ]);
  const rls = await rlsSelfCheck();
  for (const r of [paid, recentL, recentU]) if (r.error) throw r.error;
  // Gelir yalnızca PayTR tarafından doğrulanmış gerçek (test modu olmayan) ödemelerden hesaplanır.
  const real = paid.data.filter((p) => !p.test_mode);
  const revenue = real.reduce((n, p) => n + Number(p.amount), 0);
  const revenueMonth = real.filter((p) => p.paid_at && new Date(p.paid_at) >= monthStart).reduce((n, p) => n + Number(p.amount), 0);
  const days = [];
  for (let i = 0; i < 14; i++) {
    const d = new Date(since.getTime() + i * 864e5).toISOString().slice(0, 10);
    days.push({
      day: d,
      listings: recentL.data.filter((x) => x.created_at.slice(0, 10) === d).length,
      users: recentU.data.filter((x) => x.created_at.slice(0, 10) === d).length,
    });
  }
  await supabase.from('rate_limits').delete().lt('reset_at', new Date(Date.now() - 864e5).toISOString());
  await supabase.from('notifications').delete().lt('created_at', new Date(Date.now() - 90 * 864e5).toISOString());
  return res.status(200).json({
    users: { total: users, today: usersToday, blocked, suspicious },
    listings: { total: lTotal, active: lActive, pending: lPending, pending_payment: lPayment, rejected: lRejected, under_review: lReview, passive: lPassive },
    reports: { open: openReports },
    payments: { paid_count: real.length, test_count: paid.data.length - real.length, revenue, revenue_month: revenueMonth },
    conversations: convs,
    days,
    integrations: {
      paytr: !!paytr,
      paytr_test_mode: !!paytr?.test_mode,
      adsense: !!(settings.ads?.enabled && settings.ads?.client),
      moderation: !!settings.moderation_enabled,
      rls,
    },
  });
}

async function listListings(req, res) {
  const status = String(req.query.status || 'pending');
  const page = Math.max(1, int(req.query.page, 1));
  const per = 30;
  let q = supabase.from('listings').select('*', { count: 'exact' });
  if (status === 'flagged') q = q.neq('flags', '[]').in('status', ['pending', 'active', 'under_review']);
  else if (status === 'featured') q = q.or(`featured_until.gt."${new Date().toISOString()}",showcase_until.gt."${new Date().toISOString()}"`);
  else if (status === 'under_review') q = q.in('status', ['under_review', 'suspended']);
  else if (status !== 'all') q = q.eq('status', status);
  const term = cleanQ(req.query.q);
  if (term) {
    if (/^\d+$/.test(term)) q = q.eq('id', Number(term));
    else q = q.ilike('title', `%${term}%`);
  }
  let r;
  if (status === 'miscat') {
    // Başlığı bulunduğu kategoriye uymayan ilanlar: tüm ilanlar taranır, sonuç bellekte sayfalanır.
    const all = await supabase.from('listings').select('*').order('created_at', { ascending: false }).limit(3000);
    if (all.error) throw all.error;
    const low = term.toLowerCase();
    const hits = all.data.filter((l) => categoryMismatch(l.title, l.category_id) && (!term || String(l.id) === term || String(l.title).toLowerCase().includes(low)));
    r = { data: hits.slice((page - 1) * per, page * per), count: hits.length };
  } else {
    r = await q.order('created_at', { ascending: false }).range((page - 1) * per, page * per - 1);
    if (r.error) {
      if (r.error.code === 'PGRST103') return res.status(200).json({ items: [], total: 0, page, per });
      throw r.error;
    }
  }
  const uids = [...new Set(r.data.map((l) => l.user_id))];
  const people = uids.length ? await supabase.from('profiles').select('id,full_name,is_suspicious,is_blocked').in('id', uids) : { data: [], error: null };
  if (people.error) throw people.error;
  const emails = uids.length ? await emailMap() : new Map();
  const byId = new Map(people.data.map((p) => [p.id, { ...p, email: emails.get(p.id) || '' }]));
  return res.status(200).json({
    items: r.data.map((l) => ({
      ...toCard(l),
      description: String(l.description || '').slice(0, 400),
      created_at: l.created_at,
      flags: Array.isArray(l.flags) ? l.flags : [],
      suggested_category_id: categoryMismatch(l.title, l.category_id),
      reject_reason: l.reject_reason,
      report_count: l.report_count || 0,
      is_paid: !!l.is_paid,
      requires_payment: !!l.requires_payment,
      featured_until: l.featured_until,
      showcase_until: l.showcase_until,
      owner: byId.get(l.user_id) || null,
    })),
    total: r.count || 0,
    page,
    per,
  });
}

async function listingOp(req, res, auth) {
  const b = body(req);
  const id = int(b.id);
  const r = await supabase.from('listings').select('*').eq('id', id).maybeSingle();
  if (r.error) throw r.error;
  const l = r.data;
  if (!l) throw new HttpError(404, 'İlan bulunamadı.');
  const now = new Date().toISOString();
  let patch = null;
  let movedTo = '';
  switch (b.op) {
    case 'approve':
      // Ücretli ilan, ödeme doğrulanmadan yönetici tarafından da etkinleştirilemez.
      if (l.status === 'pending_payment' || (l.requires_payment && !l.is_paid)) throw new HttpError(400, 'Ödemesi tamamlanmamış ilan onaylanamaz.');
      if (!['pending', 'under_review', 'rejected', 'suspended'].includes(l.status)) throw new HttpError(400, 'Bu ilan onay beklemiyor.');
      patch = { status: 'active', reject_reason: null, published_at: l.published_at || now, updated_at: now };
      break;
    case 'reject': {
      const reason = String(b.reason || '').trim().slice(0, 300);
      if (reason.length < 5) throw new HttpError(400, 'Ret nedeni yazın (en az 5 karakter).', 'reason');
      patch = { status: 'rejected', reject_reason: reason, updated_at: now };
      break;
    }
    case 'review':
      patch = { status: 'under_review', updated_at: now };
      break;
    case 'move': {
      // İlanı doğru kategoriye taşır. Ana kategori değişirse eski kategoriye özel alanlar (marka, km vb.) temizlenir.
      const catId = int(b.category_id);
      const subId = int(b.subcategory_id);
      const cats = await supabase.from('categories').select('id,parent_id,name,filters').in('id', [catId || 0, subId || 0]);
      if (cats.error) throw cats.error;
      const cat = cats.data.find((c) => c.id === catId && !c.parent_id);
      const sub = cats.data.find((c) => c.id === subId && c.parent_id === catId);
      if (!cat || !sub) throw new HttpError(400, 'Kategori ve alt kategori seçin.', 'category');
      if (catId === l.category_id && subId === l.subcategory_id) throw new HttpError(400, 'İlan zaten bu kategoride.', 'category');
      const keep = new Set((Array.isArray(cat.filters) ? cat.filters : []).filter((d) => !Array.isArray(d.only) || d.only.includes(subId)).map((d) => d.key));
      const attributes = catId === l.category_id ? Object.fromEntries(Object.entries(l.attributes || {}).filter(([k]) => keep.has(k))) : {};
      patch = { category_id: catId, subcategory_id: subId, attributes, flags: (Array.isArray(l.flags) ? l.flags : []).filter((f) => f !== 'kategori_uyumsuz'), updated_at: now };
      movedTo = `${cat.name} › ${sub.name}`;
      break;
    }
    case 'feature':
    case 'showcase': {
      const days = int(b.days, 0);
      if (days < 0 || days > 365) throw new HttpError(400, 'Gün sayısı 0-365 arasında olmalı.');
      if (days > 0 && l.status !== 'active') throw new HttpError(400, 'Yalnızca yayındaki ilanlar öne çıkarılabilir.');
      const field = b.op === 'feature' ? 'featured_until' : 'showcase_until';
      patch = { [field]: days > 0 ? new Date(Date.now() + days * 864e5).toISOString() : null };
      break;
    }
    case 'delete':
      await deleteListingRows([l]);
      await supabase.from('reports').update({ status: 'resolved', resolved_at: now, admin_note: 'İlan yönetici tarafından silindi.' }).eq('seller_id', l.user_id).eq('listing_title', l.title).eq('status', 'open');
      if (l.user_id !== auth.user.id) await notify(l.user_id, { type: 'listing', title: 'İlanınız kaldırıldı', body: `“${l.title}” ilan kurallarına aykırı bulunduğu için yönetici tarafından kaldırıldı.`, link: '/hesabim' });
      return res.status(200).json({ ok: true });
    default:
      throw new HttpError(400, 'Geçersiz işlem.');
  }
  const u = await supabase.from('listings').update(patch).eq('id', id).select('id,status').single();
  if (u.error) throw u.error;
  if (l.user_id !== auth.user.id) {
    const t = `“${l.title}”`;
    const days = int(b.days, 0);
    const msg = {
      approve: { title: 'İlanınız onaylandı', body: `${t} yayında.`, link: `/ilan/${id}` },
      reject: { title: 'İlanınız reddedildi', body: `${t}: ${patch.reject_reason || ''}`, link: `/ilan-duzenle/${id}` },
      move: { title: 'İlanınızın kategorisi değiştirildi', body: `${t} “${movedTo}” kategorisine taşındı.`, link: `/ilan/${id}` },
      review: { title: 'İlanınız incelemeye alındı', body: `${t} inceleme bitene kadar yayında değil.`, link: `/ilan/${id}` },
      feature: days > 0 ? { title: 'İlanınız öne çıkarıldı', body: `${t} ${days} gün boyunca öne çıkan ilanlarda gösterilecek.`, link: `/ilan/${id}` } : null,
      showcase: days > 0 ? { title: 'İlanınız vitrine alındı', body: `${t} ${days} gün boyunca ana sayfa vitrininde gösterilecek.`, link: `/ilan/${id}` } : null,
    }[b.op];
    if (msg) await notify(l.user_id, { type: 'listing', ...msg });
  }
  return res.status(200).json(u.data);
}

async function listUsers(req, res) {
  const page = Math.max(1, int(req.query.page, 1));
  const per = 30;
  const filter = String(req.query.filter || 'all');
  let q = supabase.from('profiles').select('id,full_name,phone,avatar_url,city_name,is_admin,is_blocked,is_suspicious,block_reason,listings_created,created_at,last_seen_at', { count: 'exact' });
  if (filter === 'blocked') q = q.eq('is_blocked', true);
  if (filter === 'suspicious') q = q.eq('is_suspicious', true);
  const emails = await emailMap();
  const term = cleanQ(req.query.q);
  if (term) {
    const low = term.toLowerCase();
    const ids = [...emails].filter(([, e]) => e.toLowerCase().includes(low)).map(([id]) => id).slice(0, 150);
    q = ids.length ? q.or(`full_name.ilike."%${term}%",id.in.(${ids.join(',')})`) : q.ilike('full_name', `%${term}%`);
  }
  const r = await q.order('created_at', { ascending: false }).range((page - 1) * per, page * per - 1);
  if (r.error) {
    if (r.error.code === 'PGRST103') return res.status(200).json({ items: [], total: 0, page, per });
    throw r.error;
  }
  const items = [];
  for (const p of r.data) {
    items.push({ ...p, avatar_url: safeAvatar(p.avatar_url), email: emails.get(p.id) || '', phone: dec(p.phone), is_admin: p.is_admin === true ? await isAdmin(p) : false });
  }
  return res.status(200).json({ items, total: r.count || 0, page, per });
}

async function userOp(req, res, auth) {
  const b = body(req);
  const id = String(b.id || '');
  const r = await supabase.from('profiles').select('*').eq('id', id).maybeSingle();
  if (r.error) throw r.error;
  const u = r.data;
  if (!u) throw new HttpError(404, 'Kullanıcı bulunamadı.');
  if (b.op === 'block') {
    if (u.id === auth.user.id || (await isAdmin(u))) throw new HttpError(400, 'Yönetici hesabı engellenemez.');
    const reason = String(b.reason || '').trim().slice(0, 300) || 'Kullanım koşullarının ihlali';
    const up = await supabase.from('profiles').update({ is_blocked: true, block_reason: reason }).eq('id', id);
    if (up.error) throw up.error;
    // Engellenen kullanıcının yayındaki ilanları askıya alınır ve oturum açması engellenir.
    const ls = await supabase.from('listings').update({ status: 'suspended' }).eq('user_id', id).in('status', ['active', 'pending']);
    if (ls.error) throw ls.error;
    try { await supabase.auth.admin.updateUserById(id, { ban_duration: '876000h' }); } catch (e) { console.error('ban', e?.message); }
  } else if (b.op === 'unblock') {
    const up = await supabase.from('profiles').update({ is_blocked: false, block_reason: null }).eq('id', id);
    if (up.error) throw up.error;
    const ls = await supabase.from('listings').update({ status: 'pending' }).eq('user_id', id).eq('status', 'suspended');
    if (ls.error) throw ls.error;
    try { await supabase.auth.admin.updateUserById(id, { ban_duration: 'none' }); } catch (e) { console.error('unban', e?.message); }
  } else if (b.op === 'flag' || b.op === 'unflag') {
    const up = await supabase.from('profiles').update({ is_suspicious: b.op === 'flag' }).eq('id', id);
    if (up.error) throw up.error;
  } else throw new HttpError(400, 'Geçersiz işlem.');
  return res.status(200).json({ ok: true });
}

async function listReports(req, res) {
  const status = String(req.query.status || 'open');
  let q = supabase.from('reports').select('*');
  if (status !== 'all') q = q.eq('status', status);
  const r = await q.order('created_at', { ascending: false }).limit(200);
  if (r.error) throw r.error;
  const uids = [...new Set(r.data.flatMap((x) => [x.reporter_id, x.seller_id]).filter(Boolean))];
  const lids = [...new Set(r.data.map((x) => x.listing_id).filter(Boolean))];
  const [people, ls] = await Promise.all([
    uids.length ? supabase.from('profiles').select('id,full_name,is_blocked,is_suspicious').in('id', uids) : { data: [], error: null },
    lids.length ? supabase.from('listings').select('id,status,images,price,currency').in('id', lids) : { data: [], error: null },
  ]);
  if (people.error) throw people.error;
  if (ls.error) throw ls.error;
  const emails = uids.length ? await emailMap() : new Map();
  const pById = new Map(people.data.map((p) => [p.id, { ...p, email: emails.get(p.id) || '' }]));
  const lById = new Map(ls.data.map((l) => [l.id, l]));
  return res.status(200).json({
    items: r.data.map((x) => ({
      ...x,
      details: dec(x.details),
      reporter: pById.get(x.reporter_id) || null,
      seller: pById.get(x.seller_id) || null,
      listing_status: lById.get(x.listing_id)?.status || null,
    })),
  });
}

async function reportOp(req, res) {
  const b = body(req);
  const id = int(b.id);
  const r = await supabase.from('reports').select('*').eq('id', id).maybeSingle();
  if (r.error) throw r.error;
  if (!r.data) throw new HttpError(404, 'Şikâyet bulunamadı.');
  const now = new Date().toISOString();
  const note = String(b.note || '').trim().slice(0, 500) || null;
  if (b.op === 'dismiss') {
    const u = await supabase.from('reports').update({ status: 'dismissed', admin_note: note, resolved_at: now }).eq('id', id);
    if (u.error) throw u.error;
  } else if (b.op === 'resolve') {
    const u = await supabase.from('reports').update({ status: 'resolved', admin_note: note, resolved_at: now }).eq('id', id);
    if (u.error) throw u.error;
  } else if (b.op === 'remove_listing') {
    if (r.data.listing_id) {
      const l = await supabase.from('listings').select('id,images,user_id,title').eq('id', r.data.listing_id).maybeSingle();
      if (l.error) throw l.error;
      if (l.data) {
        await deleteListingRows([l.data]);
        await notify(l.data.user_id, { type: 'listing', title: 'İlanınız kaldırıldı', body: `“${l.data.title}” şikâyet incelemesi sonucunda yönetici tarafından kaldırıldı.`, link: '/hesabim' });
      }
    }
    const u = await supabase.from('reports').update({ status: 'resolved', admin_note: note || 'İlan kaldırıldı.', resolved_at: now })
      .eq('seller_id', r.data.seller_id).eq('listing_title', r.data.listing_title).eq('status', 'open');
    if (u.error) throw u.error;
  } else throw new HttpError(400, 'Geçersiz işlem.');
  return res.status(200).json({ ok: true });
}

async function listPayments(req, res) {
  const r = await supabase.from('payments').select('*').order('created_at', { ascending: false }).limit(300);
  if (r.error) throw r.error;
  const emails = r.data.length ? await emailMap() : new Map();
  return res.status(200).json({ items: r.data.map((p) => ({ ...p, amount: Number(p.amount), user_email: emails.get(p.user_id) || '' })) });
}

const NUM = {
  free_listing_count: [0, 100], listing_fee: [0, 100000], featured_fee: [0, 100000], featured_days: [1, 365],
  showcase_fee: [0, 100000], showcase_days: [1, 365], max_photos: [10, 20],
};
const BOOL = ['paid_listings_enabled', 'featured_sales_enabled', 'showcase_sales_enabled', 'moderation_enabled'];
const TEXT = { company_name: 120, company_address: 300, contact_email: 120, contact_phone: 40 };

async function getAll(req, res) {
  const [s, paytr, countries, rls, serverKeyOk] = await Promise.all([
    getSettings(), getPaytr(),
    supabase.from('countries').select('*').order('sort_order', { ascending: true }),
    rlsSelfCheck(),
    serverKeyCheck(),
  ]);
  if (countries.error) throw countries.error;
  const mask = (v) => (v ? `${String(v).slice(0, 2)}${'•'.repeat(Math.max(2, String(v).length - 4))}${String(v).slice(-2)}` : '');
  return res.status(200).json({
    settings: { ...s, banners_sig: undefined },
    ad_placements: AD_PLACEMENTS,
    source_zip: SOURCE_ZIP || null,
    android: {
      package: ANDROID_PACKAGE,
      upload_fingerprint: ANDROID_UPLOAD_FINGERPRINT,
      fingerprints: Array.isArray(s.android_fingerprints) ? s.android_fingerprints : [],
      zip: ANDROID_ZIP || null,
      info: ANDROID_ZIP ? ANDROID_INFO : {},
      files: ANDROID_ZIP ? ANDROID_FILES : [],
      key_password: ANDROID_ZIP ? ANDROID_KEY_PASSWORD || null : null,
      assetlinks_url: `${originOf(req)}/.well-known/assetlinks.json`,
    },
    paytr: {
      configured: !!paytr,
      source: paytr?.source || null,
      merchant_id_masked: paytr ? mask(paytr.merchant_id) : '',
      test_mode: !!paytr?.test_mode,
      callback_url: `${originOf(req)}/api/paytr-callback`,
    },
    rls,
    server_key_ok: serverKeyOk,
    countries: countries.data,
  });
}

async function saveSettings(req, res) {
  const b = body(req);
  const current = await getSettings();
  const paytr = await getPaytr();
  const rows = [];
  const now = new Date().toISOString();
  const next = { ...current };
  for (const [k, [lo, hi]] of Object.entries(NUM)) {
    if (b[k] === undefined) continue;
    const n = Number(b[k]);
    if (!Number.isFinite(n) || n < lo || n > hi) throw new HttpError(400, `Geçersiz değer: ${k} (${lo}-${hi})`, k);
    next[k] = k.endsWith('_fee') ? Math.round(n * 100) / 100 : Math.round(n);
  }
  for (const k of BOOL) if (b[k] !== undefined) next[k] = !!b[k];
  for (const [k, len] of Object.entries(TEXT)) if (b[k] !== undefined) next[k] = String(b[k] || '').trim().slice(0, len);

  // Ödeme altyapısı hazır değilken ücretli seçenekler açılamaz; aksi halde kullanıcılar ilan veremez duruma gelirdi.
  const paidFlags = [['paid_listings_enabled', 'listing_fee', 'Ücretli ilan'], ['featured_sales_enabled', 'featured_fee', 'Öne çıkarma satışı'], ['showcase_sales_enabled', 'showcase_fee', 'Vitrin satışı']];
  for (const [flag, fee, label] of paidFlags) {
    if (next[flag] && !paytr) throw new HttpError(400, `${label} açılamadı: PayTR mağaza bilgileri henüz tanımlı değil.`, 'PAYTR_NOT_CONFIGURED');
    if (next[flag] && !(next[fee] > 0)) throw new HttpError(400, `${label} için önce 0'dan büyük bir ücret belirleyin.`, fee);
  }
  for (const k of [...Object.keys(NUM), ...BOOL, ...Object.keys(TEXT)]) {
    if (b[k] !== undefined) rows.push(settingRow(k, next[k]));
  }
  if (rows.length) {
    const u = await supabase.from('settings').upsert(rows, { onConflict: 'key' });
    if (u.error) throw u.error;
  }
  return res.status(200).json({ settings: await getSettings() });
}

// Google AdSense ayarları. Kutulara yapıştırılan her şey tanınmaya çalışılır; tanınmayan metin sessizce atılmaz, nedeni söylenir.
const AD_LABELS = {
  all: 'Google reklam kodu', client: 'Yayıncı kimliği',
  home_desktop: 'Ana sayfa (bilgisayar)', home_mobile: 'Ana sayfa (mobil)', category_desktop: 'Kategori ve arama (bilgisayar)',
  category_mobile: 'Kategori ve arama (mobil)', detail_desktop: 'İlan detayı (bilgisayar)', detail_mobile: 'İlan detayı (mobil)',
};
const ADMOB_MSG = 'bu bir AdMob kimliği (ca-app-pub-…). AdMob reklam birimleri yalnızca yerel (native) uygulamalarda çalışır; bu uygulama siteyi gösterdiği için Google AdSense reklam kodu gerekir. AdSense yayıncı kimliği ca-pub-… ile başlar.';
const adClient = (text) => {
  const m = String(text).match(/ca-pub-(\d{10,20})/i) || String(text).match(/(?:^|[^\w-])pub-(\d{10,20})/i);
  return m ? `ca-pub-${m[1]}` : '';
};
const adSlot = (text) => {
  const t = String(text);
  const m = t.match(/data-ad-slot\s*=\s*["']?(\d{6,20})/i) || t.match(/^\s*(\d{6,20})\s*$/) || t.match(/\bslot["']?\s*[:=]\s*["']?(\d{6,20})/i);
  return m ? m[1] : '';
};

async function saveAds(req, res) {
  const b = body(req);
  const rawClient = String(b.client || '').trim().slice(0, 4000);
  const raws = {};
  for (const k of ['all', ...AD_PLACEMENTS]) raws[k] = String(b.slots?.[k] || '').trim().slice(0, 4000);
  for (const [k, raw] of [['client', rawClient], ...Object.entries(raws)]) {
    if (/ca-app-pub-\d/i.test(raw)) throw new HttpError(400, `“${AD_LABELS[k]}” kutusu: ${ADMOB_MSG}`, k);
  }
  const slots = {};
  for (const [k, raw] of Object.entries(raws)) {
    if (!raw) continue;
    const slot = adSlot(raw);
    if (slot) { slots[k] = slot; continue; }
    // Reklam birimi numarası içermeyen ama yayıncı kimliği içeren kod: AdSense "Otomatik reklamlar" kodudur; kabul edilir.
    if (adClient(raw)) continue;
    throw new HttpError(400, `“${AD_LABELS[k]}” kutusundaki metin bir Google AdSense reklam kodu olarak tanınmadı. Kod, AdSense panelinde Reklamlar → “Reklam birimine göre” → “Kodu al” ile alınır ve içinde data-ad-slot="…" bulunur. Kodun tamamını kopyalayıp yapıştırın.`, k);
  }
  let client = adClient(rawClient);
  if (rawClient && !client) {
    // Yayıncı kimliği kutusuna reklam birimi numarası ya da tanınmayan bir metin yazılmış
    throw new HttpError(400, 'Yayıncı kimliği tanınmadı. AdSense yayıncı kimliği “ca-pub-” ile başlar ve 16 rakam içerir (ör. ca-pub-1234567890123456); AdSense → Hesap → Ayarlar → Hesap bilgileri sayfasında yazar. Reklam kodunuz varsa üstteki “Google reklam kodu” kutusuna yapıştırın.', 'client');
  }
  if (!slots.all && adSlot(rawClient) && rawClient.length > 20) slots.all = adSlot(rawClient);
  if (!client) client = adClient(Object.values(raws).join(' '));
  if (Object.keys(slots).length && !client) {
    throw new HttpError(400, 'Reklam birimi numarası okundu ama yayıncı kimliği (ca-pub-…) bulunamadı. Reklam kodunun tamamını yapıştırın ya da yayıncı kimliğinizi alttaki kutuya yazın.', 'client');
  }
  const enabled = !!b.enabled;
  if (enabled && !client) throw new HttpError(400, 'Google reklamlarını açmak için önce reklam kodunu ya da yayıncı kimliğini (ca-pub-…) girin.', 'client');
  const value = { enabled, client, slots };
  const u = await supabase.from('settings').upsert(settingRow('ads', value), { onConflict: 'key' });
  if (u.error) throw u.error;
  return res.status(200).json({ ads: value, mode: !client ? 'none' : Object.keys(slots).length ? 'units' : 'auto' });
}

async function savePaytr(req, res) {
  const b = body(req);
  const merchant_id = String(b.merchant_id || '').trim();
  const merchant_key = String(b.merchant_key || '').trim();
  const merchant_salt = String(b.merchant_salt || '').trim();
  if (!/^\d{3,12}$/.test(merchant_id)) throw new HttpError(400, 'Mağaza No (merchant_id) yalnızca rakamlardan oluşmalı.', 'merchant_id');
  if (merchant_key.length < 8 || merchant_key.length > 128) throw new HttpError(400, 'Mağaza Parola (merchant_key) geçersiz.', 'merchant_key');
  if (merchant_salt.length < 8 || merchant_salt.length > 128) throw new HttpError(400, 'Mağaza Gizli Anahtar (merchant_salt) geçersiz.', 'merchant_salt');
  // Mağaza bilgileri veritabanına şifrelenerek yazılır ve hiçbir API yanıtında geri döndürülmez.
  await setSecret('paytr', enc(JSON.stringify({ merchant_id, merchant_key, merchant_salt, test_mode: b.test_mode !== false })));
  return res.status(200).json({ ok: true });
}

async function removePaytr(req, res) {
  await deleteSecret('paytr');
  const u = await supabase.from('settings').upsert(
    ['paid_listings_enabled', 'featured_sales_enabled', 'showcase_sales_enabled'].map((key) => settingRow(key, false)),
    { onConflict: 'key' },
  );
  if (u.error) throw u.error;
  return res.status(200).json({ ok: true });
}

function bannerInput(b) {
  const title = String(b.title || '').trim().slice(0, 80);
  if (title.length < 2) throw new HttpError(400, 'Banner başlığı girin.', 'title');
  const image_url = String(b.image_url || '').trim();
  if (image_url && !image_url.startsWith(publicPrefix(BUCKETS.banner))) throw new HttpError(400, 'Görseli yükleme alanından ekleyin.', 'image_url');
  const link_url = String(b.link_url || '').trim().slice(0, 300);
  if (link_url && !(link_url.startsWith('/') || link_url.startsWith('https://'))) throw new HttpError(400, 'Bağlantı "/" veya "https://" ile başlamalı.', 'link_url');
  return {
    title,
    subtitle: String(b.subtitle || '').trim().slice(0, 160) || null,
    image_url: image_url || null,
    link_url: link_url || null,
    cta_label: String(b.cta_label || '').trim().slice(0, 30) || null,
    is_active: b.is_active !== false,
    sort_order: int(b.sort_order, 0),
  };
}

const HOUSE_PLACEMENTS = { home: 'Ana sayfa', category: 'Kategori ve arama sayfaları', detail: 'İlan detayı' };

// Yöneticinin kendi görsel reklamları (AdSense gerektirmez). Görseller yalnızca yükleme ucundan gelen adresler olabilir.
async function saveHouseAds(req, res) {
  const b = body(req);
  const current = (await getSettings()).house_ads || {};
  const prefix = publicPrefix(BUCKETS.banner);
  const value = {};
  for (const [p, label] of Object.entries(HOUSE_PLACEMENTS)) {
    const a = b.ads?.[p] || {};
    const image_url = String(a.image_url || '').trim();
    const mobile_image_url = String(a.mobile_image_url || '').trim();
    for (const u of [image_url, mobile_image_url]) {
      if (u && !u.startsWith(prefix)) throw new HttpError(400, `${label}: görseli "Görsel yükle" düğmesiyle ekleyin.`, p);
    }
    // Bağlantı hoşgörüyle düzeltilir: "site.com" ya da "www.site.com" yazılırsa başına https:// eklenir.
    let link_url = String(a.link_url || '').trim().replace(/\s+/g, '').slice(0, 300);
    if (/^http:\/\//i.test(link_url)) link_url = `https://${link_url.slice(7)}`;
    else if (/^https:\/\//i.test(link_url)) link_url = `https://${link_url.slice(8)}`;
    else if (link_url && !link_url.startsWith('/') && /^[a-z0-9-]+(\.[a-z0-9-]+)+([/?#].*)?$/i.test(link_url)) link_url = `https://${link_url}`;
    if (link_url && !((link_url.startsWith('/') && !link_url.startsWith('//')) || /^https:\/\/[^\s<>"']+\.[^\s<>"']+$/.test(link_url))) {
      throw new HttpError(400, `${label}: “Tıklanınca gidilecek adres” bir web adresi olmalı (ör. https://ornek.com); site içi sayfa için /ilanlar gibi yazın. Adres istemiyorsanız kutuyu boş bırakın.`, p);
    }
    const is_active = !!a.is_active;
    if (is_active && !image_url) throw new HttpError(400, `${label}: reklamı yayına almak için önce bir görsel yükleyin.`, p);
    value[p] = { image_url, mobile_image_url, link_url, title: String(a.title || '').trim().slice(0, 80), is_active };
  }
  const u = await supabase.from('settings').upsert(settingRow('house_ads', value), { onConflict: 'key' });
  if (u.error) throw u.error;
  const keep = new Set(Object.values(value).flatMap((v) => [v.image_url, v.mobile_image_url]).filter(Boolean));
  for (const old of Object.values(current)) {
    for (const url of [old?.image_url, old?.mobile_image_url]) if (url && !keep.has(url)) await removeBannerImage(url);
  }
  return res.status(200).json({ house_ads: value });
}

// Banner tablosundaki her değişiklikten sonra tablonun imzası yenilenir.
async function resignBanners() {
  const all = await supabase.from('banners').select('*');
  if (all.error) throw all.error;
  const u = await supabase.from('settings').upsert(settingRow('banners_sig', bannersDigest(all.data)), { onConflict: 'key' });
  if (u.error) throw u.error;
}

async function removeBannerImage(url) {
  const prefix = publicPrefix(BUCKETS.banner);
  if (url && url.startsWith(prefix)) {
    try { await supabase.storage.from(BUCKETS.banner).remove([url.slice(prefix.length)]); } catch { /* yoksay */ }
  }
}

export default route(async (req, res) => {
  // Her istekte yönetici yetkisi sunucu tarafında, veritabanındaki profil kaydından doğrulanır.
  const auth = await requireAdmin(req);
  const action = String(req.query.action || '');
  const k = `${req.method} ${action}`;
  const b = body(req);
  switch (k) {
    case 'GET stats': return stats(req, res);
    case 'GET listings': return listListings(req, res);
    case 'PUT listing': return listingOp(req, res, auth);
    case 'GET users': return listUsers(req, res);
    case 'PUT user': return userOp(req, res, auth);
    case 'GET reports': return listReports(req, res);
    case 'PUT report': return reportOp(req, res);
    case 'GET payments': return listPayments(req, res);
    case 'GET settings': return getAll(req, res);
    // Supabase SQL Editor'a yapıştırılacak kodlar (panelde "kopyala" düğmeleriyle verilir)
    case 'GET setup-sql': return res.status(200).json({ lockdown: await lockdownSql(), tables: TABLES_SQL, seed: SEED_SQL });
    case 'PUT settings': return saveSettings(req, res);
    case 'PUT ads': return saveAds(req, res);
    case 'PUT house-ads': return saveHouseAds(req, res);
    case 'PUT android': {
      // Google Play'in uygulama imzalama anahtarının SHA-256 parmak izleri (Play Console → Uygulama bütünlüğü)
      const list = [...new Set(String(b.fingerprints || '').toUpperCase().split(/[\s,;]+/).map((x) => x.trim()).filter(Boolean))];
      if (list.length > 6) throw new HttpError(400, 'En fazla 6 parmak izi eklenebilir.', 'fingerprints');
      const bad = list.find((f) => !FINGERPRINT_RE.test(f));
      if (bad) throw new HttpError(400, `Geçersiz parmak izi: “${bad.slice(0, 40)}”. SHA-256 parmak izi, iki nokta ile ayrılmış 32 çift harf/rakamdan oluşur.`, 'fingerprints');
      const u = await supabase.from('settings').upsert(settingRow('android_fingerprints', list), { onConflict: 'key' });
      if (u.error) throw u.error;
      return res.status(200).json({ fingerprints: list });
    }
    case 'PUT paytr': return savePaytr(req, res);
    case 'DELETE paytr': return removePaytr(req, res);
    case 'GET banners': {
      const r = await supabase.from('banners').select('*').order('sort_order', { ascending: true }).order('id', { ascending: false });
      if (r.error) throw r.error;
      const sig = (await getSettings()).banners_sig || '';
      return res.status(200).json({ items: r.data, tampered: r.data.length > 0 && !safeEqual(bannersDigest(r.data), sig) });
    }
    case 'POST banner': {
      const r = await supabase.from('banners').insert(bannerInput(b)).select().single();
      if (r.error) throw r.error;
      await resignBanners();
      return res.status(201).json(r.data);
    }
    case 'PUT banner': {
      const old = await supabase.from('banners').select('image_url').eq('id', int(b.id)).maybeSingle();
      if (old.error) throw old.error;
      if (!old.data) throw new HttpError(404, 'Banner bulunamadı.');
      const input = bannerInput(b);
      const r = await supabase.from('banners').update(input).eq('id', int(b.id)).select().single();
      if (r.error) throw r.error;
      await resignBanners();
      if (old.data.image_url && old.data.image_url !== input.image_url) await removeBannerImage(old.data.image_url);
      return res.status(200).json(r.data);
    }
    case 'DELETE banner': {
      const old = await supabase.from('banners').select('image_url').eq('id', int(b.id)).maybeSingle();
      if (old.error) throw old.error;
      const r = await supabase.from('banners').delete().eq('id', int(b.id));
      if (r.error) throw r.error;
      await resignBanners();
      await removeBannerImage(old.data?.image_url);
      return res.status(200).json({ ok: true });
    }
    case 'PUT country': {
      const code = String(b.code || '').toUpperCase().slice(0, 2);
      if (code === 'TR' && b.is_active === false) throw new HttpError(400, 'Türkiye kapatılamaz.');
      const r = await supabase.from('countries').update({ is_active: !!b.is_active }).eq('code', code).select().maybeSingle();
      if (r.error) throw r.error;
      if (!r.data) throw new HttpError(404, 'Ülke bulunamadı.');
      return res.status(200).json(r.data);
    }
    default:
      throw new HttpError(400, 'Geçersiz istek.');
  }
});
