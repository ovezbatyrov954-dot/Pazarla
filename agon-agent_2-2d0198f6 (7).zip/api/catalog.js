import { supabase, route, HttpError, getSettings, getPaytr, publicSettings, int, bannersDigest, safeBannerImage, safeLink, safeEqual, ANDROID_PACKAGE, ANDROID_UPLOAD_FINGERPRINT, FINGERPRINT_RE } from './_lib.js';

export default route(async (req, res) => {
  if (req.method !== 'GET') throw new HttpError(405, 'Yöntem desteklenmiyor.');
  const action = String(req.query.action || 'bootstrap');

  if (action === 'bootstrap') {
    const [cats, countries, settings, banners, paytr] = await Promise.all([
      supabase.from('categories').select('id,parent_id,slug,name,icon,color,sort_order,filters').order('sort_order', { ascending: true }).order('id', { ascending: true }),
      supabase.from('countries').select('code,name,currency,currency_symbol,phone_prefix,region_label,district_label,is_active,sort_order').eq('is_active', true).order('sort_order', { ascending: true }),
      getSettings(),
      supabase.from('banners').select('id,title,subtitle,image_url,link_url,cta_label,sort_order,is_active').order('sort_order', { ascending: true }).order('id', { ascending: false }),
      getPaytr(),
    ]);
    if (cats.error) throw cats.error;
    if (countries.error) throw countries.error;
    if (banners.error) throw banners.error;
    res.setHeader('Cache-Control', 'public, s-maxage=10, stale-while-revalidate=20');
    return res.status(200).json({
      categories: cats.data,
      countries: countries.data,
      settings: publicSettings(settings, !!paytr),
      // Banner tablosu sunucu imzasıyla eşleşmiyorsa (dışarıdan değiştirilmişse) hiçbir banner gösterilmez.
      banners: banners.data.length && safeEqual(bannersDigest(banners.data), settings.banners_sig || '')
        ? banners.data.filter((b) => b.is_active !== false).map(({ is_active, ...b }) => ({ ...b, image_url: safeBannerImage(b.image_url), link_url: safeLink(b.link_url) }))
        : [],
    });
  }

  if (action === 'cities') {
    const country = String(req.query.country || 'TR').toUpperCase().slice(0, 2);
    const { data, error } = await supabase
      .from('cities').select('id,name,country_code,sort_order').eq('country_code', country)
      .order('sort_order', { ascending: true }).order('name', { ascending: true }).limit(500);
    if (error) throw error;
    res.setHeader('Cache-Control', 'public, s-maxage=3600, stale-while-revalidate=86400');
    return res.status(200).json(data);
  }

  if (action === 'districts') {
    const cityId = int(req.query.city_id);
    if (!cityId) throw new HttpError(400, 'Şehir seçilmedi.');
    const { data, error } = await supabase
      .from('districts').select('id,name,city_id').eq('city_id', cityId).order('name', { ascending: true }).limit(500);
    if (error) throw error;
    res.setHeader('Cache-Control', 'public, s-maxage=3600, stale-while-revalidate=86400');
    return res.status(200).json(data);
  }

  // Android uygulamasının bu siteyi tam ekran (adres çubuğu olmadan) açabilmesi için Digital Asset Links beyanı.
  if (action === 'assetlinks') {
    const s = await getSettings();
    const extra = (Array.isArray(s.android_fingerprints) ? s.android_fingerprints : []).filter((f) => FINGERPRINT_RE.test(f));
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Cache-Control', 'public, s-maxage=60');
    return res.status(200).send(JSON.stringify([{
      relation: ['delegate_permission/common.handle_all_urls'],
      target: { namespace: 'android_app', package_name: ANDROID_PACKAGE, sha256_cert_fingerprints: [...new Set([ANDROID_UPLOAD_FINGERPRINT, ...extra])] },
    }]));
  }

  if (action === 'adstxt') {
    const s = await getSettings();
    // Yayıncı kimliği kaydedildiği anda yayınlanır (reklamlar kapalı olsa da): Google, siteyi bu dosyayla doğrulayabilir.
    const client = /^ca-pub-\d+$/.test(s.ads?.client || '') ? s.ads.client.replace('ca-', '') : null;
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Cache-Control', 'public, s-maxage=60');
    return res.status(200).send(client ? `google.com, ${client}, DIRECT, f08c47fec0942fa0\n` : '# AdSense henüz yapılandırılmadı\n');
  }

  throw new HttpError(400, 'Geçersiz istek.');
});
