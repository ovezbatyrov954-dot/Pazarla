import { supabase, getPaytr, getSettings, paytrCallbackHash, safeEqual, body, hasBlockingFlag, notify } from './_lib.js';

// PayTR Bildirim URL'si. PayTR bu adrese sunucudan sunucuya POST gönderir.
// İmza (hash) mağaza anahtarıyla doğrulanmadan hiçbir ödeme onaylanmaz ve hiçbir ilan etkinleştirilmez.
export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  if (req.method !== 'POST') return res.status(405).send('Method not allowed');
  try {
    const cfg = await getPaytr();
    if (!cfg) return res.status(503).send('PAYTR not configured');
    const b = body(req);
    const { merchant_oid, status, total_amount, hash } = b;
    if (!merchant_oid || !status || total_amount === undefined || !hash) return res.status(400).send('PAYTR notification failed: missing fields');
    const expected = paytrCallbackHash(cfg, merchant_oid, status, total_amount);
    if (!safeEqual(expected, hash)) return res.status(400).send('PAYTR notification failed: bad hash');

    const p = await supabase.from('payments').select('*').eq('merchant_oid', String(merchant_oid)).maybeSingle();
    if (p.error) throw p.error;
    // Bilinmeyen veya daha önce işlenmiş sipariş: PayTR'nin tekrar denememesi için OK dönülür.
    if (!p.data || p.data.status !== 'pending') return res.status(200).send('OK');
    const pay = p.data;
    const now = new Date().toISOString();

    if (status !== 'success') {
      const reason = `${b.failed_reason_code || ''} ${b.failed_reason_msg || 'Ödeme tamamlanmadı'}`.trim().slice(0, 300);
      const f = await supabase.from('payments').update({ status: 'failed', failed_reason: reason }).eq('id', pay.id).eq('status', 'pending');
      if (f.error) throw f.error;
      await notify(pay.user_id, { type: 'payment', title: 'Ödeme tamamlanamadı', body: pay.listing_title ? `“${pay.listing_title}” için ödeme alınamadı. Kartınızdan tahsilat yapılmadı.` : '', link: '/hesabim/odemeler' });
      return res.status(200).send('OK');
    }

    // Tutar doğrulaması: PayTR'nin bildirdiği sipariş tutarı kayıtlı tutarla aynı olmalı.
    const paidKurus = Number(b.payment_amount ?? total_amount);
    if (!Number.isFinite(paidKurus) || paidKurus < pay.amount_kurus) {
      const f = await supabase.from('payments').update({ status: 'failed', failed_reason: 'Tutar uyuşmazlığı' }).eq('id', pay.id).eq('status', 'pending');
      if (f.error) throw f.error;
      return res.status(200).send('OK');
    }

    // Yalnızca "pending" kayıt güncellenir; aynı bildirim iki kez gelirse etki bir kez uygulanır.
    const u = await supabase.from('payments').update({ status: 'paid', paid_at: now, test_mode: String(b.test_mode) === '1' })
      .eq('id', pay.id).eq('status', 'pending').select('id');
    if (u.error) throw u.error;
    if (!u.data.length) return res.status(200).send('OK');

    if (pay.listing_id) {
      const l = await supabase.from('listings').select('id,status,flags,featured_until,showcase_until,published_at').eq('id', pay.listing_id).maybeSingle();
      if (l.error) throw l.error;
      if (l.data) {
        const extend = (current, days) => {
          const base = current && new Date(current).getTime() > Date.now() ? new Date(current).getTime() : Date.now();
          return new Date(base + (days || 7) * 864e5).toISOString();
        };
        let patch = null;
        if (pay.type === 'listing_fee' && l.data.status === 'pending_payment') {
          const s = await getSettings();
          const direct = !s.moderation_enabled && !hasBlockingFlag(l.data.flags);
          patch = { is_paid: true, status: direct ? 'active' : 'pending', published_at: direct ? now : l.data.published_at, updated_at: now };
        } else if (pay.type === 'featured') {
          patch = { featured_until: extend(l.data.featured_until, pay.days) };
        } else if (pay.type === 'showcase') {
          patch = { showcase_until: extend(l.data.showcase_until, pay.days) };
        }
        if (patch) {
          const lu = await supabase.from('listings').update(patch).eq('id', l.data.id);
          if (lu.error) throw lu.error;
        }
      }
    }
    await notify(pay.user_id, { type: 'payment', title: 'Ödemeniz alındı', body: pay.listing_title ? `“${pay.listing_title}” için ödemeniz doğrulandı ve işleminiz uygulandı.` : '', link: pay.listing_id ? `/ilan/${pay.listing_id}` : '/hesabim/odemeler' });
    return res.status(200).send('OK');
  } catch (err) {
    console.error('paytr callback error:', err);
    // 500 dönülürse PayTR bildirimi daha sonra yeniden dener.
    return res.status(500).send('ERROR');
  }
}
