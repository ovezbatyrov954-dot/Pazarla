import crypto from 'crypto';
import {
  supabase, route, HttpError, requireAuth, getSettings, getPaytr, paytrRequestToken, rateLimit, body, int, clientIp, originOf, dec,
} from './_lib.js';

const TYPES = {
  listing_fee: { label: 'İlan yayınlama ücreti' },
  featured: { label: 'Öne çıkarma' },
  showcase: { label: 'Vitrin ilanı' },
};

const safeRow = (p) => ({
  id: p.id,
  merchant_oid: p.merchant_oid,
  listing_id: p.listing_id,
  listing_title: p.listing_title,
  type: p.type,
  amount: Number(p.amount),
  currency: p.currency,
  days: p.days,
  status: p.status,
  failed_reason: p.failed_reason,
  test_mode: !!p.test_mode,
  created_at: p.created_at,
  paid_at: p.paid_at,
});

async function history(req, res) {
  const auth = await requireAuth(req, { allowBlocked: true });
  const r = await supabase.from('payments').select('*').eq('user_id', auth.user.id).order('created_at', { ascending: false }).limit(100);
  if (r.error) throw r.error;
  return res.status(200).json({ items: r.data.map(safeRow) });
}

async function status(req, res) {
  const auth = await requireAuth(req, { allowBlocked: true });
  const oid = String(req.query.oid || '').replace(/[^A-Za-z0-9]/g, '').slice(0, 64);
  const r = await supabase.from('payments').select('*').eq('merchant_oid', oid).eq('user_id', auth.user.id).maybeSingle();
  if (r.error) throw r.error;
  if (!r.data) throw new HttpError(404, 'Ödeme kaydı bulunamadı.');
  return res.status(200).json(safeRow(r.data));
}

// PayTR iFrame API için ödeme başlatır. Tutar her zaman sunucudaki ayarlardan alınır; istemciden gelen tutar kullanılmaz.
async function create(req, res) {
  const auth = await requireAuth(req);
  const cfg = await getPaytr();
  if (!cfg) {
    throw new HttpError(503, 'Online ödeme henüz etkin değil. PayTR mağaza bilgileri tanımlandığında ödeme alınabilecek.', 'PAYTR_NOT_CONFIGURED');
  }
  await rateLimit(`pay:${auth.user.id}`, 15, 3600);
  const b = body(req);
  const type = TYPES[b.type] ? b.type : null;
  if (!type) throw new HttpError(400, 'Geçersiz ödeme türü.');
  const listingId = int(b.listing_id);
  const l = await supabase.from('listings').select('id,user_id,title,status,currency').eq('id', listingId).maybeSingle();
  if (l.error) throw l.error;
  if (!l.data || l.data.user_id !== auth.user.id) throw new HttpError(404, 'İlan bulunamadı.');

  const s = await getSettings();
  let amount = 0;
  let days = null;
  if (type === 'listing_fee') {
    if (l.data.status !== 'pending_payment') throw new HttpError(400, 'Bu ilan için ödeme beklenmiyor.');
    amount = Number(s.listing_fee);
  } else if (type === 'featured') {
    if (!s.featured_sales_enabled) throw new HttpError(400, 'Öne çıkarma satışı şu anda kapalı.');
    if (l.data.status !== 'active') throw new HttpError(400, 'Yalnızca yayındaki ilanlar öne çıkarılabilir.');
    amount = Number(s.featured_fee);
    days = Number(s.featured_days);
  } else {
    if (!s.showcase_sales_enabled) throw new HttpError(400, 'Vitrin satışı şu anda kapalı.');
    if (l.data.status !== 'active') throw new HttpError(400, 'Yalnızca yayındaki ilanlar vitrine alınabilir.');
    amount = Number(s.showcase_fee);
    days = Number(s.showcase_days);
  }
  if (!Number.isFinite(amount) || amount <= 0) throw new HttpError(400, 'Bu hizmet için ücret tanımlanmamış.');

  const name = String(b.name || auth.profile.full_name || '').replace(/\s+/g, ' ').trim().slice(0, 60);
  const phone = String(b.phone || dec(auth.profile.phone) || '').replace(/[^\d+]/g, '').slice(0, 20);
  const address = String(b.address || '').replace(/\s+/g, ' ').trim().slice(0, 400);
  if (name.length < 3) throw new HttpError(400, 'Fatura için ad soyad girin.', 'name');
  if (phone.replace(/\D/g, '').length < 10) throw new HttpError(400, 'Geçerli bir telefon numarası girin.', 'phone');
  if (address.length < 10) throw new HttpError(400, 'Fatura adresini girin.', 'address');

  const amountKurus = Math.round(amount * 100);
  const merchant_oid = `PZR${Date.now().toString(36)}${crypto.randomBytes(8).toString('hex')}`.toUpperCase();
  const ins = await supabase.from('payments').insert({
    merchant_oid,
    user_id: auth.user.id,
    listing_id: l.data.id,
    listing_title: l.data.title,
    type,
    amount,
    amount_kurus: amountKurus,
    currency: 'TRY',
    days,
    status: 'pending',
    provider: 'paytr',
    test_mode: !!cfg.test_mode,
  }).select('id').single();
  if (ins.error) throw ins.error;

  const origin = originOf(req);
  const f = {
    user_ip: clientIp(req),
    merchant_oid,
    email: auth.user.email,
    payment_amount: String(amountKurus),
    user_basket: Buffer.from(JSON.stringify([[`${TYPES[type].label} - İlan #${l.data.id}`, amount.toFixed(2), 1]])).toString('base64'),
    no_installment: '1',
    max_installment: '0',
    currency: 'TL',
    test_mode: cfg.test_mode ? '1' : '0',
  };
  const form = new URLSearchParams({
    merchant_id: cfg.merchant_id,
    ...f,
    paytr_token: paytrRequestToken(cfg, f),
    debug_on: cfg.test_mode ? '1' : '0',
    user_name: name,
    user_address: address,
    user_phone: phone,
    merchant_ok_url: `${origin}/odeme/sonuc?oid=${merchant_oid}`,
    merchant_fail_url: `${origin}/odeme/sonuc?oid=${merchant_oid}&durum=basarisiz`,
    timeout_limit: '30',
    lang: 'tr',
  });

  let out = null;
  try {
    const r = await fetch('https://www.paytr.com/odeme/api/get-token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: form.toString(),
    });
    out = await r.json();
  } catch (e) {
    console.error('paytr get-token', e?.message || e);
  }
  if (!out || out.status !== 'success' || !out.token) {
    const reason = String(out?.reason || 'PayTR ile bağlantı kurulamadı').slice(0, 300);
    await supabase.from('payments').update({ status: 'failed', failed_reason: reason }).eq('id', ins.data.id);
    throw new HttpError(502, `Ödeme başlatılamadı: ${reason}`, 'PAYTR_ERROR');
  }
  return res.status(201).json({ merchant_oid, iframe_token: out.token, amount, test_mode: !!cfg.test_mode });
}

export default route(async (req, res) => {
  const action = String(req.query.action || '');
  if (req.method === 'GET' && action === 'status') return status(req, res);
  if (req.method === 'GET') return history(req, res);
  if (req.method === 'POST' && action === 'create') return create(req, res);
  throw new HttpError(405, 'Yöntem desteklenmiyor.');
});
