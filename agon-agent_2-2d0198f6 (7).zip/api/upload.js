import crypto from 'crypto';
import { supabase, route, HttpError, requireAuth, rateLimit, body, BUCKETS, publicPrefix, isAdmin } from './_lib.js';

const MAX_MAIN = 3 * 1024 * 1024;
const MAX_THUMB = 400 * 1024;

// Yalnızca gerçek JPEG verisi kabul edilir (dosya imzası denetlenir). İstemci tüm fotoğrafları JPEG'e dönüştürür.
function decodeJpeg(b64, maxBytes, label) {
  if (typeof b64 !== 'string' || b64.length < 100) throw new HttpError(400, `${label} verisi eksik.`);
  if (b64.length > Math.ceil(maxBytes * 1.37) + 16) throw new HttpError(413, `${label} çok büyük.`);
  if (!/^[A-Za-z0-9+/=]+$/.test(b64.slice(0, 2000))) throw new HttpError(400, 'Geçersiz dosya biçimi.');
  const buf = Buffer.from(b64, 'base64');
  if (buf.length > maxBytes) throw new HttpError(413, `${label} çok büyük.`);
  const okStart = buf.length > 4 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
  const okEnd = buf[buf.length - 2] === 0xff && buf[buf.length - 1] === 0xd9;
  if (!okStart || !okEnd) throw new HttpError(415, 'Yalnızca fotoğraf (JPEG) yüklenebilir.');
  return buf;
}

export default route(async (req, res) => {
  if (req.method !== 'POST') throw new HttpError(405, 'Yöntem desteklenmiyor.');
  const auth = await requireAuth(req);
  const b = body(req);
  const kind = ['listing', 'avatar', 'banner'].includes(b.kind) ? b.kind : null;
  if (!kind) throw new HttpError(400, 'Geçersiz yükleme türü.');
  if (kind === 'banner' && !(await isAdmin(auth.profile))) throw new HttpError(403, 'Bu alana erişim yetkiniz yok.', 'FORBIDDEN');

  await rateLimit(`upload:${auth.user.id}`, 150, 3600, 'Çok fazla dosya yüklediniz. Lütfen daha sonra tekrar deneyin.');

  const main = decodeJpeg(b.main, MAX_MAIN, 'Fotoğraf');
  const thumb = kind === 'listing' ? decodeJpeg(b.thumb, MAX_THUMB, 'Önizleme') : null;

  const bucket = BUCKETS[kind];
  const name = crypto.randomBytes(16).toString('hex');
  const folder = kind === 'banner' ? 'site' : auth.user.id;
  const path = `${folder}/${name}.jpg`;
  const opts = { contentType: 'image/jpeg', upsert: false, cacheControl: '31536000' };

  const up = await supabase.storage.from(bucket).upload(path, main, opts);
  if (up.error) throw up.error;
  if (thumb) {
    const t = await supabase.storage.from(bucket).upload(`${folder}/${name}_t.jpg`, thumb, opts);
    if (t.error) {
      await supabase.storage.from(bucket).remove([path]);
      throw t.error;
    }
  }
  const url = `${publicPrefix(bucket)}${path}`;

  if (kind === 'avatar') {
    const old = auth.profile.avatar_url;
    const u = await supabase.from('profiles').update({ avatar_url: url }).eq('id', auth.user.id);
    if (u.error) throw u.error;
    if (old && old.startsWith(publicPrefix(bucket))) {
      try { await supabase.storage.from(bucket).remove([old.slice(publicPrefix(bucket).length)]); } catch { /* yoksay */ }
    }
  }
  return res.status(201).json({ url });
});
