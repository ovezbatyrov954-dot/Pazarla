// İlan başlığından kategori tahmini. Amaç: bir ilanın açıkça başka bir kategoriye ait olduğunu yakalamak
// (ör. "Telefon ve Tablet" altında elbise). Anahtar sözcükler Türkçe karakterlerden arındırılmış hâlde yazılır.
//  - "sozcuk"   : sözcüğün başıyla eşleşir (elbise → elbisesi, elbiseler). Sonu k/p ile bitenlerde yumuşama da
//                 hesaba katılır (yatak → yatağı, kitap → kitabı).
//  - "sozcuk!"  : yalnızca tam eşleşme (kısa ya da başka sözcüklerin başında geçen kelimeler için).
//  - "iki sozcuk": birlikte geçen ifade; tek sözcükten daha güçlü sayılır (3 puan).
// Seçilen kategoride hiç eşleşme yoksa ya da başka bir kategori en az 2 puan öndeyse uyumsuzluk bildirilir.
import { norm } from './_lib.js';

const HINTS = {
  1: ['otomobil', 'otomotiv', 'oto!', 'araba', 'sedan', 'hatchback', 'suv!', 'pickup', 'minibus', 'kamyon', 'cekici!', 'otobus', 'karavan', 'tekne', 'panelvan', 'minivan', 'jant', 'lastik', 'renault', 'fiat', 'tofas', 'togg!', 'volkswagen', 'opel', 'peugeot', 'citroen', 'hyundai', 'toyota', 'honda', 'ford!', 'bmw!', 'mercedes', 'audi', 'skoda', 'dacia', 'nissan', 'kia!', 'volvo', 'tesla', 'clio', 'egea', 'corolla', 'passat', 'megane', 'doblo', 'fiorino', 'transit!', 'oto yedek parca', 'arac kiti'],
  2: ['motosiklet', 'motorsiklet', 'scooter', 'atv!', 'bisiklet', 'kask!', 'kaski!', 'yamaha', 'kawasaki', 'vespa', 'mondial', 'bajaj', 'honda', 'motor kaski', 'elektrikli bisiklet'],
  3: ['daire', 'arsa!', 'arsasi!', 'tarla', 'villa', 'dukkan', 'isyeri', 'is yeri', 'mustakil', 'dubleks', 'rezidans', 'residence', 'emlak', 'konut', 'imarli', 'tapulu', 'yazlik', 'kiralik daire', 'satilik daire', 'satilik ev', 'kiralik ev', 'gunluk kiralik', 'devren'],
  4: ['telefon', 'iphone', 'galaxy', 'tablet', 'ipad', 'kulaklik', 'airpods', 'kilif', 'powerbank', 'redmi', 'xiaomi', 'oppo!', 'realme', 'android', 'cep telefonu', 'akilli saat', 'akilli bileklik', 'sarj aleti', 'sarj cihazi', 'ekran koruyucu'],
  5: ['laptop', 'notebook', 'bilgisayar', 'macbook', 'monitor', 'yazici', 'televizyon', 'tv!', 'playstation', 'ps4!', 'ps5!', 'xbox', 'nintendo', 'kamera', 'drone', 'modem', 'klavye', 'mouse!', 'islemci', 'anakart', 'ssd!', 'hoparlor', 'projeksiyon', 'oyun konsolu', 'ekran karti', 'fotograf makinesi', 'ses sistemi', 'smart tv', 'harddisk', 'hard disk'],
  6: ['buzdolabi', 'firin!', 'firini!', 'ocak!', 'ocagi!', 'klima', 'kombi', 'mikrodalga', 'aspirator', 'davlumbaz', 'sebil', 'sofben', 'termosifon', 'camasir makinesi', 'bulasik makinesi', 'kurutma makinesi', 'derin dondurucu', 'su aritma', 'beyaz esya'],
  7: ['koltuk', 'kanepe', 'yatak', 'baza!', 'bazasi!', 'gardirop', 'dolap', 'masa!', 'masasi!', 'masalar!', 'sandalye', 'sehpa', 'kitaplik', 'komodin', 'sifonyer', 'hali!', 'halisi!', 'kilim', 'avize', 'perde', 'ayna!', 'aynasi!', 'berjer', 'karyola', 'ranza', 'abajur', 'lambader', 'mobilya', 'tv unitesi', 'yemek odasi', 'yatak odasi', 'oturma grubu', 'kose takimi', 'masa lambasi', 'genc odasi'],
  8: ['tencere', 'tava!', 'tavasi!', 'duduklu', 'tabak', 'bardak', 'catal', 'blender', 'mikser', 'supurge', 'utu!', 'utusu!', 'airfryer', 'fritoz', 'kettle', 'nevresim', 'battaniye', 'yorgan', 'havlu', 'cezve', 'termos', 'yemek takimi', 'cay makinesi', 'kahve makinesi', 'tost makinesi', 'su isitici', 'mutfak robotu', 'saklama kabi', 'utu masasi', 'elektrikli supurge'],
  9: ['elbise', 'gomlek', 'pantolon', 'kazak', 'ceket', 'mont!', 'montu!', 'kaban', 'etek', 'tisort', 'sweatshirt', 'esofman', 'abiye', 'gelinlik', 'damatlik', 'pijama', 'tayt', 'hirka', 'bluz', 'tunik', 'ferace', 'esarp', 'kot!', 'jean', 'yelek', 'mayo!', 'bikini', 'corap', 'atki', 'kravat', 'kolye', 'kupe!', 'bilezik', 'yuzuk', 'gozluk', 'giyim', 'kiyafet', 't shirt', 'takim elbise', 'kol saati', 'kot pantolon'],
  10: ['ayakkabi', 'bot!', 'botu!', 'botlar!', 'cizme', 'terlik', 'sandalet', 'sneaker', 'canta', 'valiz', 'bavul', 'cuzdan', 'topuklu', 'babet', 'loafer', 'krampon', 'sirt cantasi', 'spor ayakkabi', 'el cantasi', 'okul cantasi'],
  11: ['bebek', 'cocuk', 'besik', 'biberon', 'emzik', 'yurutec', 'puset', 'zibin', 'kanguru!', 'bebek arabasi', 'oto koltugu', 'park yatak', 'mama sandalyesi', 'ana kucagi', 'bebek bezi', 'bebek yatagi', 'cocuk odasi'],
  12: ['dambil', 'halter', 'kondisyon', 'fitness', 'cadir', 'kamp!', 'olta', 'kayak!', 'snowboard', 'forma!', 'formasi!', 'raket', 'pilates', 'kaykay', 'paten', 'scooter', 'trambolin', 'barfiks', 'krampon', 'kosu bandi', 'kondisyon bisikleti', 'uyku tulumu', 'futbol topu', 'basketbol topu', 'yoga mati', 'sisme bot', 'boks eldiveni', 'kamp sandalyesi'],
  13: ['kitap!', 'kitabi!', 'kitaplar!', 'kitaplari!', 'roman!', 'romani!', 'kpss!', 'tyt!', 'ayt!', 'yks!', 'lgs!', 'dergi', 'kirtasiye', 'defter', 'kalem!', 'kalemi!', 'kalemler!', 'ansiklopedi', 'sozluk', 'ders kitabi', 'test kitabi', 'soru bankasi', 'cizgi roman', 'okul cantasi', 'hikaye kitabi'],
  14: ['oyuncak', 'lego', 'puzzle', 'gitar', 'piyano', 'keman', 'baglama', 'saz!', 'davul', 'org!', 'flut', 'ukulele', 'klarnet', 'koleksiyon', 'antika', 'maket', 'plak!', 'kutu oyunu', 'uzaktan kumandali', 'pelus oyuncak'],
  15: ['matkap', 'hizar', 'testere', 'cimento', 'tugla', 'seramik', 'fayans', 'parke', 'laminat', 'pencere', 'pvc!', 'fidan', 'tohum', 'saksi', 'hortum', 'merdiven', 'lavabo', 'klozet', 'musluk', 'armatur', 'vidalama', 'cim bicme', 'el aleti', 'celik kapi', 'dus kabin', 'bahce hortumu'],
  16: ['bal!', 'bali!', 'recel', 'zeytin', 'peynir', 'tereyag', 'findik', 'ceviz', 'badem', 'fistik', 'kuruyemis', 'pekmez', 'salca', 'tursu', 'baharat', 'cay!', 'cayi!', 'kahve!', 'kahvesi!', 'bulgur', 'mercimek', 'nohut', 'pirinc', 'yumurta', 'tarhana', 'eriste', 'sucuk', 'pastirma', 'baklava', 'lokum', 'cikolata', 'icecek', 'damacana', 'kuru meyve', 'ev yapimi', 'nar eksisi', 'icme suyu', 'maden suyu', 'kaynak suyu'],
  17: ['parfum', 'deodorant', 'makyaj', 'ruj!', 'rimel', 'fondoten', 'krem!', 'kremi!', 'sampuan', 'epilasyon', 'epilator', 'oje!', 'serum', 'maskara', 'kozmetik', 'cilt bakim', 'sac kurutma', 'sac duzlestirici', 'sac masasi', 'tiras makinesi', 'dis fircasi', 'gunes kremi', 'sac boyasi', 'masaj aleti', 'kisisel bakim'],
  18: ['mama!', 'mamasi!', 'kedi', 'kopek', 'kafes', 'akvaryum', 'tasma', 'hamster', 'kedi kumu', 'kedi mamasi', 'kopek mamasi', 'kus kafesi', 'kus yemi', 'tirmalama tahtasi'],
  19: ['ekskavator', 'kepce', 'forklift', 'traktor', 'jenerator', 'kompresor', 'torna!', 'freze', 'cnc!', 'pulluk', 'romork', 'vinc!', 'transpalet', 'dozer', 'greyder', 'endustriyel', 'is makinesi', 'kaynak makinesi', 'bicer dover', 'sanayi tipi'],
};

function compile(list) {
  return list.map((raw) => {
    const exact = raw.endsWith('!');
    const words = (exact ? raw.slice(0, -1) : raw).split(' ');
    return { words, exact };
  });
}
const COMPILED = Object.fromEntries(Object.entries(HINTS).map(([id, list]) => [id, compile(list)]));

function wordHit(token, kw, exact) {
  if (exact) return token === kw;
  if (token.startsWith(kw)) return true;
  const last = kw[kw.length - 1];
  if (last === 'k') return token.startsWith(`${kw.slice(0, -1)}g`); // yatak → yatağı
  if (last === 'p') return token.startsWith(`${kw.slice(0, -1)}b`); // kitap → kitabı, dolap → dolabı
  return false;
}

function hit(tokens, { words, exact }) {
  for (let i = 0; i + words.length <= tokens.length; i++) {
    let ok = true;
    for (let j = 0; j < words.length && ok; j++) {
      const isLast = j === words.length - 1;
      ok = isLast ? wordHit(tokens[i + j], words[j], exact) : tokens[i + j] === words[j];
    }
    if (ok) return true;
  }
  return false;
}

export function categoryScores(title) {
  const tokens = norm(title).split(' ').filter(Boolean);
  const scores = {};
  for (const [id, list] of Object.entries(COMPILED)) {
    let s = 0;
    for (const k of list) if (hit(tokens, k)) s += k.words.length > 1 ? 3 : 1;
    if (s) scores[id] = s;
  }
  return scores;
}

// Başlık seçilen kategoriye uymuyor ve başka bir kategoriye açıkça uyuyorsa o kategorinin numarasını döndürür.
// Başlıkta tanınan bir sözcük yoksa ya da seçilen kategori de makul görünüyorsa null döner (ilan engellenmez).
export function categoryMismatch(title, categoryId) {
  const scores = categoryScores(title);
  const selected = scores[categoryId] || 0;
  let best = 0;
  let bestId = null;
  for (const [id, s] of Object.entries(scores)) {
    if (Number(id) !== Number(categoryId) && s > best) { best = s; bestId = Number(id); }
  }
  if (!bestId) return null;
  if (selected === 0) return bestId;
  return best >= selected + 2 ? bestId : null;
}
