import {
  supabase, route, HttpError, getAuth, requireAuth, getSettings, getPaytr, norm, toCard, CARD_COLS,
  publicPrefix, BUCKETS, removeImages, deleteListingRows, spamFlags, rateLimit, body, int, isAdmin, dec, hasBlockingFlag, listingImages, safeAvatar, notifyAdmin,
} from './_lib.js';
import { categoryMismatch } from './_category-hints.js';

// Başlık seçilen kategoriye uymuyorsa ilan sahibine doğru kategori önerilir. Sahibi yine de aynı kategoride ısrar ederse
// ilan doğrudan yayına girmez; "kategori_uyumsuz" işaretiyle yönetici onayına düşer.
async function categoryGuard(data, b, changed = true) {
  const suggested = categoryMismatch(data.title, data.category_id);
  if (suggested && changed && b.confirm_category !== true) {
    const c = await supabase.from('categories').select('id,name').eq('id', suggested).maybeSingle();
    const name = c.data?.name || 'başka bir kategori';
    throw new HttpError(409, `Bu ilan “${name}” kategorisine daha uygun görünüyor.`, 'CATEGORY_MISMATCH', { suggested_category_id: suggested, suggested_category_name: name });
  }
  return suggested;
}

const clamp = (v, def, min, max) => Math.min(max, Math.max(min, int(v, def)));

function applyFilters(b, q, filterDefs) {
  if (q.country) b = b.eq('country_code', String(q.country).toUpperCase().slice(0, 2));
  const cat = int(q.category);
  const sub = int(q.sub);
  if (cat) b = b.eq('category_id', cat);
  if (sub) b = b.eq('subcategory_id', sub);
  const city = int(q.city);
  const district = int(q.district);
  if (city) b = b.eq('city_id', city);
  if (district) b = b.eq('district_id', district);
  const min = Number(q.min);
  const max = Number(q.max);
  if (q.min !== undefined && q.min !== '' && Number.isFinite(min) && min >= 0) b = b.gte('price', min);
  if (q.max !== undefined && q.max !== '' && Number.isFinite(max) && max >= 0) b = b.lte('price', max);
  if (q.condition === 'new' || q.condition === 'used') b = b.eq('condition', q.condition);
  const words = norm(q.q).split(' ').filter((w) => w.length >= 2).slice(0, 6);
  for (const w of words) b = b.ilike('title_search', `%${w}%`);
  for (const d of filterDefs || []) {
    if (!/^[a-z0-9_]+$/.test(d.key)) continue;
    if (d.type === 'select') {
      const v = q[`a_${d.key}`];
      if (v && Array.isArray(d.options) && d.options.includes(String(v))) b = b.eq(`attributes->>${d.key}`, String(v));
    } else if (d.type === 'number') {
      const lo = Number(q[`a_${d.key}_min`]);
      const hi = Number(q[`a_${d.key}_max`]);
      if (q[`a_${d.key}_min`] !== undefined && q[`a_${d.key}_min`] !== '' && Number.isFinite(lo)) b = b.gte(`attributes->${d.key}`, lo);
      if (q[`a_${d.key}_max`] !== undefined && q[`a_${d.key}_max`] !== '' && Number.isFinite(hi)) b = b.lte(`attributes->${d.key}`, hi);
    }
  }
  return b;
}

async function search(req, res) {
  const q = req.query;
  const page = clamp(q.page, 1, 1, 400);
  const per = clamp(q.per, 24, 1, 48);
  let defs = [];
  const cat = int(q.category);
  if (cat) {
    const c = await supabase.from('categories').select('filters').eq('id', cat).maybeSingle();
    if (c.error) throw c.error;
    defs = Array.isArray(c.data?.filters) ? c.data.filters : [];
  }
  const base = () => applyFilters(supabase.from('listings').select(CARD_COLS, { count: 'exact' }).eq('status', 'active'), q, defs);

  let main = base();
  const sort = String(q.sort || 'new');
  if (sort === 'cheap') main = main.order('price', { ascending: true });
  else if (sort === 'expensive') main = main.order('price', { ascending: false });
  else if (sort === 'views') main = main.order('view_count', { ascending: false });
  else main = main.order('published_at', { ascending: false, nullsFirst: false });
  main = main.order('id', { ascending: false }).range((page - 1) * per, page * per - 1);

  const featuredQ = page === 1
    ? applyFilters(supabase.from('listings').select(CARD_COLS).eq('status', 'active'), q, defs)
        .gt('featured_until', new Date().toISOString()).order('featured_until', { ascending: false }).limit(4)
    : Promise.resolve({ data: [], error: null });

  const [r, f] = await Promise.all([main, featuredQ]);
  if (r.error) {
    if (r.error.code === 'PGRST103') return res.status(200).json({ items: [], total: 0, page, per, featured: [] });
    throw r.error;
  }
  if (f.error) throw f.error;
  return res.status(200).json({
    items: (r.data || []).map(toCard),
    total: r.count || 0,
    page,
    per,
    featured: (f.data || []).map(toCard),
  });
}

async function home(req, res) {
  const now = new Date().toISOString();
  const country = req.query.country ? String(req.query.country).toUpperCase().slice(0, 2) : null;
  const q = () => {
    let b = supabase.from('listings').select(CARD_COLS).eq('status', 'active');
    if (country) b = b.eq('country_code', country);
    return b;
  };
  let countQ = supabase.from('listings').select('id', { count: 'exact', head: true }).eq('status', 'active');
  if (country) countQ = countQ.eq('country_code', country);
  const [showcase, featured, latest, total] = await Promise.all([
    q().gt('showcase_until', now).order('showcase_until', { ascending: false }).limit(12),
    q().gt('featured_until', now).order('featured_until', { ascending: false }).limit(12),
    q().order('published_at', { ascending: false, nullsFirst: false }).order('id', { ascending: false }).limit(24),
    countQ,
  ]);
  for (const r of [showcase, featured, latest, total]) if (r.error) throw r.error;
  return res.status(200).json({
    showcase: showcase.data.map(toCard),
    featured: featured.data.map(toCard),
    latest: latest.data.map(toCard),
    total: total.count || 0,
  });
}

async function detail(req, res) {
  const id = int(req.query.id);
  if (!id) throw new HttpError(400, 'Geçersiz ilan numarası.');
  const r = await supabase.from('listings').select('*').eq('id', id).maybeSingle();
  if (r.error) throw r.error;
  const l = r.data;
  if (!l) throw new HttpError(404, 'İlan bulunamadı.', 'NOT_FOUND');
  const auth = await getAuth(req);
  const isOwner = auth?.user.id === l.user_id;
  const admin = auth ? await isAdmin(auth.profile) : false;
  if (l.status !== 'active' && !isOwner && !admin) throw new HttpError(404, 'Bu ilan yayında değil.', 'NOT_FOUND');

  const [sellerR, countR, similarR, favR] = await Promise.all([
    supabase.from('profiles').select('id,full_name,avatar_url,created_at,show_phone,phone,whatsapp,city_name').eq('id', l.user_id).maybeSingle(),
    supabase.from('listings').select('id', { count: 'exact', head: true }).eq('user_id', l.user_id).eq('status', 'active'),
    supabase.from('listings').select(CARD_COLS).eq('status', 'active').eq('category_id', l.category_id).neq('id', l.id)
      .order('published_at', { ascending: false, nullsFirst: false }).limit(8),
    auth
      ? supabase.from('favorites').select('id').eq('user_id', auth.user.id).eq('listing_id', l.id).limit(1)
      : Promise.resolve({ data: [], error: null }),
  ]);
  for (const x of [sellerR, countR, similarR, favR]) if (x.error) throw x.error;
  const s = sellerR.data;
  const now = Date.now();
  const out = {
    id: l.id,
    user_id: l.user_id,
    title: l.title,
    description: l.description,
    price: Number(l.price),
    currency: l.currency,
    category_id: l.category_id,
    subcategory_id: l.subcategory_id,
    country_code: l.country_code,
    city_id: l.city_id,
    district_id: l.district_id,
    city_name: l.city_name,
    district_name: l.district_name,
    condition: l.condition,
    images: listingImages(l.images),
    attributes: l.attributes || {},
    status: l.status,
    view_count: l.view_count || 0,
    date: l.published_at || l.created_at,
    created_at: l.created_at,
    is_featured: !!(l.featured_until && new Date(l.featured_until).getTime() > now),
    is_showcase: !!(l.showcase_until && new Date(l.showcase_until).getTime() > now),
  };
  if (isOwner || admin) {
    out.reject_reason = l.reject_reason;
    out.featured_until = l.featured_until;
    out.showcase_until = l.showcase_until;
    out.is_paid = l.is_paid;
  }
  if (admin) out.flags = l.flags || [];
  return res.status(200).json({
    listing: out,
    seller: s
      ? {
          id: s.id,
          full_name: s.full_name || 'PAZARLA üyesi',
          avatar_url: safeAvatar(s.avatar_url),
          created_at: s.created_at,
          city_name: s.city_name,
          has_phone: !!(s.show_phone && s.phone),
          whatsapp: !!(s.show_phone && s.phone && s.whatsapp),
          active_count: countR.count || 0,
        }
      : null,
    similar: similarR.data.map(toCard),
    is_favorite: (favR.data || []).length > 0,
    is_owner: isOwner,
  });
}

async function phone(req, res) {
  const auth = await requireAuth(req);
  const id = int(req.query.id);
  await rateLimit(`phone:${auth.user.id}`, 40, 3600, 'Kısa sürede çok fazla telefon numarası görüntülediniz. Lütfen daha sonra tekrar deneyin.');
  const r = await supabase.from('listings').select('user_id,status').eq('id', id).maybeSingle();
  if (r.error) throw r.error;
  if (!r.data || r.data.status !== 'active') throw new HttpError(404, 'İlan bulunamadı.');
  const p = await supabase.from('profiles').select('phone,show_phone,whatsapp,is_blocked').eq('id', r.data.user_id).maybeSingle();
  if (p.error) throw p.error;
  if (!p.data || !p.data.show_phone || !p.data.phone || p.data.is_blocked) throw new HttpError(404, 'Satıcı telefon numarasını paylaşmıyor.');
  const number = dec(p.data.phone);
  if (!number) throw new HttpError(404, 'Satıcı telefon numarasını paylaşmıyor.');
  return res.status(200).json({ phone: number, whatsapp: !!p.data.whatsapp });
}

async function view(req, res) {
  const id = int(body(req).id);
  if (!id) throw new HttpError(400, 'Geçersiz ilan.');
  const auth = await getAuth(req);
  const r = await supabase.from('listings').select('id,user_id,status,view_count').eq('id', id).maybeSingle();
  if (r.error) throw r.error;
  if (!r.data || r.data.status !== 'active') return res.status(200).json({ ok: true });
  if (auth?.user.id === r.data.user_id) return res.status(200).json({ ok: true, view_count: r.data.view_count });
  const next = (r.data.view_count || 0) + 1;
  const u = await supabase.from('listings').update({ view_count: next }).eq('id', id);
  if (u.error) throw u.error;
  return res.status(200).json({ ok: true, view_count: next });
}

async function quotaOf(profile) {
  const [s, paytr] = await Promise.all([getSettings(), getPaytr()]);
  const used = profile.listings_created || 0;
  const paidOn = !!(s.paid_listings_enabled && s.listing_fee > 0 && paytr);
  return {
    free_total: s.free_listing_count,
    used,
    free_left: Math.max(0, s.free_listing_count - used),
    paid_enabled: paidOn,
    listing_fee: s.listing_fee,
    next_requires_payment: paidOn && used >= s.free_listing_count,
    settings: s,
  };
}

async function mine(req, res) {
  const auth = await requireAuth(req, { allowBlocked: true });
  const r = await supabase.from('listings').select('*').eq('user_id', auth.user.id).order('created_at', { ascending: false }).limit(500);
  if (r.error) throw r.error;
  const q = await quotaOf(auth.profile);
  delete q.settings;
  return res.status(200).json({
    items: r.data.map((l) => ({
      ...toCard(l),
      created_at: l.created_at,
      reject_reason: l.reject_reason,
      featured_until: l.featured_until,
      showcase_until: l.showcase_until,
      is_paid: l.is_paid,
    })),
    quota: q,
  });
}

function cleanAttributes(input, defs, subId) {
  const out = {};
  if (!input || typeof input !== 'object') return out;
  for (const d of defs || []) {
    if (!/^[a-z0-9_]+$/.test(d.key)) continue;
    if (Array.isArray(d.only) && !d.only.includes(subId)) continue;
    const v = input[d.key];
    if (v === undefined || v === null || v === '') continue;
    if (d.type === 'select') {
      if (Array.isArray(d.options) && d.options.includes(String(v))) out[d.key] = String(v);
    } else if (d.type === 'number') {
      const n = Number(v);
      if (Number.isFinite(n) && n >= (d.min ?? 0) && n <= (d.max ?? 1e9)) out[d.key] = n;
    } else {
      const t = String(v).replace(/\s+/g, ' ').trim().slice(0, 80);
      if (t) out[d.key] = t;
    }
  }
  return out;
}

async function validateInput(b, userId, maxPhotos) {
  const title = String(b.title || '').replace(/\s+/g, ' ').trim();
  if (title.length < 5 || title.length > 100) throw new HttpError(400, 'İlan başlığı 5 ile 100 karakter arasında olmalı.', 'title');
  const description = String(b.description || '').replace(/\r/g, '').trim();
  if (description.length < 20 || description.length > 5000) throw new HttpError(400, 'Açıklama 20 ile 5000 karakter arasında olmalı.', 'description');
  const price = Math.round(Number(b.price) * 100) / 100;
  if (!Number.isFinite(price) || price <= 0 || price > 1e12) throw new HttpError(400, 'Geçerli bir fiyat girin.', 'price');
  const condition = b.condition === 'new' ? 'new' : b.condition === 'used' ? 'used' : null;
  if (!condition) throw new HttpError(400, 'Ürün durumunu seçin (sıfır / ikinci el).', 'condition');

  const catId = int(b.category_id);
  const subId = int(b.subcategory_id);
  if (!catId || !subId) throw new HttpError(400, 'Kategori ve alt kategori seçin.', 'category');
  const cats = await supabase.from('categories').select('id,parent_id,filters').in('id', [catId, subId]);
  if (cats.error) throw cats.error;
  const cat = cats.data.find((c) => c.id === catId && !c.parent_id);
  const sub = cats.data.find((c) => c.id === subId && c.parent_id === catId);
  if (!cat || !sub) throw new HttpError(400, 'Seçilen kategori geçersiz.', 'category');

  const code = String(b.country_code || 'TR').toUpperCase().slice(0, 2);
  const cityId = int(b.city_id);
  const districtId = int(b.district_id);
  if (!cityId) throw new HttpError(400, 'Şehir seçin.', 'city');
  if (!districtId) throw new HttpError(400, 'İlçe seçin.', 'district');
  const [country, city, district] = await Promise.all([
    supabase.from('countries').select('code,currency,is_active').eq('code', code).maybeSingle(),
    supabase.from('cities').select('id,name,country_code').eq('id', cityId).maybeSingle(),
    supabase.from('districts').select('id,name,city_id').eq('id', districtId).maybeSingle(),
  ]);
  for (const x of [country, city, district]) if (x.error) throw x.error;
  if (!country.data || !country.data.is_active) throw new HttpError(400, 'Seçilen ülke şu anda desteklenmiyor.', 'country');
  if (!city.data || city.data.country_code !== code) throw new HttpError(400, 'Seçilen şehir geçersiz.', 'city');
  if (!district.data || district.data.city_id !== cityId) throw new HttpError(400, 'Seçilen ilçe geçersiz.', 'district');

  const prefix = `${publicPrefix(BUCKETS.listing)}${userId}/`;
  const images = [...new Set(Array.isArray(b.images) ? b.images : [])].filter(
    (u) => typeof u === 'string' && u.startsWith(prefix) && /^[a-f0-9]{16,64}\.jpg$/.test(u.slice(prefix.length)),
  );
  if (images.length < 1) throw new HttpError(400, 'En az 1 fotoğraf yükleyin.', 'images');
  if (images.length > maxPhotos) throw new HttpError(400, `En fazla ${maxPhotos} fotoğraf yükleyebilirsiniz.`, 'images');

  return {
    title,
    title_search: norm(title),
    description,
    price,
    currency: country.data.currency,
    condition,
    category_id: catId,
    subcategory_id: subId,
    country_code: code,
    city_id: cityId,
    district_id: districtId,
    city_name: city.data.name,
    district_name: district.data.name,
    images,
    attributes: cleanAttributes(b.attributes, cat.filters, subId),
  };
}

async function create(req, res) {
  const auth = await requireAuth(req);
  const uid = auth.user.id;
  const profile = auth.profile;
  if (!profile.full_name) throw new HttpError(400, 'İlan vermeden önce profilinize ad soyad ekleyin.', 'PROFILE_INCOMPLETE');

  const dayAgo = new Date(Date.now() - 864e5).toISOString();
  const recent = await supabase.from('listings').select('id,created_at,title_search').eq('user_id', uid).gte('created_at', dayAgo);
  if (recent.error) throw recent.error;
  const hourAgo = Date.now() - 36e5;
  if (recent.data.filter((x) => new Date(x.created_at).getTime() > hourAgo).length >= 5) {
    throw new HttpError(429, 'Bir saat içinde en fazla 5 ilan verebilirsiniz. Lütfen daha sonra tekrar deneyin.', 'RATE_LIMITED');
  }
  if (recent.data.length >= 20) throw new HttpError(429, 'Günlük ilan sınırına ulaştınız (20). Yarın tekrar deneyin.', 'RATE_LIMITED');

  const q = await quotaOf(profile);
  const s = q.settings;
  const b = body(req);
  const data = await validateInput(b, uid, s.max_photos);
  const wrongCategory = await categoryGuard(data, b);

  const dup = await supabase.from('listings').select('id').eq('user_id', uid).eq('title_search', data.title_search)
    .in('status', ['active', 'pending', 'pending_payment', 'under_review']).limit(1);
  if (dup.error) throw dup.error;
  if (dup.data.length) throw new HttpError(409, 'Aynı başlıkla yayında veya onay bekleyen bir ilanınız zaten var.', 'DUPLICATE');

  // Ücretsiz hak dolduysa ve ücretli ilan açıksa ilan ödeme bekler; ödeme doğrulanmadan yayına girmez.
  if (used(q) && s.paid_listings_enabled && s.listing_fee > 0 && !q.paid_enabled) {
    throw new HttpError(503, 'Ücretsiz ilan hakkınız doldu. Ücretli ilan için ödeme sistemi henüz etkin değil.', 'PAYTR_NOT_CONFIGURED');
  }
  const needsPayment = q.next_requires_payment;
  const flags = spamFlags({
    title: data.title, description: data.description, price: data.price,
    categoryId: data.category_id, subcategoryId: data.subcategory_id, profile, recentCount: recent.data.length,
  });
  if (wrongCategory) flags.push('kategori_uyumsuz');
  const direct = !s.moderation_enabled && !hasBlockingFlag(flags);
  const status = needsPayment ? 'pending_payment' : direct ? 'active' : 'pending';
  const now = new Date().toISOString();
  const ins = await supabase.from('listings').insert({
    ...data,
    user_id: uid,
    status,
    flags,
    is_paid: false,
    requires_payment: needsPayment,
    view_count: 0,
    report_count: 0,
    updated_at: now,
    published_at: status === 'active' ? now : null,
  }).select('id,status').single();
  if (ins.error) throw ins.error;

  const up = await supabase.from('profiles').update({
    listings_created: (profile.listings_created || 0) + 1,
    ...(flags.includes('supheli_ifade') || flags.includes('yasakli_urun_suphesi') ? { is_suspicious: true } : {}),
  }).eq('id', uid);
  if (up.error) throw up.error;

  if (ins.data.status === 'pending') await notifyAdmin({ title: 'Onay bekleyen yeni ilan', body: `“${data.title}”`, link: '/yonetim?sekme=ilanlar' }, uid);
  return res.status(201).json({ id: ins.data.id, status: ins.data.status, requires_payment: needsPayment });
}

const used = (q) => q.used >= q.free_total;

async function loadOwned(id, auth) {
  const r = await supabase.from('listings').select('*').eq('id', id).maybeSingle();
  if (r.error) throw r.error;
  if (!r.data) throw new HttpError(404, 'İlan bulunamadı.', 'NOT_FOUND');
  // Sahiplik denetimi sunucuda yapılır: kullanıcı yalnızca kendi ilanını değiştirebilir.
  if (r.data.user_id !== auth.user.id) throw new HttpError(403, 'Bu ilan size ait değil.', 'FORBIDDEN');
  return r.data;
}

async function update(req, res) {
  const auth = await requireAuth(req);
  const b = body(req);
  const l = await loadOwned(int(b.id), auth);
  if (l.status === 'under_review' || l.status === 'suspended') {
    throw new HttpError(403, 'İncelemedeki ilan düzenlenemez.', 'LOCKED');
  }
  await rateLimit(`edit:${auth.user.id}`, 40, 3600);
  const s = await getSettings();
  const data = await validateInput(b, auth.user.id, s.max_photos);

  const oldImgs = Array.isArray(l.images) ? l.images : [];
  const changed =
    data.title !== l.title || data.description !== l.description || data.category_id !== l.category_id ||
    data.subcategory_id !== l.subcategory_id || JSON.stringify(data.images) !== JSON.stringify(oldImgs);
  const flags = spamFlags({
    title: data.title, description: data.description, price: data.price,
    categoryId: data.category_id, subcategoryId: data.subcategory_id, profile: auth.profile, recentCount: 0,
  });
  // Kategori denetimi yalnızca başlık ya da kategori değiştiğinde yeniden sorulur.
  const catChanged = data.title !== l.title || data.category_id !== l.category_id;
  const wrongCategory = await categoryGuard(data, b, catChanged);
  const hadCatFlag = Array.isArray(l.flags) && l.flags.includes('kategori_uyumsuz');
  if (wrongCategory && (catChanged || (hadCatFlag && l.status !== 'active'))) flags.push('kategori_uyumsuz');
  const needsReview = s.moderation_enabled || hasBlockingFlag(flags);
  let status = l.status;
  if (l.status === 'rejected') status = needsReview ? 'pending' : 'active';
  else if ((l.status === 'active' || l.status === 'passive') && changed && needsReview) status = 'pending';
  const now = new Date().toISOString();
  const up = await supabase.from('listings').update({
    ...data,
    status,
    flags,
    reject_reason: status === 'rejected' ? l.reject_reason : null,
    updated_at: now,
    published_at: status === 'active' ? l.published_at || now : l.published_at,
  }).eq('id', l.id).eq('user_id', auth.user.id).select('id,status').single();
  if (up.error) throw up.error;
  await removeImages(oldImgs.filter((u) => !data.images.includes(u)));
  if (up.data.status === 'pending' && l.status !== 'pending') await notifyAdmin({ title: 'Düzenlenen ilan onay bekliyor', body: `“${data.title}”`, link: '/yonetim?sekme=ilanlar' }, auth.user.id);
  return res.status(200).json({ id: up.data.id, status: up.data.status });
}

async function setStatus(req, res) {
  const auth = await requireAuth(req);
  const b = body(req);
  const l = await loadOwned(int(b.id), auth);
  let next = null;
  if (b.status === 'passive' && (l.status === 'active' || l.status === 'pending')) next = 'passive';
  if (b.status === 'active' && l.status === 'passive') next = l.published_at ? 'active' : 'pending';
  if (!next) throw new HttpError(400, 'Bu ilan için bu işlem yapılamaz.');
  const up = await supabase.from('listings').update({ status: next, updated_at: new Date().toISOString() })
    .eq('id', l.id).eq('user_id', auth.user.id).select('id,status').single();
  if (up.error) throw up.error;
  return res.status(200).json(up.data);
}

async function remove(req, res) {
  const auth = await requireAuth(req, { allowBlocked: true });
  const l = await loadOwned(int(body(req).id), auth);
  await deleteListingRows([l]);
  return res.status(200).json({ ok: true });
}

export default route(async (req, res) => {
  const action = String(req.query.action || '');
  if (req.method === 'GET') {
    if (action === 'search') return search(req, res);
    if (action === 'home') return home(req, res);
    if (action === 'mine') return mine(req, res);
    if (action === 'phone') return phone(req, res);
    if (req.query.id) return detail(req, res);
    throw new HttpError(400, 'Geçersiz istek.');
  }
  if (req.method === 'POST') {
    if (action === 'view') return view(req, res);
    return create(req, res);
  }
  if (req.method === 'PUT') {
    if (action === 'status') return setStatus(req, res);
    return update(req, res);
  }
  if (req.method === 'DELETE') return remove(req, res);
  throw new HttpError(405, 'Yöntem desteklenmiyor.');
});
