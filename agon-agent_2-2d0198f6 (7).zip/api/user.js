import crypto from 'crypto';
import {
  supabase, route, HttpError, getAuth, requireAuth, getSettings, getPaytr, setSecret, isAdmin, enc, dec, sign,
  rateLimit, body, int, toCard, CARD_COLS, deleteListingRows, publicPrefix, BUCKETS, clientIp, safeEqual, ADMIN_SETUP_HASH, OWNER_USER_ID, safeAvatar, notify, notifyAdmin,
} from './_lib.js';

const REPORT_REASONS = ['sahte_ilan', 'dolandiricilik', 'yasakli_urun', 'yanlis_kategori', 'uygunsuz_icerik', 'mukerrer', 'diger'];

const REPORT_LABELS = { sahte_ilan: 'Sahte ilan', dolandiricilik: 'Dolandırıcılık şüphesi', yasakli_urun: 'Yasaklı ürün', yanlis_kategori: 'Yanlış kategori', uygunsuz_icerik: 'Uygunsuz içerik', mukerrer: 'Mükerrer ilan', diger: 'Diğer' };

function ownProfile(p, email, admin) {
  return {
    id: p.id,
    email,
    full_name: p.full_name,
    phone: dec(p.phone),
    show_phone: p.show_phone !== false,
    whatsapp: !!p.whatsapp,
    avatar_url: safeAvatar(p.avatar_url),
    country_code: p.country_code || 'TR',
    city_id: p.city_id,
    city_name: p.city_name,
    bio: p.bio,
    is_admin: admin === true,
    is_blocked: p.is_blocked === true && admin !== true,
    block_reason: p.is_blocked && admin !== true ? p.block_reason : null,
    rt_key: p.rt_key,
    listings_created: p.listings_created || 0,
    created_at: p.created_at,
  };
}

async function me(req, res) {
  const auth = await requireAuth(req, { allowBlocked: true });
  const uid = auth.user.id;
  const [convs, favs, s, paytr, admin] = await Promise.all([
    supabase.from('conversations').select('buyer_id,seller_id,buyer_unread,seller_unread').or(`buyer_id.eq.${uid},seller_id.eq.${uid}`),
    supabase.from('favorites').select('listing_id').eq('user_id', uid),
    getSettings(),
    getPaytr(),
    isAdmin(auth.profile),
  ]);
  if (convs.error) throw convs.error;
  if (favs.error) throw favs.error;
  const unread = convs.data.reduce((n, c) => n + (c.buyer_id === uid ? c.buyer_unread || 0 : c.seller_unread || 0), 0);
  const usedCount = auth.profile.listings_created || 0;
  const paidOn = !!(s.paid_listings_enabled && s.listing_fee > 0 && paytr);
  if (!auth.profile.last_seen_at || Date.now() - new Date(auth.profile.last_seen_at).getTime() > 6e5) {
    await supabase.from('profiles').update({ last_seen_at: new Date().toISOString() }).eq('id', uid);
  }
  return res.status(200).json({
    profile: { ...ownProfile(auth.profile, auth.user.email, admin), can_setup_admin: admin ? false : !(await validAdminExists()) },
    unread,
    favorite_ids: favs.data.map((f) => f.listing_id),
    quota: {
      free_total: s.free_listing_count,
      used: usedCount,
      free_left: Math.max(0, s.free_listing_count - usedCount),
      paid_enabled: paidOn,
      listing_fee: s.listing_fee,
      next_requires_payment: paidOn && usedCount >= s.free_listing_count,
    },
  });
}

async function updateProfile(req, res) {
  const auth = await requireAuth(req);
  const b = body(req);
  const full_name = String(b.full_name || '').replace(/\s+/g, ' ').trim();
  if (full_name.length < 2 || full_name.length > 60) throw new HttpError(400, 'Ad soyad 2 ile 60 karakter arasında olmalı.', 'full_name');
  let phone = String(b.phone || '').replace(/[^\d+]/g, '');
  if (phone) {
    const digits = phone.replace(/\D/g, '');
    if (digits.length < 10 || digits.length > 15) throw new HttpError(400, 'Geçerli bir telefon numarası girin.', 'phone');
    if (/^(90)?5\d{9}$/.test(digits) || /^05\d{9}$/.test(digits)) phone = `+90${digits.slice(-10)}`;
    else phone = phone.startsWith('+') ? `+${digits}` : digits;
  } else phone = null;
  const bio = String(b.bio || '').trim().slice(0, 500) || null;
  const patch = {
    full_name,
    phone: enc(phone),
    show_phone: b.show_phone !== false,
    whatsapp: !!b.whatsapp && !!phone,
    bio,
  };
  const cityId = int(b.city_id);
  if (cityId) {
    const c = await supabase.from('cities').select('id,name,country_code').eq('id', cityId).maybeSingle();
    if (c.error) throw c.error;
    if (!c.data) throw new HttpError(400, 'Seçilen şehir geçersiz.', 'city');
    patch.city_id = c.data.id;
    patch.city_name = c.data.name;
    patch.country_code = c.data.country_code;
  } else {
    patch.city_id = null;
    patch.city_name = null;
  }
  const u = await supabase.from('profiles').update(patch).eq('id', auth.user.id).select('*').single();
  if (u.error) throw u.error;
  return res.status(200).json({ profile: ownProfile(u.data, auth.user.email, await isAdmin(u.data)) });
}

async function favorites(req, res) {
  const auth = await requireAuth(req, { allowBlocked: true });
  const f = await supabase.from('favorites').select('listing_id,created_at').eq('user_id', auth.user.id).order('created_at', { ascending: false }).limit(300);
  if (f.error) throw f.error;
  const ids = f.data.map((x) => x.listing_id);
  if (!ids.length) return res.status(200).json({ items: [] });
  const l = await supabase.from('listings').select(CARD_COLS).in('id', ids);
  if (l.error) throw l.error;
  const byId = new Map(l.data.map((x) => [x.id, x]));
  return res.status(200).json({ items: ids.map((id) => byId.get(id)).filter(Boolean).map(toCard) });
}

async function toggleFavorite(req, res) {
  const auth = await requireAuth(req);
  const listingId = int(body(req).listing_id);
  if (!listingId) throw new HttpError(400, 'Geçersiz ilan.');
  const ex = await supabase.from('favorites').select('id').eq('user_id', auth.user.id).eq('listing_id', listingId);
  if (ex.error) throw ex.error;
  if (ex.data.length) {
    const d = await supabase.from('favorites').delete().eq('user_id', auth.user.id).eq('listing_id', listingId);
    if (d.error) throw d.error;
    return res.status(200).json({ favorite: false });
  }
  const l = await supabase.from('listings').select('id').eq('id', listingId).eq('status', 'active').maybeSingle();
  if (l.error) throw l.error;
  if (!l.data) throw new HttpError(404, 'İlan bulunamadı.');
  await rateLimit(`fav:${auth.user.id}`, 200, 3600);
  const i = await supabase.from('favorites').insert({ user_id: auth.user.id, listing_id: listingId });
  if (i.error) throw i.error;
  return res.status(201).json({ favorite: true });
}

async function report(req, res) {
  const auth = await requireAuth(req);
  const b = body(req);
  const listingId = int(b.listing_id);
  const reason = REPORT_REASONS.includes(b.reason) ? b.reason : null;
  const details = String(b.details || '').trim().slice(0, 1000);
  if (!listingId || !reason) throw new HttpError(400, 'Şikâyet nedeni seçin.', 'reason');
  if (reason === 'diger' && details.length < 10) throw new HttpError(400, 'Lütfen şikâyetinizi kısaca açıklayın (en az 10 karakter).', 'details');
  const l = await supabase.from('listings').select('id,title,user_id,status,report_count').eq('id', listingId).maybeSingle();
  if (l.error) throw l.error;
  if (!l.data) throw new HttpError(404, 'İlan bulunamadı.');
  if (l.data.user_id === auth.user.id) throw new HttpError(400, 'Kendi ilanınızı şikâyet edemezsiniz.');
  const ex = await supabase.from('reports').select('id').eq('listing_id', listingId).eq('reporter_id', auth.user.id).eq('status', 'open').limit(1);
  if (ex.error) throw ex.error;
  if (ex.data.length) throw new HttpError(409, 'Bu ilan için incelenmeyi bekleyen bir şikâyetiniz zaten var.');
  await rateLimit(`report:${auth.user.id}`, 10, 86400, 'Günlük şikâyet sınırına ulaştınız.');
  const ins = await supabase.from('reports').insert({
    listing_id: listingId, listing_title: l.data.title, seller_id: l.data.user_id,
    reporter_id: auth.user.id, reason, details: enc(details), status: 'open',
  });
  if (ins.error) throw ins.error;

  // Farklı kullanıcılardan 3 açık şikâyet alan ilan otomatik olarak incelemeye alınır.
  const open = await supabase.from('reports').select('reporter_id').eq('listing_id', listingId).eq('status', 'open');
  if (open.error) throw open.error;
  const distinct = new Set(open.data.map((r) => r.reporter_id)).size;
  const patch = { report_count: (l.data.report_count || 0) + 1 };
  if (distinct >= 3 && l.data.status === 'active') patch.status = 'under_review';
  await supabase.from('listings').update(patch).eq('id', listingId);
  if (distinct >= 3) await supabase.from('profiles').update({ is_suspicious: true }).eq('id', l.data.user_id);
  await notifyAdmin({ title: 'Yeni şikâyet', body: `“${l.data.title}” · ${REPORT_LABELS[reason] || reason}`, link: '/yonetim?sekme=sikayetler' }, auth.user.id);
  if (patch.status === 'under_review') {
    await notify(l.data.user_id, { type: 'listing', title: 'İlanınız incelemeye alındı', body: `“${l.data.title}” şikâyetler nedeniyle inceleniyor; inceleme bitene kadar yayında değil.`, link: `/ilan/${listingId}` });
  }
  return res.status(201).json({ ok: true });
}

async function seller(req, res) {
  const id = String(req.query.id || '');
  if (!/^[0-9a-f-]{36}$/i.test(id)) throw new HttpError(400, 'Geçersiz satıcı.');
  const p = await supabase.from('profiles').select('id,full_name,avatar_url,created_at,city_name,bio,show_phone,phone,is_blocked').eq('id', id).maybeSingle();
  if (p.error) throw p.error;
  if (!p.data || p.data.is_blocked) throw new HttpError(404, 'Satıcı bulunamadı.', 'NOT_FOUND');
  const l = await supabase.from('listings').select(CARD_COLS).eq('user_id', id).eq('status', 'active')
    .order('published_at', { ascending: false, nullsFirst: false }).limit(120);
  if (l.error) throw l.error;
  return res.status(200).json({
    seller: {
      id: p.data.id,
      full_name: p.data.full_name || 'PAZARLA üyesi',
      avatar_url: safeAvatar(p.data.avatar_url),
      created_at: p.data.created_at,
      city_name: p.data.city_name,
      bio: p.data.bio,
      has_phone: !!(p.data.show_phone && p.data.phone),
    },
    items: l.data.map(toCard),
  });
}

// Yönetici yetkisi yalnızca tek kullanımlık kurulum koduyla, giriş yapmış hesaba verilir.
async function claimAdmin(req, res) {
  const auth = await requireAuth(req);
  await rateLimit(`claim:${auth.user.id}`, 5, 3600, 'Çok fazla hatalı deneme. Bir saat sonra tekrar deneyin.');
  await rateLimit(`claim-ip:${sign(clientIp(req)).slice(0, 20)}`, 10, 3600, 'Çok fazla hatalı deneme. Bir saat sonra tekrar deneyin.');
  const code = String(body(req).code || '').trim().toUpperCase();
  if (code.length < 12) throw new HttpError(400, 'Kurulum kodunu girin.');
  if (await validAdminExists()) throw new HttpError(410, 'Yönetici kurulumu daha önce tamamlanmış. Kurulum kodu şu anda kullanılamaz.', 'ALREADY_CLAIMED');
  const given = crypto.createHash('sha256').update(code).digest('hex');
  if (!safeEqual(given, ADMIN_SETUP_HASH)) throw new HttpError(403, 'Kurulum kodu hatalı.', 'BAD_CODE');
  const u = await supabase.from('profiles').update({ is_admin: true }).eq('id', auth.user.id);
  if (u.error) throw u.error;
  await setSecret(`admin:${auth.user.id}`, sign(`admin:${auth.user.id}`));
  return res.status(200).json({ ok: true });
}

// İmzası doğrulanan bir yönetici varsa kurulum kodu kullanılamaz (tek yönetici hesabı).
async function validAdminExists() {
  if (OWNER_USER_ID) return true;
  const admins = await supabase.from('profiles').select('id,is_admin,is_blocked').eq('is_admin', true).limit(50);
  if (admins.error) throw admins.error;
  for (const p of admins.data) if (await isAdmin(p)) return true;
  return false;
}

async function adminSetupState(req, res) {
  const auth = await getAuth(req);
  return res.status(200).json({ available: !(await validAdminExists()), is_admin: auth ? await isAdmin(auth.profile) : false });
}

async function deleteAccount(req, res) {
  const auth = await requireAuth(req, { allowBlocked: true });
  const uid = auth.user.id;
  const confirm = String(body(req).confirm || '').trim().toLocaleUpperCase('tr-TR');
  if (confirm !== 'SİL' && confirm !== 'SIL') throw new HttpError(400, 'Onay için SİL yazın.', 'confirm');
  if (await isAdmin(auth.profile)) throw new HttpError(400, 'Yönetici hesabı bu ekrandan silinemez.');

  const ls = await supabase.from('listings').select('id,images').eq('user_id', uid);
  if (ls.error) throw ls.error;
  await deleteListingRows(ls.data);
  const steps = [
    supabase.from('favorites').delete().eq('user_id', uid),
    supabase.from('conversations').delete().or(`buyer_id.eq.${uid},seller_id.eq.${uid}`),
    supabase.from('reports').delete().eq('reporter_id', uid),
    supabase.from('app_secrets').delete().eq('key', `admin:${uid}`),
    supabase.from('notifications').delete().eq('user_id', uid),
  ];
  for (const r of await Promise.all(steps)) if (r.error) throw r.error;
  const av = auth.profile.avatar_url;
  const prefix = publicPrefix(BUCKETS.avatar);
  if (av && av.startsWith(prefix)) {
    try { await supabase.storage.from(BUCKETS.avatar).remove([av.slice(prefix.length)]); } catch { /* yoksay */ }
  }
  const dp = await supabase.from('profiles').delete().eq('id', uid);
  if (dp.error) throw dp.error;
  const del = await supabase.auth.admin.deleteUser(uid);
  if (del.error) throw del.error;
  return res.status(200).json({ ok: true });
}

// Bildirim listesi: kayıtlı bildirimler + okunmamış mesajı olan sohbetler (mesaj içeriği bildirime yazılmaz).
async function notifications(req, res) {
  const auth = await requireAuth(req, { allowBlocked: true });
  const uid = auth.user.id;
  const [n, c] = await Promise.all([
    supabase.from('notifications').select('id,data,is_read,created_at').eq('user_id', uid).order('id', { ascending: false }).limit(40),
    supabase.from('conversations').select('id,buyer_id,seller_id,buyer_unread,seller_unread,listing_title,last_message_at').or(`buyer_id.eq.${uid},seller_id.eq.${uid}`)
      .order('last_message_at', { ascending: false, nullsFirst: false }).limit(100),
  ]);
  if (n.error) throw n.error;
  if (c.error) throw c.error;
  const convs = c.data.filter((x) => (x.buyer_id === uid ? x.buyer_unread : x.seller_unread) > 0).slice(0, 20);
  const otherIds = [...new Set(convs.map((x) => (x.buyer_id === uid ? x.seller_id : x.buyer_id)))];
  const people = otherIds.length ? await supabase.from('profiles').select('id,full_name').in('id', otherIds) : { data: [], error: null };
  if (people.error) throw people.error;
  const names = new Map(people.data.map((p) => [p.id, p.full_name]));
  const items = convs.map((x) => {
    const count = x.buyer_id === uid ? x.buyer_unread : x.seller_unread;
    return {
      id: `m:${x.id}`,
      type: 'message',
      title: `${names.get(x.buyer_id === uid ? x.seller_id : x.buyer_id) || 'PAZARLA üyesi'} size ${count > 1 ? `${count} mesaj` : 'mesaj'} gönderdi`,
      body: x.listing_title || '',
      link: `/mesajlar/${x.id}`,
      is_read: false,
      created_at: x.last_message_at,
    };
  });
  for (const r of n.data) {
    let d = null;
    try { d = JSON.parse(dec(r.data) || 'null'); } catch { d = null; }
    if (!d || typeof d.title !== 'string') continue; // sunucunun yazmadığı kayıt yok sayılır
    const link = typeof d.link === 'string' && d.link.startsWith('/') && !d.link.startsWith('//') ? d.link : null;
    items.push({ id: `n:${r.id}`, type: String(d.type || 'info'), title: d.title, body: String(d.body || ''), link, is_read: r.is_read === true, created_at: r.created_at });
  }
  items.sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0));
  return res.status(200).json({ items, unread: items.filter((i) => !i.is_read).length });
}

async function notificationsRead(req, res) {
  const auth = await requireAuth(req, { allowBlocked: true });
  const u = await supabase.from('notifications').update({ is_read: true }).eq('user_id', auth.user.id).eq('is_read', false);
  if (u.error) throw u.error;
  return res.status(200).json({ ok: true });
}

async function notificationsClear(req, res) {
  const auth = await requireAuth(req, { allowBlocked: true });
  const d = await supabase.from('notifications').delete().eq('user_id', auth.user.id);
  if (d.error) throw d.error;
  return res.status(200).json({ ok: true });
}

export default route(async (req, res) => {
  const action = String(req.query.action || '');
  const k = `${req.method} ${action}`;
  if (k === 'GET me') return me(req, res);
  if (k === 'PUT profile') return updateProfile(req, res);
  if (k === 'GET favorites') return favorites(req, res);
  if (k === 'POST favorite') return toggleFavorite(req, res);
  if (k === 'POST report') return report(req, res);
  if (k === 'GET seller') return seller(req, res);
  if (k === 'GET admin-setup') return adminSetupState(req, res);
  if (k === 'POST claim-admin') return claimAdmin(req, res);
  if (k === 'DELETE account') return deleteAccount(req, res);
  if (k === 'GET notifications') return notifications(req, res);
  if (k === 'PUT notifications') return notificationsRead(req, res);
  if (k === 'DELETE notifications') return notificationsClear(req, res);
  throw new HttpError(400, 'Geçersiz istek.');
});
