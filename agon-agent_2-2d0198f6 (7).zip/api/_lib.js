import crypto from 'crypto';
import { createClient } from '@supabase/supabase-js';
import supabase from './db-client.js';

export { supabase };

// Hata ayrıntılarını istemciye göstermek için (yalnızca geliştirme sırasında true yapılır)
export const DEBUG_ERRORS = false;

// Yönetici kurulum kodunun SHA-256 özeti. Kodun kendisi hiçbir yerde saklanmaz; yalnızca site sahibinde bulunur.
export const ADMIN_SETUP_HASH = '246ac9b664869258749f87350a54d1babb5a9d0573fffbe82721af0f5fbb9e28';

/* ----------------------------------------------- sunucu tarafı şifreleme */
// Anahtar yalnızca sunucuda bulunur (APP_ENCRYPTION_KEY ya da servis anahtarından türetilir); istemciye asla gönderilmez.
// Veritabanı satırları bir şekilde okunsa bile mesajlar, telefonlar ve PayTR bilgileri çözülemez; yönetici yetkisi sahte üretilemez.
const SERVER_KEY = crypto
  .createHash('sha256')
  .update(`pazarla:v1:${process.env.APP_ENCRYPTION_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY || ''}`)
  .digest();

export function enc(plain) {
  if (plain === null || plain === undefined || plain === '') return null;
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', SERVER_KEY, iv);
  const data = Buffer.concat([c.update(String(plain), 'utf8'), c.final()]);
  return `v1.${iv.toString('base64url')}.${c.getAuthTag().toString('base64url')}.${data.toString('base64url')}`;
}

export function dec(value) {
  if (value === null || value === undefined || value === '') return null;
  const s = String(value);
  if (!s.startsWith('v1.')) return null; // sunucunun şifrelemediği değer güvenilmezdir
  try {
    const [, iv, tag, data] = s.split('.');
    const d = crypto.createDecipheriv('aes-256-gcm', SERVER_KEY, Buffer.from(iv, 'base64url'));
    d.setAuthTag(Buffer.from(tag, 'base64url'));
    return Buffer.concat([d.update(Buffer.from(data, 'base64url')), d.final()]).toString('utf8');
  } catch {
    return null;
  }
}

export const sign = (text) => crypto.createHmac('sha256', SERVER_KEY).update(String(text)).digest('hex');

export const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
export const BUCKETS = { listing: 'listing-photos', avatar: 'avatars', banner: 'banners' };
export const publicPrefix = (bucket) => `${SUPABASE_URL}/storage/v1/object/public/${bucket}/`;

export class HttpError extends Error {
  constructor(status, message, code, extra) {
    super(message);
    this.status = status;
    this.code = code;
    this.extra = extra;
  }
}

export function route(fn) {
  return async (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    if (req.method === 'OPTIONS') return res.status(204).end();
    try {
      await fn(req, res);
    } catch (err) {
      if (err instanceof HttpError) {
        return res.status(err.status).json({ error: err.message, code: err.code, ...(err.extra || {}) });
      }
      console.error('API error:', err);
      const out = { error: 'Sunucu hatası oluştu. Lütfen biraz sonra tekrar deneyin.' };
      if (DEBUG_ERRORS) out.detail = String(err?.message || err);
      return res.status(500).json(out);
    }
  };
}

export const int = (v, def = null) => {
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? n : def;
};

export function body(req) {
  const b = req.body;
  if (!b) return {};
  if (typeof b === 'string') {
    try { return JSON.parse(b); } catch { return {}; }
  }
  return b;
}

export const clientIp = (req) =>
  String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket?.remoteAddress || '0.0.0.0';

export const originOf = (req) => `https://${req.headers['x-forwarded-host'] || req.headers.host}`;

// Türkçe karakter duyarsız arama için metni sadeleştirir
export const norm = (s) =>
  String(s || '')
    .replace(/İ/g, 'i').replace(/I/g, 'i')
    .toLowerCase()
    .replace(/ç/g, 'c').replace(/ğ/g, 'g').replace(/ı/g, 'i')
    .replace(/ö/g, 'o').replace(/ş/g, 's').replace(/ü/g, 'u')
    .replace(/â/g, 'a').replace(/î/g, 'i').replace(/û/g, 'u')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

export const check = (r) => {
  if (r.error) throw r.error;
  return r.data;
};

/* ---------------------------------------------------------------- auth */

async function ensureProfile(user) {
  const found = await supabase.from('profiles').select('*').eq('id', user.id).maybeSingle();
  if (found.error) throw found.error;
  if (found.data) return found.data;
  const meta = user.user_metadata || {};
  const row = {
    id: user.id,
    full_name: String(meta.full_name || meta.name || '').slice(0, 60) || null,
    avatar_url: typeof meta.avatar_url === 'string' && meta.avatar_url.startsWith('https://') ? meta.avatar_url : null,
    rt_key: crypto.randomBytes(18).toString('hex'),
  };
  const ins = await supabase.from('profiles').insert(row).select().maybeSingle();
  if (ins.data) return ins.data;
  const again = await supabase.from('profiles').select('*').eq('id', user.id).maybeSingle();
  if (again.data) return again.data;
  throw ins.error || new Error('profile could not be created');
}

export async function getAuth(req) {
  const h = String(req.headers.authorization || '');
  const token = h.startsWith('Bearer ') ? h.slice(7).trim() : null;
  if (!token) return null;
  const { data, error } = await supabase.auth.getUser(token);
  if (error || !data?.user) return null;
  const profile = await ensureProfile(data.user);
  return { user: data.user, profile };
}

export async function requireAuth(req, { allowBlocked = false } = {}) {
  const a = await getAuth(req);
  if (!a) throw new HttpError(401, 'Bu işlem için giriş yapmalısınız.', 'UNAUTHORIZED');
  if (a.profile.is_blocked && !allowBlocked && a.user.id !== OWNER_USER_ID) {
    throw new HttpError(403, 'Hesabınız engellenmiştir. Bu işlemi yapamazsınız.', 'BLOCKED');
  }
  return a;
}

// Yönetici yetkisi yalnızca profildeki işarete güvenilerek verilmez: sunucu anahtarıyla imzalanmış yetki kaydı da doğrulanır.
// Böylece profil satırı değiştirilse bile sahte yönetici oluşturulamaz.
// Site sahibinin hesabı. Tanımlıyken yönetici YALNIZCA bu hesaptır: veritabanındaki hiçbir kayıt ya da kurulum kodu
// başka bir hesaba yönetici yetkisi veremez. Yöneticiyi değiştirmek için bu değer güncellenip yeniden yayınlanır.
// Kendi kurulumunuzda: Vercel'de OWNER_USER_ID ortam değişkenine kendi kullanıcı kimliğinizi (Supabase → Authentication →
// Users → User UID) yazın. Değişken tanımlı değilse yönetici, /yonetici-kurulum sayfasındaki kurulum koduyla belirlenir.
const FIRST_SITE_OWNER = String(SUPABASE_URL || '').includes('nngpkocajdsxmzkobdzm') ? '216f78e0-c0fa-49c9-89cb-69c59e19d08d' : '';
const ownerInput = String(process.env.OWNER_USER_ID ?? FIRST_SITE_OWNER).trim().toLowerCase();
export const OWNER_USER_ID = /^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$/.test(ownerInput) ? ownerInput : '';

export async function isAdmin(profile) {
  if (!profile) return false;
  if (OWNER_USER_ID) return profile.id === OWNER_USER_ID;
  if (profile.is_admin !== true || profile.is_blocked === true) return false;
  const { data, error } = await supabase.from('app_secrets').select('value').eq('key', `admin:${profile.id}`).maybeSingle();
  if (error) throw error;
  return !!data?.value && safeEqual(data.value, sign(`admin:${profile.id}`));
}

export async function requireAdmin(req) {
  const a = await requireAuth(req);
  if (!(await isAdmin(a.profile))) throw new HttpError(403, 'Bu alana erişim yetkiniz yok.', 'FORBIDDEN');
  return a;
}

/* ------------------------------------------------------------ settings */

export const SETTING_DEFAULTS = {
  free_listing_count: 3,
  paid_listings_enabled: false,
  listing_fee: 0,
  featured_sales_enabled: false,
  featured_fee: 0,
  featured_days: 7,
  showcase_sales_enabled: false,
  showcase_fee: 0,
  showcase_days: 7,
  moderation_enabled: false,
  max_photos: 12,
  ads: { enabled: false, client: '', slots: {} },
  house_ads: {},
  banners_sig: '',
  android_fingerprints: [],
  company_name: '',
  company_address: '',
  contact_email: '',
  contact_phone: '',
};

export const AD_PLACEMENTS = ['home_desktop', 'home_mobile', 'category_desktop', 'category_mobile', 'detail_desktop', 'detail_mobile'];

export async function getSettings() {
  const { data, error } = await supabase.from('settings').select('key,value');
  if (error) throw error;
  const s = { ...SETTING_DEFAULTS };
  for (const r of data || []) {
    if (!(r.key in SETTING_DEFAULTS)) continue;
    const v = unpackSetting(r.key, r.value);
    if (v !== undefined) s[r.key] = v; // imzası geçersiz kayıt yok sayılır, güvenli varsayılan kullanılır
  }
  return s;
}

// Ayarlar sunucu anahtarıyla imzalanarak saklanır. Veritabanına sunucu dışından yazılan ya da değiştirilen bir ayar
// (ücretler, reklam kodları, reklam alanları, onay kuralı) imzası tutmadığı için uygulanmaz.
const packSetting = (key, value) => {
  const d = JSON.stringify(value);
  return { d, s: sign(`setting:${key}:${d}`) };
};
function unpackSetting(key, raw) {
  if (!raw || typeof raw !== 'object' || typeof raw.d !== 'string' || typeof raw.s !== 'string') return undefined;
  if (!safeEqual(raw.s, sign(`setting:${key}:${raw.d}`))) return undefined;
  try { return JSON.parse(raw.d); } catch { return undefined; }
}
export const settingRow = (key, value) => ({ key, value: packSetting(key, value), updated_at: new Date().toISOString() });

// Banner kayıtlarının tamamı için sunucu imzası: tablo dışarıdan değiştirilirse bannerlar sitede gösterilmez.
export const bannersDigest = (rows) =>
  sign(`banners:${JSON.stringify([...(rows || [])].sort((a, b) => a.id - b.id)
    .map((b) => [b.id, b.title || '', b.subtitle || '', b.image_url || '', b.link_url || '', b.cta_label || '', b.is_active !== false, b.sort_order || 0]))}`);

/* --------------------------------------------- veritabanından gelen adresler */
// Veritabanındaki adresler olduğu gibi sayfaya basılmaz: yalnızca kendi depolama alanımızdaki görseller ve güvenli bağlantılar geçer.
const inBucket = (u, bucket) => typeof u === 'string' && u.startsWith(publicPrefix(bucket)) && /^[\w\-/.]+$/.test(u.slice(publicPrefix(bucket).length));
export const safeListingImage = (u) => (inBucket(u, BUCKETS.listing) ? u : null);
export const listingImages = (arr) => (Array.isArray(arr) ? arr : []).filter((u) => inBucket(u, BUCKETS.listing));
export const safeBannerImage = (u) => (inBucket(u, BUCKETS.banner) ? u : null);
export const safeAvatar = (u) => (inBucket(u, BUCKETS.avatar) || (typeof u === 'string' && /^https:\/\/[a-z0-9-]+\.googleusercontent\.com\/[\w\-/.=]+$/.test(u)) ? u : null);
export const safeLink = (u) => (typeof u === 'string' && ((u.startsWith('/') && !u.startsWith('//')) || /^https:\/\/[^\s<>"']+$/.test(u)) ? u : null);

export async function getSecret(key) {
  const { data, error } = await supabase.from('app_secrets').select('value').eq('key', key).maybeSingle();
  if (error) throw error;
  return data?.value ?? null;
}

export async function setSecret(key, value) {
  const { error } = await supabase
    .from('app_secrets')
    .upsert({ key, value, updated_at: new Date().toISOString() }, { onConflict: 'key' });
  if (error) throw error;
}

export async function deleteSecret(key) {
  const { error } = await supabase.from('app_secrets').delete().eq('key', key);
  if (error) throw error;
}

/* --------------------------------------------------------------- PayTR */

// PayTR mağaza bilgileri: ortam değişkenleri (PAYTR_MERCHANT_ID/KEY/SALT) veya yönetici panelinden girilen gizli kayıt.
export async function getPaytr() {
  const e = process.env;
  if (e.PAYTR_MERCHANT_ID && e.PAYTR_MERCHANT_KEY && e.PAYTR_MERCHANT_SALT) {
    return {
      merchant_id: e.PAYTR_MERCHANT_ID,
      merchant_key: e.PAYTR_MERCHANT_KEY,
      merchant_salt: e.PAYTR_MERCHANT_SALT,
      test_mode: e.PAYTR_TEST_MODE === '1',
      source: 'env',
    };
  }
  const raw = dec(await getSecret('paytr'));
  if (!raw) return null;
  try {
    const c = JSON.parse(raw);
    if (c.merchant_id && c.merchant_key && c.merchant_salt) return { ...c, test_mode: !!c.test_mode, source: 'panel' };
  } catch { /* geçersiz kayıt */ }
  return null;
}

export function paytrRequestToken(cfg, f) {
  const hashStr =
    cfg.merchant_id + f.user_ip + f.merchant_oid + f.email + f.payment_amount + f.user_basket +
    f.no_installment + f.max_installment + f.currency + f.test_mode;
  return crypto.createHmac('sha256', cfg.merchant_key).update(hashStr + cfg.merchant_salt).digest('base64');
}

export function paytrCallbackHash(cfg, merchant_oid, status, total_amount) {
  return crypto
    .createHmac('sha256', cfg.merchant_key)
    .update(String(merchant_oid) + cfg.merchant_salt + String(status) + String(total_amount))
    .digest('base64');
}

export function safeEqual(a, b) {
  const x = Buffer.from(String(a));
  const y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

export function publicSettings(s, paytrReady) {
  const ads = s.ads || {};
  const adsOn = !!(ads.enabled && ads.client);
  return {
    free_listing_count: s.free_listing_count,
    paid_listings_enabled: !!(s.paid_listings_enabled && paytrReady && s.listing_fee > 0),
    listing_fee: s.listing_fee,
    featured_sales_enabled: !!(s.featured_sales_enabled && paytrReady && s.featured_fee > 0),
    featured_fee: s.featured_fee,
    featured_days: s.featured_days,
    showcase_sales_enabled: !!(s.showcase_sales_enabled && paytrReady && s.showcase_fee > 0),
    showcase_fee: s.showcase_fee,
    showcase_days: s.showcase_days,
    moderation_enabled: !!s.moderation_enabled,
    max_photos: s.max_photos,
    paytr_ready: !!paytrReady,
    // Yayıncı kimliği gizli değildir; reklamlar kapalıyken de gönderilir (site doğrulaması ve yönetici notları için).
    ads: /^ca-pub-\d{10,20}$/.test(ads.client || '') ? { enabled: adsOn, client: ads.client, slots: adsOn ? ads.slots || {} : {} } : { enabled: false, client: '', slots: {} },
    // Kendi reklam alanları: yalnızca etkin ve görseli olanlar istemciye gönderilir.
    house_ads: Object.fromEntries(Object.entries(s.house_ads || {}).filter(([, v]) => v && v.is_active && v.image_url)),
    company_name: s.company_name,
    company_address: s.company_address,
    contact_email: /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(s.contact_email || '')) ? s.contact_email : '',
    contact_phone: s.contact_phone,
  };
}

/* ---------------------------------------------------------- rate limit */

export async function rateLimit(key, max, windowSec, message) {
  const now = Date.now();
  const { data, error } = await supabase.from('rate_limits').select('*').eq('key', key).maybeSingle();
  if (error) throw error;
  if (!data || new Date(data.reset_at).getTime() < now) {
    const up = await supabase
      .from('rate_limits')
      .upsert({ key, count: 1, reset_at: new Date(now + windowSec * 1000).toISOString() }, { onConflict: 'key' });
    if (up.error) throw up.error;
    return;
  }
  if (data.count >= max) {
    throw new HttpError(429, message || 'Çok fazla istek gönderdiniz. Lütfen biraz bekleyip tekrar deneyin.', 'RATE_LIMITED');
  }
  const up = await supabase.from('rate_limits').update({ count: data.count + 1 }).eq('key', key);
  if (up.error) throw up.error;
}

/* ------------------------------------------------------------ listings */

export const CARD_COLS =
  'id,user_id,title,price,currency,country_code,city_name,district_name,condition,images,created_at,published_at,featured_until,showcase_until,view_count,category_id,subcategory_id,status';

export const thumbOf = (url) => (typeof url === 'string' ? url.replace(/\.jpg$/, '_t.jpg') : null);

export function toCard(l) {
  const now = Date.now();
  const imgs = listingImages(l.images);
  return {
    id: l.id,
    user_id: l.user_id,
    title: l.title,
    price: Number(l.price),
    currency: l.currency,
    country_code: l.country_code,
    city_name: l.city_name,
    district_name: l.district_name,
    condition: l.condition,
    cover: thumbOf(imgs[0]),
    photo_count: imgs.length,
    date: l.published_at || l.created_at,
    view_count: l.view_count || 0,
    category_id: l.category_id,
    subcategory_id: l.subcategory_id,
    status: l.status,
    is_featured: !!(l.featured_until && new Date(l.featured_until).getTime() > now),
    is_showcase: !!(l.showcase_until && new Date(l.showcase_until).getTime() > now),
  };
}

export async function removeImages(urls, bucket = BUCKETS.listing) {
  const prefix = publicPrefix(bucket);
  const paths = [];
  for (const u of urls || []) {
    if (typeof u === 'string' && u.startsWith(prefix)) {
      const p = u.slice(prefix.length);
      paths.push(p, p.replace(/\.jpg$/, '_t.jpg'));
    }
  }
  if (paths.length) {
    try { await supabase.storage.from(bucket).remove(paths); } catch (e) { console.error('storage remove', e); }
  }
}

export async function deleteListingRows(listings) {
  if (!listings.length) return;
  await removeImages(listings.flatMap((l) => (Array.isArray(l.images) ? l.images : [])));
  const { error } = await supabase.from('listings').delete().in('id', listings.map((l) => l.id));
  if (error) throw error;
}

// Spam / sahte ilan sinyalleri. Dönen her işaret ilanı yönetici incelemesine düşürür.
export function spamFlags({ title, description, price, categoryId, subcategoryId, profile, recentCount }) {
  const flags = [];
  const raw = `${title}\n${description}`;
  const t = norm(raw);
  if (/(western union|moneygram|kapora|on odeme|pesin havale|iban|kripto|bitcoin|usdt|bahis|casino|kumar|escort|telegram|whatsapp tan yaz|kazanc garantili|hemen zengin)/.test(t)) flags.push('supheli_ifade');
  if (/(silah|tabanca|tufek|mermi|fisek|uyusturucu|esrar|kokain|sahte para|sahte kimlik|sahte diploma|sahte ehliyet|organ sat|recetesiz ilac|tutun|sigara|alkol|viski|raki|votka)/.test(t)) flags.push('yasakli_urun_suphesi');
  if (/(https?:\/\/|www\.|\bt\.me\/|\bwa\.me\/)/i.test(raw)) flags.push('baglanti_iceriyor');
  if (/(?:\+?90|0)?\s*5\d{2}[\s.\-]?\d{3}[\s.\-]?\d{2}[\s.\-]?\d{2}/.test(title)) flags.push('baslikta_telefon');
  const letters = title.replace(/[^A-Za-zÇĞİÖŞÜçğıöşü]/g, '');
  if (letters.length >= 12) {
    const upper = letters.replace(/[^A-ZÇĞİÖŞÜ]/g, '').length;
    if (upper / letters.length > 0.8) flags.push('buyuk_harf');
  }
  if (/(.)\1{6,}/.test(raw)) flags.push('tekrarli_karakter');
  if (categoryId === 1 && [101, 102, 103, 104, 105, 106, 107].includes(subcategoryId) && price < 20000) flags.push('supheli_dusuk_fiyat');
  if (categoryId === 3 && [301, 303, 305, 309].includes(subcategoryId) && price < 100000) flags.push('supheli_dusuk_fiyat');
  const ageH = (Date.now() - new Date(profile.created_at).getTime()) / 36e5;
  if (ageH < 24 && recentCount >= 3) flags.push('yeni_hesap_cok_ilan');
  if (profile.is_suspicious) flags.push('supheli_kullanici');
  return flags;
}

// Biçimle ilgili hafif işaretler (büyük harf, tekrarlı karakter) ilanı bekletmez; yalnızca yönetici ekranında gösterilir.
const SOFT_FLAGS = ['buyuk_harf', 'tekrarli_karakter'];
export const hasBlockingFlag = (flags) => (Array.isArray(flags) ? flags : []).some((f) => !SOFT_FLAGS.includes(f));

/* ------------------------------------------------------------ realtime */

// Alıcının gizli kanalına yalnızca "yeni mesaj var" sinyali gönderir; mesaj içeriği kanaldan geçmez.
export async function signalUser(rtKey, payload) {
  if (!rtKey) return;
  let ch;
  try {
    ch = supabase.channel(`rt-${rtKey}`);
    await Promise.race([
      ch.httpSend('msg', payload),
      new Promise((resolve) => setTimeout(resolve, 2500)),
    ]);
  } catch (e) {
    console.error('realtime signal', e?.message || e);
  } finally {
    try { if (ch) await supabase.removeChannel(ch); } catch { /* yoksay */ }
  }
}

/* ---------------------------------------------------------- bildirimler */

// Kullanıcıya uygulama içi bildirim yazar ve anlık sinyal gönderir. İçerik şifreli saklanır; sunucunun
// şifrelemediği (veritabanına dışarıdan eklenen) bildirimler gösterilmez. Bildirim hatası ana işlemi asla bozmaz.
export async function notify(userId, { type, title, body = '', link = null }) {
  if (!userId || !title) return;
  try {
    const data = enc(JSON.stringify({ type, title: String(title).slice(0, 120), body: String(body || '').slice(0, 300), link }));
    const ins = await supabase.from('notifications').insert({ user_id: userId, data, is_read: false });
    if (ins.error) throw ins.error;
    const p = await supabase.from('profiles').select('rt_key').eq('id', userId).maybeSingle();
    await signalUser(p.data?.rt_key, { kind: 'notif' });
  } catch (e) {
    console.error('notify', e?.message || e);
  }
}

// Site sahibine (yönetici) bildirim; işlemi yapan kişi yöneticinin kendisiyse gönderilmez.
export const notifyAdmin = (payload, exceptUserId) =>
  OWNER_USER_ID && OWNER_USER_ID !== exceptUserId ? notify(OWNER_USER_ID, { type: 'admin', ...payload }) : Promise.resolve();

/* ------------------------------------------------- Android uygulaması */

// Google Play paket adı ve yükleme (upload) anahtarının SHA-256 parmak izi. İkisi de gizli değildir.
// Google Play'in uygulamayı imzaladığı anahtarın parmak izi yönetim panelinden eklenir (ayar: android_fingerprints).
export const ANDROID_PACKAGE = 'com.pazarla.app';
export const ANDROID_UPLOAD_FINGERPRINT = 'BA:C8:80:E7:B7:3A:53:E6:DB:DF:CB:8E:01:FB:44:63:08:2D:C6:15:8F:0F:BE:A3:CE:73:BB:76:D7:DC:53:E1';
export const FINGERPRINT_RE = /^([0-9A-F]{2}:){31}[0-9A-F]{2}$/;

/* ------------------------------------------- veritabanına doğrudan erişim */

// Uygulamanın bütün tabloları. YENİ TABLO EKLENİRSE: bu listeye eklenmeli ve tablo dış erişime kapatılmalıdır
// (kendi projede: supabase/1-tablolar.sql'deki gibi yetkiler geri alınır; hazır "herkese izin ver" kuralı olan
// veritabanında: tabloya, tablonun kendisini sorgulayan "dogrudan_erisim_kapali" kuralı eklenir).
export const DB_TABLES = ['app_secrets', 'rate_limits', 'settings', 'profiles', 'listings', 'favorites', 'conversations', 'messages',
  'reports', 'payments', 'banners', 'categories', 'countries', 'cities', 'districts', 'notifications'];

// Canlı denetim: herkese açık (anon) anahtarla her tablo doğrudan okunmaya ve iki tabloya yazılmaya çalışılır.
// Veritabanı kapalıysa hiçbir tablo satır döndürmez ve hiçbir yazma kabul edilmez.
export async function rlsSelfCheck() {
  try {
    const anon = createClient(SUPABASE_URL, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY, { auth: { persistSession: false, autoRefreshToken: false } });
    const probeUser = '00000000-0000-4000-8000-000000000000';
    const [write, write2, ...reads] = await Promise.all([
      anon.from('rate_limits').insert({ key: 'rls-self-check', count: 0 }).select('key'),
      anon.from('notifications').insert({ user_id: probeUser, data: 'rls-self-check' }).select('id'),
      ...DB_TABLES.map((t) => anon.from(t).select('*').limit(1)),
    ]);
    if (!write.error) await supabase.from('rate_limits').delete().eq('key', 'rls-self-check');
    if (!write2.error) await supabase.from('notifications').delete().eq('user_id', probeUser);
    const openTables = DB_TABLES.filter((t, i) => !reads[i].error && (reads[i].data || []).length > 0);
    const readBlocked = openTables.length === 0;
    const writeBlocked = !!write.error && !!write2.error;
    return { checked: true, enforced: readBlocked && writeBlocked, private_read_blocked: readBlocked, direct_write_blocked: writeBlocked, tables_checked: DB_TABLES.length, open_tables: openTables };
  } catch {
    return { checked: false, enforced: false, private_read_blocked: false, direct_write_blocked: false, tables_checked: 0, open_tables: [] };
  }
}
