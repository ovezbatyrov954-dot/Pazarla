// Android yükleme anahtarının (.jks) şifresi. Yalnızca yöneticiye, sunucu üzerinden gösterilir; istemci koduna girmez.
export const ANDROID_KEY_PASSWORD = 'zcypyiWjkDhIlmyboZ35BDro';
