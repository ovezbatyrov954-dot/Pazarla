# PAZARLA — Google Play yayın rehberi

Google Play Console'a yükleyeceğiniz dosyalar ve adım adım yapılacaklar.

## Dosyalar

| Dosya | Play Console'da nereye |
| --- | --- |
| `pazarla-1.0.1.aab` | **Uygulama paketi.** Test ve yayınlama → Dahili test (ya da Kapalı test) → Yeni sürüm oluştur → "Uygulama paketleri" alanına yüklenir |
| `simge-512x512.png` | Mağaza girişi → Uygulama simgesi (512×512) |
| `one-cikan-gorsel-1024x500.png` | Mağaza girişi → Öne çıkan görsel (1024×500) |
| `ekran-1 … ekran-4 (.png)` | Mağaza girişi → Telefon ekran görüntüleri (1080×1920; en az 2 tane gerekir) |
| `MAGAZA-METINLERI.txt` | Uygulama adı, kısa açıklama, tam açıklama, gizlilik politikası ve hesap silme adresleri (kopyala–yapıştır) |
| `pazarla-upload-key.jks` | **Yükleme (imza) anahtarı. Play Console'a yüklenmez; saklayın.** Uygulamanın sonraki sürümleri de aynı anahtarla imzalanmalıdır |
| `android-proje/` (zip içinde) | Uygulamanın kaynak kodu; paketi yeniden üretmek gerekirse kullanılır |

Anahtarın şifresi bu dosyalarda yoktur. PAZARLA sitesinde **Yönetim paneli → Google Play** sekmesinde, yalnızca yönetici
hesabına gösterilir. Şifreyi bir yere not edin ve `.jks` dosyasıyla birlikte güvenli bir yerde saklayın.

## Uygulama nasıl çalışır?

Uygulama, PAZARLA sitesini adres çubuğu olmadan tam ekran açan bir Android uygulamasıdır (Trusted Web Activity).
Ayrı bir veritabanı yoktur: uygulama, sitenin kullandığı **gerçek veritabanını** kullanır. Sitede yaptığınız her
değişiklik (yeni özellik, tasarım, kategori, reklam) uygulamada da kendiliğinden görünür; bunun için Play'e yeni sürüm yüklemek gerekmez.

- Paket adı: `com.pazarla.app` (Google Play'de kalıcıdır, sonradan değiştirilemez)
- Sürüm: 1.0.1 (sürüm kodu 2) · Hedef: Android 16 (API 36) · En düşük: Android 7.0 (API 24)
- İstenen tek izin: bildirim gönderme
- Açtığı adres: `https://pazarla-gw4z.arcada.app`

**Site adresi değişirse** (ör. kendi alan adınız) uygulamanın yeni adresle yeniden üretilip Play'e güncelleme olarak
yüklenmesi gerekir. Paket adı ve anahtar aynı kalır; adres `android-proje/gradle.properties` dosyasındaki `twaHost` satırındadır.

## 1. Geliştirici hesabı

play.google.com/console adresinden Google Play geliştirici hesabı açın (tek seferlik kayıt ücreti vardır, kimlik doğrulaması istenir).
Yeni açılan **bireysel** hesaplarda Google, uygulamayı herkese açmadan önce belirli sayıda test kullanıcısıyla belirli bir süre
**kapalı test** yapılmasını ister; güncel sayı ve süre Play Console'da gösterilir.

Dosya yükleme işlemleri bilgisayardaki bir tarayıcıdan en rahat şekilde yapılır.

## 2. Uygulamayı oluşturun ve AAB dosyasını yükleyin

1. Play Console → **Uygulama oluştur** → ad: PAZARLA · dil: Türkçe · tür: Uygulama · Ücretsiz.
2. **Test ve yayınlama → Dahili test** (ya da Kapalı test) → **Yeni sürüm oluştur**.
3. "Play Uygulama İmzalama" sorulursa kabul edin (önerilen ayar).
4. `pazarla-1.0.1.aab` dosyasını yükleyin → kaydedin → incelemeye gönderin.

## 3. ÇOK ÖNEMLİ: imza parmak izini siteye ekleyin

Google Play, uygulamayı kendi anahtarıyla yeniden imzalar. Sitenin bu anahtarı tanıması gerekir; yoksa uygulama
çalışır ama **üstte tarayıcı adres çubuğu görünür**.

1. Play Console → **Test ve yayınlama → Uygulama bütünlüğü → Uygulama imzalama** (App signing).
2. "Uygulama imzalama anahtarı sertifikası" altındaki **SHA-256 sertifika parmak izi** değerini kopyalayın.
3. PAZARLA sitesinde **Yönetim paneli → Google Play** sekmesindeki kutuya yapıştırın → **Parmak izini kaydet**.

Birkaç dakika sonra uygulamayı telefondan kaldırıp yeniden yükleyin; adres çubuğu kaybolmalıdır.

## 4. Mağaza sayfası ve zorunlu formlar

Play Console'daki "Uygulamanızı ayarlayın" listesindeki her madde doldurulmalıdır. Metinler ve adresler `MAGAZA-METINLERI.txt` dosyasında hazırdır.

- **Gizlilik politikası adresi:** `https://pazarla-gw4z.arcada.app/gizlilik`
- **Hesap silme adresi** (Veri güvenliği formunda sorulur): `https://pazarla-gw4z.arcada.app/hesap-silme`
- **Uygulama erişimi:** "Bazı işlevler kısıtlı" seçin ve Google'ın inceleme ekibi için bir **test hesabı** (e-posta + şifre) verin.
  İlan verme, mesajlaşma ve favoriler giriş gerektirir. Kendi yönetici hesabınızı vermeyin; ayrı bir üyelik açın.
- **Reklamlar:** Yönetim panelinden reklam (kendi reklamınız ya da Google reklamı) yayınlıyorsanız "Evet, reklam içeriyor".
- **İçerik derecelendirmesi:** anketi doldurun. Uygulamada kullanıcıların oluşturduğu içerik (ilan, fotoğraf) ve
  kullanıcılar arası mesajlaşma **vardır**; bu soruları "Evet" olarak yanıtlayın.
- **Hedef kitle:** 18 yaş ve üzeri (kullanım koşullarında üyelik 18 yaş şartına bağlıdır).
- **Veri güvenliği formu** — uygulamanın topladığı veriler:

  | Veri | Toplanıyor mu | Amaç |
  | --- | --- | --- |
  | Ad, e-posta adresi | Evet (zorunlu) | Hesap yönetimi |
  | Telefon numarası | Evet (isteğe bağlı) | Uygulama işlevi — alıcıların satıcıya ulaşması |
  | Fotoğraflar | Evet (ilan ve profil fotoğrafı) | Uygulama işlevi |
  | Uygulama içi mesajlar | Evet | Uygulama işlevi |
  | Diğer kullanıcı içeriği (ilan metni) | Evet | Uygulama işlevi |
  | Yaklaşık konum | Hayır (kullanıcı il/ilçeyi listeden kendisi seçer) | — |

  Veriler aktarım sırasında şifrelenir (HTTPS): **Evet**. Kullanıcı verilerinin silinmesini isteyebilir: **Evet** (uygulama içinden).
  Google reklamlarını açarsanız reklam amaçlı veri paylaşımını da beyan etmeniz gerekir.
- **Mağaza girişi:** uygulama adı, kısa açıklama, tam açıklama, simge, öne çıkan görsel ve ekran görüntüleri.
  Hazır ekran görüntüleri uygulamanın genel ekranlarını gösterir; dilerseniz kendi telefonunuzdan aldığınız görüntüleri ekleyin.

## 5. Yayından önce bilmeniz gerekenler

- **Ödemeler:** Google Play, uygulama içinde satılan dijital hizmetlerde (ör. ilanı öne çıkarma, vitrin, ücretli ilan)
  genellikle kendi ödeme sistemini (Play Billing) şart koşar. Bu uygulamada ödemeler PayTR ile planlanmıştır ve şu an kapalıdır.
  Ücretli özellikleri açmadan önce Google Play Ödemeler politikasını inceleyin; aksi halde uygulama reddedilebilir ya da kaldırılabilir.
- **Kullanıcı içeriği:** Google, ilan gibi kullanıcı içeriği barındıran uygulamalarda şikâyet etme ve denetim düzeni ister.
  Uygulamada ilan şikâyet etme, ilan kaldırma ve kullanıcı engelleme (yönetici tarafından) vardır.
  İnceleme sırasında kullanıcının başka bir kullanıcıyı kendisinin engelleyebilmesi de istenebilir; bu özellik henüz yoktur.
- **Reklamlar:** Google AdMob kimlikleri bu uygulamada çalışmaz; uygulama siteyi gösterdiği için Google AdSense kullanılır.
- **Veritabanı güvenliği:** Yönetim paneli → "Kurulum ve güvenlik" sekmesindeki denetimin iki satırı da "engelli" göstermelidir.
- Google'ın incelemesi birkaç gün sürebilir; onay garantisi verilemez.

## Sonraki sürümler

Site güncellemeleri için yeni sürüm gerekmez. Uygulamanın kendisini (ad, simge, site adresi) değiştirmek için
`android-proje/gradle.properties` içinde `appVersionCode` değeri bir artırılır ve paket aynı anahtarla yeniden üretilir:

```
./gradlew bundleRelease -PuploadStoreFile=/tam/yol/pazarla-upload-key.jks -PuploadStorePassword=ŞİFRENİZ
```

Çıktı: `app/build/outputs/bundle/release/app-release.aab`. (Bilgisayarda JDK 17 ve Android SDK gerekir.)
