import { lazy, Suspense, useEffect } from 'react';
import { BrowserRouter, Outlet, Route, Routes, useLocation } from 'react-router-dom';
import { ShieldAlert } from 'lucide-react';
import { AppProvider, useApp } from './contexts/AppContext';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Header from './components/Header';
import Footer from './components/Footer';
import MobileNav from './components/MobileNav';
import CookieNotice from './components/CookieNotice';
import ProtectedRoute from './components/ProtectedRoute';
import { ErrorBox, PageLoader } from './components/ui';
import Home from './pages/Home';
import SearchPage from './pages/Search';
import ListingDetailPage from './pages/ListingDetail';
import { Login, ForgotPassword, ResetPassword } from './pages/Auth';
import NotFound from './pages/NotFound';

const ListingForm = lazy(() => import('./pages/ListingForm'));
const Account = lazy(() => import('./pages/Account'));
const Messages = lazy(() => import('./pages/Messages'));
const Seller = lazy(() => import('./pages/Seller'));
const Payment = lazy(() => import('./pages/Payment'));
const PaymentResult = lazy(() => import('./pages/PaymentResult'));
const Admin = lazy(() => import('./pages/Admin'));
const AdminSetup = lazy(() => import('./pages/AdminSetup'));
const Legal = lazy(() => import('./pages/Legal'));

function ScrollTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

function Layout() {
  const { loading, error, reload } = useApp();
  const { profile } = useAuth();
  const loc = useLocation();
  const chat = /^\/mesajlar\/.+/.test(loc.pathname);
  return (
    <div className="flex min-h-dvh flex-col">
      <a href="#icerik" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[200] focus:rounded-lg focus:bg-ink focus:px-3 focus:py-2 focus:text-sm focus:font-bold focus:text-white">
        İçeriğe geç
      </a>
      <Header />
      {profile?.is_blocked && (
        <div role="alert" className="bg-coral-ink text-white">
          <div className="wrap flex items-start gap-2 py-2.5 text-sm font-semibold">
            <ShieldAlert size={18} className="mt-0.5 shrink-0" />
            <span>Hesabınız engellenmiştir; ilan veremez ve mesaj gönderemezsiniz.{profile.block_reason ? ` Neden: ${profile.block_reason}` : ''}</span>
          </div>
        </div>
      )}
      <main id="icerik" className={"flex-1"}>
        {loading ? <PageLoader /> : error ? <div className="wrap py-16"><ErrorBox message={error} onRetry={reload} /></div> : (
          <Suspense fallback={<PageLoader />}>
            <Outlet />
          </Suspense>
        )}
      </main>
      {!chat && <Footer />}
      <MobileNav />
      <CookieNotice />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppProvider>
        <AuthProvider>
          <ScrollTop />
          <Routes>
            <Route element={<Layout />}>
              <Route path="/" element={<Home />} />
              <Route path="/ilanlar" element={<SearchPage />} />
              <Route path="/kategori/:slug" element={<SearchPage />} />
              <Route path="/kategori/:slug/:sub" element={<SearchPage />} />
              <Route path="/ilan/:id" element={<ListingDetailPage />} />
              <Route path="/satici/:id" element={<Seller />} />
              <Route path="/giris" element={<Login mode="login" />} />
              <Route path="/kayit" element={<Login mode="signup" />} />
              <Route path="/sifremi-unuttum" element={<ForgotPassword />} />
              <Route path="/sifre-yenile" element={<ResetPassword />} />
              <Route path="/ilan-ver" element={<ProtectedRoute><ListingForm /></ProtectedRoute>} />
              <Route path="/ilan-duzenle/:id" element={<ProtectedRoute><ListingForm /></ProtectedRoute>} />
              <Route path="/hesabim" element={<ProtectedRoute><Account tab="ilanlar" /></ProtectedRoute>} />
              <Route path="/hesabim/favoriler" element={<ProtectedRoute><Account tab="favoriler" /></ProtectedRoute>} />
              <Route path="/hesabim/profil" element={<ProtectedRoute><Account tab="profil" /></ProtectedRoute>} />
              <Route path="/hesabim/odemeler" element={<ProtectedRoute><Account tab="odemeler" /></ProtectedRoute>} />
              <Route path="/mesajlar" element={<ProtectedRoute><Messages /></ProtectedRoute>} />
              <Route path="/mesajlar/:id" element={<ProtectedRoute><Messages /></ProtectedRoute>} />
              <Route path="/odeme/sonuc" element={<ProtectedRoute><PaymentResult /></ProtectedRoute>} />
              <Route path="/odeme/:type/:listingId" element={<ProtectedRoute><Payment /></ProtectedRoute>} />
              <Route path="/yonetim" element={<ProtectedRoute><Admin /></ProtectedRoute>} />
              <Route path="/yonetici-kurulum" element={<ProtectedRoute><AdminSetup /></ProtectedRoute>} />
              <Route path="/kvkk" element={<Legal doc="kvkk" />} />
              <Route path="/gizlilik" element={<Legal doc="gizlilik" />} />
              <Route path="/kullanim-kosullari" element={<Legal doc="kosullar" />} />
              <Route path="/guvenli-alisveris" element={<Legal doc="guvenlik" />} />
              <Route path="/hesap-silme" element={<Legal doc="hesap" />} />
              <Route path="*" element={<NotFound />} />
            </Route>
          </Routes>
        </AuthProvider>
      </AppProvider>
    </BrowserRouter>
  );
}
