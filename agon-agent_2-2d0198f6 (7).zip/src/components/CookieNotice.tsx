import { useState } from 'react';
import { Link } from 'react-router-dom';
import { getConsent, setConsent, useConsent } from './AdSlot';

export default function CookieNotice() {
  const [open, setOpen] = useState(() => !getConsent());
  const consent = useConsent();
  // Tercih başka bir yerden yapıldıysa (ör. yöneticinin "bu cihazda izin ver" düğmesi) bildirim de kapanır.
  if (!open || consent) return null;
  const choose = (v: 'all' | 'necessary') => {
    setConsent(v);
    setOpen(false);
  };
  return (
    <div role="region" aria-label="Çerez tercihleri" className="fixed inset-x-3 bottom-[5.25rem] z-[60] mx-auto max-w-2xl animate-rise rounded-2xl border border-line bg-white p-4 shadow-pop md:bottom-4">
      <p className="text-[0.84rem] leading-relaxed text-ink-soft">
        Oturumunuzu açık tutmak ve tercihlerinizi hatırlamak için zorunlu çerez ve yerel depolama kullanırız. Reklam çerezleri yalnızca izin verirseniz yüklenir.{' '}
        <Link to="/gizlilik" className="font-bold text-brand-700 underline underline-offset-2">Ayrıntılar</Link>
      </p>
      <div className="mt-3 flex flex-wrap justify-end gap-2">
        <button className="btn btn-outline btn-sm" onClick={() => choose('necessary')}>Yalnızca zorunlu</button>
        <button className="btn btn-primary btn-sm" onClick={() => choose('all')}>Tümünü kabul et</button>
      </div>
    </div>
  );
}
