import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Bell, BellRing, CreditCard, MessageCircle, ShieldCheck, Tag } from 'lucide-react';
import { api, errMsg } from '../lib/api';
import { useApp } from '../contexts/AppContext';
import { formatDate, formatTime } from '../lib/format';
import { Spinner } from './ui';

interface Item { id: string; type: string; title: string; body: string; link: string | null; is_read: boolean; created_at: string | null }

const supported = () => typeof window !== 'undefined' && 'Notification' in window;
const permissionNow = (): NotificationPermission | 'unsupported' => (supported() ? Notification.permission : 'unsupported');

// Site açıkken (sekme arka planda olsa da) cihazın bildirim alanında gösterir.
async function showSystem(item: Item) {
  if (!supported() || Notification.permission !== 'granted') return;
  const opts = { body: item.body, icon: '/icons/icon-192.png', badge: '/icons/icon-192.png', tag: item.id, data: { url: item.link || '/' } };
  try {
    const reg = 'serviceWorker' in navigator ? await navigator.serviceWorker.getRegistration() : undefined;
    if (reg) await reg.showNotification(item.title, opts);
    else {
      const n = new Notification(item.title, opts);
      n.onclick = () => { window.focus(); if (item.link) window.location.assign(item.link); n.close(); };
    }
  } catch (e) {
    console.warn('notification', e);
  }
}

function TypeIcon({ type }: { type: string }) {
  const cls = 'grid h-9 w-9 shrink-0 place-items-center rounded-xl';
  if (type === 'message') return <span className={`${cls} bg-brand-50 text-brand-700`}><MessageCircle size={17} /></span>;
  if (type === 'payment') return <span className={`${cls} bg-mint-soft text-mint-ink`}><CreditCard size={17} /></span>;
  if (type === 'admin') return <span className={`${cls} bg-ink text-sun`}><ShieldCheck size={17} /></span>;
  return <span className={`${cls} bg-sun-soft text-sun-ink`}><Tag size={17} /></span>;
}

export default function NotificationBell() {
  const { toast } = useApp();
  const loc = useLocation();
  const [items, setItems] = useState<Item[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [perm, setPerm] = useState(permissionNow);
  const [busy, setBusy] = useState(false);
  const box = useRef<HTMLDivElement>(null);
  const seen = useRef<Set<string> | null>(null);
  const openRef = useRef(false);
  openRef.current = open;
  const pathRef = useRef(loc.pathname);
  pathRef.current = loc.pathname;

  const load = useCallback(async (announce: boolean) => {
    try {
      const d = await api<{ items: Item[] }>('user?action=notifications');
      setItems(d.items);
      setError(null);
      const unreadNow = d.items.filter((i) => !i.is_read);
      if (seen.current && announce) {
        // Yalnızca bu oturumda ilk kez görülen ve kullanıcının o an bakmadığı bildirimler duyurulur.
        for (const it of unreadNow.filter((i) => !seen.current!.has(i.id + i.title)).slice(0, 3)) {
          if (it.link && it.link.split('?')[0] === pathRef.current) continue;
          if (document.visibilityState === 'hidden') showSystem(it);
          else if (!openRef.current) toast(it.body ? `${it.title} — ${it.body}` : it.title, 'info');
        }
      }
      // Mesaj bildirimlerinde başlık mesaj sayısıyla değişir; yeni mesaj yeniden duyurulur.
      seen.current = new Set(unreadNow.map((i) => i.id + i.title));
    } catch (e) {
      setError(errMsg(e));
    }
  }, [toast]);

  useEffect(() => {
    load(false);
    const onSignal = () => load(true);
    window.addEventListener('pz:msg', onSignal);
    const t = window.setInterval(() => { if (document.visibilityState === 'visible') load(true); }, 60000);
    const onVisible = () => { if (document.visibilityState === 'visible') load(false); };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      window.removeEventListener('pz:msg', onSignal);
      window.clearInterval(t);
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, [load]);

  // Sayfa değişince (ör. sohbet okununca) sayaç güncellensin ve açık liste kapansın
  useEffect(() => {
    setOpen(false);
    const t = window.setTimeout(() => load(false), 1200);
    return () => window.clearTimeout(t);
  }, [loc.pathname, load]);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => { if (box.current && !box.current.contains(e.target as Node)) setOpen(false); };
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const unread = (items || []).filter((i) => !i.is_read).length;
  const hasStored = (items || []).some((i) => i.id.startsWith('n:'));

  const markRead = useCallback(() => {
    setItems((list) => {
      if (!(list || []).some((i) => !i.is_read && i.id.startsWith('n:'))) return list;
      api('user?action=notifications', { method: 'PUT' }).catch(() => undefined);
      return (list || []).map((i) => (i.id.startsWith('n:') ? { ...i, is_read: true } : i));
    });
  }, []);

  // Liste her kapandığında (düğme, dışarı tıklama, Esc, bağlantıya gitme) kayıtlı bildirimler okundu sayılır.
  // Mesaj bildirimleri ise sohbet okununca kendiliğinden kalkar.
  const wasOpen = useRef(false);
  useEffect(() => {
    if (!open && wasOpen.current) markRead();
    wasOpen.current = open;
  }, [open, markRead]);

  const toggle = () => {
    if (!open) {
      setPerm(permissionNow());
      load(false);
    }
    setOpen(!open);
  };

  const clearAll = async () => {
    setBusy(true);
    try {
      await api('user?action=notifications', { method: 'DELETE' });
      await load(false);
    } catch (e) {
      toast(errMsg(e), 'error');
    } finally {
      setBusy(false);
    }
  };

  const enable = async () => {
    if (!supported()) return;
    try {
      const p = await Notification.requestPermission();
      setPerm(p);
      if (p === 'granted') {
        toast('Cihaz bildirimleri açıldı.');
        showSystem({ id: 'test', type: 'info', title: 'PAZARLA bildirimleri açık', body: 'Yeni mesaj ve ilan bildirimleri burada görünecek.', link: '/', is_read: false, created_at: null });
      } else if (p === 'denied') toast('Bildirim izni verilmedi. Tarayıcı ayarlarından bu site için izin verebilirsiniz.', 'info');
    } catch {
      toast('Bu tarayıcı bildirim iznine izin vermiyor.', 'error');
    }
  };

  const when = (iso: string | null) => {
    if (!iso) return '';
    const d = formatDate(iso);
    return d === 'Bugün' ? formatTime(iso) : d;
  };

  return (
    <div className="relative" ref={box}>
      <button onClick={toggle} aria-haspopup="dialog" aria-expanded={open} aria-label={unread ? `Bildirimler, ${unread} yeni` : 'Bildirimler'} className="relative grid h-11 w-11 place-items-center rounded-xl text-ink-soft transition-colors hover:bg-brand-50 hover:text-brand-700">
        {unread > 0 ? <BellRing size={21} /> : <Bell size={21} />}
        {unread > 0 && <span className="absolute right-1 top-1 grid h-[18px] min-w-[18px] place-items-center rounded-full bg-coral px-1 text-[10px] font-extrabold text-white ring-2 ring-white">{unread > 99 ? '99+' : unread}</span>}
      </button>
      {open && (
        <div role="dialog" aria-label="Bildirimler" className="fixed inset-x-3 top-[4.25rem] z-[60] flex max-h-[min(34rem,calc(100dvh-6rem))] animate-rise flex-col overflow-hidden rounded-2xl border border-line bg-white shadow-pop sm:absolute sm:inset-x-auto sm:right-0 sm:top-[calc(100%+8px)] sm:w-[24rem]">
          <div className="flex items-center justify-between gap-2 border-b border-line px-4 py-3">
            <h2 className="text-base font-bold text-ink">Bildirimler</h2>
            {hasStored && (
              <button onClick={clearAll} disabled={busy} className="rounded-lg px-2 py-1 text-xs font-bold text-muted hover:bg-surface hover:text-ink">
                {busy ? <Spinner size={13} /> : 'Tümünü temizle'}
              </button>
            )}
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto">
            {items === null && !error ? (
              <div className="grid place-items-center py-10"><Spinner className="text-brand-600" size={24} /></div>
            ) : error && !items ? (
              <div className="px-4 py-8 text-center">
                <p role="alert" className="text-sm font-semibold text-coral-ink">{error}</p>
                <button className="btn btn-outline btn-sm mt-3" onClick={() => load(false)}>Tekrar dene</button>
              </div>
            ) : (items || []).length === 0 ? (
              <div className="px-6 py-10 text-center">
                <Bell size={30} className="mx-auto text-brand-200" />
                <p className="mt-3 text-sm font-bold text-ink">Henüz bildiriminiz yok</p>
                <p className="mt-1 text-[0.82rem] leading-relaxed text-muted">Yeni mesajlar ve ilanlarınızla ilgili gelişmeler burada görünür.</p>
              </div>
            ) : (
              <ul>
                {(items || []).map((it) => {
                  const inner = (
                    <>
                      <TypeIcon type={it.type} />
                      <span className="min-w-0 flex-1">
                        <span className={`block text-[0.88rem] leading-snug text-ink ${it.is_read ? 'font-semibold' : 'font-extrabold'}`}>{it.title}</span>
                        {it.body && <span className="mt-0.5 line-clamp-2 block text-[0.8rem] leading-snug text-muted">{it.body}</span>}
                        <span className="mt-0.5 block text-[0.7rem] font-semibold text-muted">{when(it.created_at)}</span>
                      </span>
                      {!it.is_read && <span className="mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full bg-coral" aria-label="Yeni" />}
                    </>
                  );
                  const cls = `flex w-full items-start gap-3 border-b border-line px-4 py-3 text-left last:border-0 ${it.is_read ? 'bg-white' : 'bg-brand-50/60'}`;
                  return (
                    <li key={it.id}>
                      {it.link ? <Link to={it.link} onClick={() => setOpen(false)} className={`${cls} hover:bg-surface`}>{inner}</Link> : <div className={cls}>{inner}</div>}
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
          <div className="border-t border-line bg-surface px-4 py-3">
            {perm === 'default' ? (
              <button onClick={enable} className="btn btn-primary btn-sm w-full"><BellRing size={15} /> Cihaz bildirimlerini aç</button>
            ) : (
              <p className="text-[0.76rem] leading-snug text-muted">
                {perm === 'granted'
                  ? 'Cihaz bildirimleri açık: site açıkken başka bir sekmede ya da uygulamada olsanız da haber verilir.'
                  : perm === 'denied'
                    ? 'Cihaz bildirimleri bu site için engellenmiş. Tarayıcınızın site ayarlarından bildirimlere izin verebilirsiniz.'
                    : 'Bu tarayıcı cihaz bildirimlerini desteklemiyor. iPhone’da siteyi ana ekrana ekleyip oradan açın.'}
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
