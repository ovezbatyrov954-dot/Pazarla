import { useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../contexts/AppContext';
import { useAuth } from '../contexts/AuthContext';
import type { HouseAd } from '../lib/types';

declare global {
  interface Window { adsbygoogle?: unknown[] }
}

export const CONSENT_KEY = 'pz_consent';
export const getConsent = () => localStorage.getItem(CONSENT_KEY) as 'all' | 'necessary' | null;
export function setConsent(v: 'all' | 'necessary') {
  localStorage.setItem(CONSENT_KEY, v);
  window.dispatchEvent(new Event('pz:consent'));
}

export function useConsent() {
  const [c, setC] = useState(getConsent);
  useEffect(() => {
    const on = () => setC(getConsent());
    window.addEventListener('pz:consent', on);
    return () => window.removeEventListener('pz:consent', on);
  }, []);
  return c;
}

function loadAdsense(client: string) {
  if (document.querySelector('script[data-pz-adsense]')) return;
  const s = document.createElement('script');
  s.async = true;
  s.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${encodeURIComponent(client)}`;
  s.crossOrigin = 'anonymous';
  s.setAttribute('data-pz-adsense', '1');
  document.head.appendChild(s);
}

/**
 * Yöneticinin yüklediği görsel reklam. Görsel hangi biçimde olursa olsun (yatay, kare, dikey) KIRPILMADAN,
 * ortalanarak gösterilir; kenarlarda kalan boşluk aynı görselin bulanık hâliyle doldurulur, böylece alan her zaman dolu görünür.
 * Yönetim panelindeki önizleme de bu bileşeni kullanır: sitede görünen ile önizleme aynıdır.
 */
export function HouseAdView({ ad, compact = false, className = '' }: { ad: HouseAd; compact?: boolean; className?: string }) {
  const cap = compact ? 'max-h-[120px] md:max-h-[150px]' : 'max-h-[260px] md:max-h-[300px]';
  const pic = (cls: string, alt: string, decorative = false) => (
    <picture>
      {ad.mobile_image_url && <source media="(max-width: 767px)" srcSet={ad.mobile_image_url} />}
      <img src={ad.image_url} alt={alt} aria-hidden={decorative || undefined} loading="lazy" className={cls} />
    </picture>
  );
  const inner = (
    <span className="relative block overflow-hidden rounded-xl bg-surface">
      {pic('pointer-events-none absolute inset-0 h-full w-full scale-125 object-cover opacity-60 blur-xl', '', true)}
      {pic(`relative mx-auto block h-auto w-auto max-w-full object-contain ${cap}`, ad.title || 'Reklam')}
    </span>
  );
  return (
    <aside aria-label="Reklam" className={`overflow-hidden rounded-2xl border border-line bg-white ${compact ? 'p-1.5' : 'p-2'} ${className}`}>
      <p className={`text-center text-[10px] font-bold uppercase tracking-[0.14em] text-muted ${compact ? 'mb-0.5' : 'mb-1'}`}>Reklam</p>
      {!ad.link_url ? inner : ad.link_url.startsWith('/') ? (
        <Link to={ad.link_url} className="block">{inner}</Link>
      ) : (
        <a href={ad.link_url} target="_blank" rel="noopener noreferrer sponsored" className="block">{inner}</a>
      )}
    </aside>
  );
}

/**
 * Reklam alanı. İki tür reklam gösterebilir: yöneticinin kendi yüklediği görsel reklam ve Google AdSense.
 *  - only verilmezse: kendi reklam yayındaysa o, değilse AdSense gösterilir (kategori ve ilan detayı).
 *  - only="house" / only="adsense": alan yalnızca o türü gösterir (ana sayfadaki iki ayrı küçük alan).
 *  - compact: küçük şerit; AdSense sabit boyutlu banner olur (telefonda 320×50, geniş ekranda 728×90).
 * AdSense reklam birimi: bu alan ve cihaz için girilen kod; yoksa aynı alanın diğer cihaz kodu; o da yoksa "bütün alanlar" kodu.
 * Hiç reklam birimi yoksa yalnızca Google betiği yüklenir (AdSense "Otomatik reklamlar").
 * Ziyaretçiye asla boş kutu gösterilmez: Google reklam göndermezse alan kapanır. Yöneticiye ise nedenini söyleyen bir not gösterilir.
 */
interface Props { placement: 'home' | 'category' | 'detail'; className?: string; only?: 'house' | 'adsense'; compact?: boolean }

export default function AdSlot({ placement, className = '', only, compact = false }: Props) {
  const { settings } = useApp();
  const { profile } = useAuth();
  const consent = useConsent();
  // Küçük banner 728 piksel genişlik ister; yeterince geniş olmayan ekranlarda mobil boyut kullanılır.
  const [desktop] = useState(() => window.matchMedia(compact ? '(min-width: 800px)' : '(min-width: 768px)').matches);
  const insRef = useRef<HTMLModElement>(null);
  const pushed = useRef(false);
  const [status, setStatus] = useState<'pending' | 'filled' | 'unfilled' | 'blocked'>('pending');

  const ads = settings?.ads;
  const dev = desktop ? 'desktop' : 'mobile';
  const slot = ads?.slots?.[`${placement}_${dev}`] || ads?.slots?.[`${placement}_${desktop ? 'mobile' : 'desktop'}`] || ads?.slots?.all || '';
  const house = only === 'adsense' ? undefined : settings?.house_ads?.[placement];
  const showHouse = !!house?.image_url;
  const google = only !== 'house' && !showHouse;                      // bu alanda Google reklamı gösterilebilir mi
  const canLoad = !!(google && ads?.enabled && ads.client && consent === 'all');
  const active = canLoad && !!slot;

  useEffect(() => {
    if (!canLoad || !ads) return;
    loadAdsense(ads.client);
    if (!active || pushed.current) return;
    pushed.current = true;
    try {
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch (e) {
      console.warn('adsense', e);
    }
  }, [canLoad, active, ads]);

  // Google bu alana reklam gönderdi mi? Göndermediyse ya da betik hiç çalışmadıysa (ör. reklam engelleyici) boş kutu bırakılmaz.
  useEffect(() => {
    if (!active) return;
    const el = insRef.current;
    if (!el) return;
    const read = () => {
      const s = el.getAttribute('data-ad-status');
      if (s === 'filled' || s === 'unfilled') setStatus(s);
    };
    const mo = new MutationObserver(read);
    mo.observe(el, { attributes: true, attributeFilter: ['data-ad-status'] });
    const t = window.setTimeout(() => setStatus((s) => (s === 'pending' && !el.getAttribute('data-adsbygoogle-status') ? 'blocked' : s)), 8000);
    read();
    return () => {
      mo.disconnect();
      window.clearTimeout(t);
    };
  }, [active]);

  if (showHouse && house) return <HouseAdView ad={house} compact={compact} className={className} />;

  if (active && ads && status !== 'unfilled' && status !== 'blocked') {
    return (
      <aside aria-label="Reklam" className={`overflow-hidden rounded-2xl border border-line bg-white ${compact ? 'p-1.5' : 'p-2'} ${className}`}>
        <p className={`text-center text-[10px] font-bold uppercase tracking-[0.14em] text-muted ${compact ? 'mb-0.5' : 'mb-1'}`}>Reklam</p>
        {compact ? (
          <div className="flex justify-center overflow-hidden">
            <ins ref={insRef} className="adsbygoogle" style={{ display: 'inline-block', width: desktop ? 728 : 320, height: desktop ? 90 : 50 }} data-ad-client={ads.client} data-ad-slot={slot} />
          </div>
        ) : (
          <ins ref={insRef} className="adsbygoogle" style={{ display: 'block', minHeight: desktop ? 90 : 100 }} data-ad-client={ads.client} data-ad-slot={slot} data-ad-format="auto" data-full-width-responsive="true" />
        )}
      </aside>
    );
  }

  // Bundan sonrası yalnızca yöneticiye gösterilen notlardır; ziyaretçiler hiçbir şey görmez.
  if (!profile?.is_admin) return null;
  const note = (title: string, text: ReactNode) => (
    <aside aria-label="Reklam alanı notu (yalnızca yönetici görür)" className={`rounded-2xl border-2 border-dashed border-brand-200 bg-brand-50/50 px-3 py-2.5 text-center ${className}`}>
      <p className="text-[0.8rem] font-bold text-ink">{title}</p>
      <p className="text-[0.74rem] leading-snug text-muted">Bu notu yalnızca siz görüyorsunuz. {text}</p>
    </aside>
  );
  const toAds = (label: string) => <Link to="/yonetim?sekme=reklam" className="font-bold text-brand-700 underline">{label}</Link>;
  if (!google) return note('Reklam alanı (boş)', toAds('Reklam görseli ekle'));
  if (!ads?.client) return note(only === 'adsense' ? 'Google banner alanı (boş)' : 'Reklam alanı (boş)', toAds(only === 'adsense' ? 'Google AdSense kodu ekle' : 'Reklam ekle'));
  if (!ads.enabled) return note('Google reklamları kapalı', toAds('Reklam ayarlarından açın'));
  if (consent !== 'all') {
    return note('Google reklamı bu cihazda gösterilmiyor', <>Çerez bildiriminde reklam çerezlerine izin vermediniz. <button type="button" className="font-bold text-brand-700 underline" onClick={() => setConsent('all')}>Bu cihazda izin ver</button></>);
  }
  if (!slot) return note('Google: yalnızca otomatik reklamlar', <>Bu alan için reklam birimi kodu yok; Google reklamı sayfada kendi seçtiği yerde gösterir. {toAds('Reklam birimi kodu ekle')}</>);
  if (status === 'blocked') return note('Google reklam betiği yüklenemedi', 'Bu cihazda reklam engelleyici açık olabilir.');
  return note('Google şu an bu alana reklam göndermiyor', 'Reklam kodunuz yüklü. AdSense hesabınız ya da siteniz henüz onaylanmamış olabilir; AdSense panelini kontrol edin.');
}
