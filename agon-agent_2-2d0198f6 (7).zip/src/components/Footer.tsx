import { Link } from 'react-router-dom';
import { ShieldCheck } from 'lucide-react';
import Logo from './Logo';
import { useAuth } from '../contexts/AuthContext';

// Alt bilgi: yalnızca logo. "Yönetim paneli" bağlantısı sadece site yöneticisine gösterilir;
// yönetici yetkisi sunucuda doğrulanır, bu bağlantı yalnızca kısayoldur.
export default function Footer() {
  const { profile } = useAuth();
  return (
    <footer className="mt-12 border-t border-line bg-white pb-24 md:pb-0">
      <div className="wrap flex flex-col items-center gap-3 py-6 md:flex-row md:justify-between">
        <Link to="/" aria-label="PAZARLA ana sayfa" className="rounded-lg"><Logo size={28} /></Link>
        {profile?.is_admin && (
          <Link to="/yonetim" className="btn btn-outline btn-sm"><ShieldCheck size={15} /> Yönetim paneli</Link>
        )}
      </div>
    </footer>
  );
}
