import { useState } from 'react';
import { api, errMsg } from '../lib/api';
import { REPORT_REASONS } from '../lib/format';
import { useApp } from '../contexts/AppContext';
import { Modal, Spinner } from './ui';

export default function ReportDialog({ listingId, open, onClose }: { listingId: number; open: boolean; onClose: () => void }) {
  const { toast } = useApp();
  const [reason, setReason] = useState('');
  const [details, setDetails] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason) return setError('Lütfen bir şikâyet nedeni seçin.');
    if (reason === 'diger' && details.trim().length < 10) return setError('Lütfen şikâyetinizi kısaca açıklayın (en az 10 karakter).');
    setBusy(true);
    setError(null);
    try {
      await api('user?action=report', { method: 'POST', body: { listing_id: listingId, reason, details } });
      toast('Şikâyetiniz alındı. Ekibimiz en kısa sürede inceleyecek.');
      setReason('');
      setDetails('');
      onClose();
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open={open} onClose={onClose} title="İlanı şikâyet et">
      <form onSubmit={submit} noValidate>
        <fieldset>
          <legend className="mb-2 text-sm font-semibold text-ink-soft">Bu ilanla ilgili sorun nedir?</legend>
          <div className="flex flex-col gap-1.5">
            {REPORT_REASONS.map((r) => (
              <label key={r.value} className={`flex cursor-pointer items-center gap-3 rounded-xl border-[1.5px] px-3 py-2.5 text-sm font-semibold transition-colors ${reason === r.value ? 'border-brand-500 bg-brand-50 text-brand-800' : 'border-line text-ink-soft hover:border-brand-300'}`}>
                <input type="radio" name="reason" value={r.value} checked={reason === r.value} onChange={() => setReason(r.value)} className="h-4 w-4 accent-[#1447e6]" />
                {r.label}
              </label>
            ))}
          </div>
        </fieldset>
        <label className="label mt-4" htmlFor="report-details">Açıklama {reason === 'diger' ? '' : '(isteğe bağlı)'}</label>
        <textarea id="report-details" className="input !min-h-24" maxLength={1000} value={details} onChange={(e) => setDetails(e.target.value)} placeholder="İncelememize yardımcı olacak ayrıntıları yazın." />
        {error && <p role="alert" className="mt-2 text-sm font-semibold text-coral-ink">{error}</p>}
        <div className="mt-5 flex justify-end gap-2">
          <button type="button" className="btn btn-ghost" onClick={onClose}>Vazgeç</button>
          <button type="submit" className="btn btn-danger-solid" disabled={busy}>
            {busy && <Spinner size={16} />} Şikâyeti gönder
          </button>
        </div>
      </form>
    </Modal>
  );
}
