import { useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Loader2, X } from 'lucide-react';
import { initials } from '../lib/format';

export function useTitle(title: string | null | undefined) {
  useEffect(() => {
    document.title = title ? `${title} | PAZARLA` : 'PAZARLA — Ücretsiz ilan ver, al, sat';
  }, [title]);
}

export function Spinner({ size = 20, className = '' }: { size?: number; className?: string }) {
  return <Loader2 size={size} className={`animate-spin ${className}`} aria-hidden="true" />;
}

export function PageLoader({ label = 'Yükleniyor…' }: { label?: string }) {
  return (
    <div className="flex min-h-[45vh] flex-col items-center justify-center gap-3 text-muted" role="status">
      <Spinner size={30} className="text-brand-600" />
      <span className="text-sm font-semibold">{label}</span>
    </div>
  );
}

export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="card mx-auto flex max-w-lg flex-col items-center gap-3 px-6 py-10 text-center">
      <div className="grid h-12 w-12 place-items-center rounded-full bg-coral-soft text-coral-ink">
        <X size={22} />
      </div>
      <p className="font-semibold text-ink">{message}</p>
      {onRetry && (
        <button className="btn btn-outline btn-sm" onClick={onRetry}>
          Tekrar dene
        </button>
      )}
    </div>
  );
}

export function EmptyState({ icon, title, text, action }: { icon: ReactNode; title: string; text?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center gap-3 rounded-3xl border border-dashed border-brand-200 bg-white px-6 py-12 text-center">
      <div className="grid h-14 w-14 place-items-center rounded-2xl bg-brand-50 text-brand-600">{icon}</div>
      <h3 className="text-lg font-bold text-ink">{title}</h3>
      {text && <p className="max-w-md text-sm leading-relaxed text-muted">{text}</p>}
      {action}
    </div>
  );
}

export function Avatar({ name, url, size = 44 }: { name: string | null | undefined; url: string | null | undefined; size?: number }) {
  const [broken, setBroken] = useState(false);
  if (url && !broken) {
    return <img src={url} alt="" width={size} height={size} onError={() => setBroken(true)} className="shrink-0 rounded-full object-cover" style={{ width: size, height: size }} />;
  }
  return (
    <span
      aria-hidden="true"
      className="grid shrink-0 place-items-center rounded-full bg-gradient-to-br from-brand-500 to-brand-800 font-display font-bold text-white"
      style={{ width: size, height: size, fontSize: size * 0.38 }}
    >
      {initials(name)}
    </span>
  );
}

export function Field({ label, error, hint, children, htmlFor, required }: { label: string; error?: string | null; hint?: string; children: ReactNode; htmlFor?: string; required?: boolean }) {
  return (
    <div>
      <label className="label" htmlFor={htmlFor}>
        {label}
        {required && <span className="ml-0.5 text-coral-ink" aria-hidden="true">*</span>}
      </label>
      {children}
      {error ? (
        <p role="alert" className="mt-1.5 text-[0.82rem] font-semibold text-coral-ink">{error}</p>
      ) : hint ? (
        <p className="mt-1.5 text-[0.82rem] text-muted">{hint}</p>
      ) : null}
    </div>
  );
}

export function Modal({ open, onClose, title, children, wide = false }: { open: boolean; onClose: () => void; title: string; children: ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    ref.current?.focus();
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[90] flex items-end justify-center sm:items-center sm:p-4">
      <div className="absolute inset-0 animate-fade bg-brand-950/55 backdrop-blur-[2px]" onClick={onClose} aria-hidden="true" />
      <div
        ref={ref}
        tabIndex={-1}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={`relative flex max-h-[92dvh] w-full animate-sheet flex-col overflow-hidden rounded-t-3xl bg-white shadow-pop outline-none sm:animate-rise sm:rounded-3xl ${wide ? 'sm:max-w-2xl' : 'sm:max-w-md'}`}
      >
        <div className="flex items-center justify-between gap-3 border-b border-line px-5 py-4">
          <h2 className="text-lg font-bold text-ink">{title}</h2>
          <button onClick={onClose} aria-label="Kapat" className="grid h-9 w-9 place-items-center rounded-full text-muted hover:bg-surface hover:text-ink">
            <X size={20} />
          </button>
        </div>
        <div className="overflow-y-auto px-5 pt-5 pb-[max(1.25rem,env(safe-area-inset-bottom))]">{children}</div>
      </div>
    </div>
  );
}

export function Pagination({ page, total, per, onChange }: { page: number; total: number; per: number; onChange: (p: number) => void }) {
  const pages = Math.ceil(total / per);
  if (pages <= 1) return null;
  const nums: number[] = [];
  for (let i = Math.max(1, page - 2); i <= Math.min(pages, page + 2); i++) nums.push(i);
  const btn = 'grid h-10 min-w-10 place-items-center rounded-xl border px-2 text-sm font-bold transition-colors';
  return (
    <nav aria-label="Sayfalar" className="mt-8 flex flex-wrap items-center justify-center gap-1.5">
      <button className={`${btn} border-line bg-white text-ink hover:border-brand-400 disabled:opacity-40`} disabled={page <= 1} onClick={() => onChange(page - 1)} aria-label="Önceki sayfa">
        <ChevronLeft size={18} />
      </button>
      {nums[0] > 1 && <span className="px-1 text-muted">…</span>}
      {nums.map((n) => (
        <button
          key={n}
          onClick={() => onChange(n)}
          aria-current={n === page ? 'page' : undefined}
          className={`${btn} ${n === page ? 'border-brand-600 bg-brand-600 text-white' : 'border-line bg-white text-ink hover:border-brand-400'}`}
        >
          {n}
        </button>
      ))}
      {nums[nums.length - 1] < pages && <span className="px-1 text-muted">…</span>}
      <button className={`${btn} border-line bg-white text-ink hover:border-brand-400 disabled:opacity-40`} disabled={page >= pages} onClick={() => onChange(page + 1)} aria-label="Sonraki sayfa">
        <ChevronRight size={18} />
      </button>
    </nav>
  );
}

export function Crumbs({ items }: { items: { label: string; to?: string }[] }) {
  return (
    <nav aria-label="Konum" className="no-scrollbar flex items-center gap-1.5 overflow-x-auto whitespace-nowrap text-[0.82rem] font-semibold text-muted">
      {items.map((it, i) => (
        <span key={i} className="flex items-center gap-1.5">
          {i > 0 && <ChevronRight size={13} className="shrink-0 opacity-60" />}
          {it.to ? (
            <Link to={it.to} className="hover:text-brand-700">{it.label}</Link>
          ) : (
            <span className="text-ink-soft">{it.label}</span>
          )}
        </span>
      ))}
    </nav>
  );
}

export function Toggle({ checked, onChange, label, description, disabled }: { checked: boolean; onChange: (v: boolean) => void; label: string; description?: string; disabled?: boolean }) {
  return (
    <label className={`flex items-start gap-3 ${disabled ? 'opacity-60' : 'cursor-pointer'}`}>
      <span className="relative mt-0.5 inline-flex shrink-0">
        <input type="checkbox" className="peer sr-only" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
        <span className="h-6 w-11 rounded-full bg-[#c9d2e6] transition-colors peer-checked:bg-brand-600 peer-focus-visible:ring-4 peer-focus-visible:ring-brand-200" />
        <span className="absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform peer-checked:translate-x-5" />
      </span>
      <span className="min-w-0">
        <span className="block text-sm font-bold text-ink">{label}</span>
        {description && <span className="mt-0.5 block text-[0.82rem] leading-snug text-muted">{description}</span>}
      </span>
    </label>
  );
}
