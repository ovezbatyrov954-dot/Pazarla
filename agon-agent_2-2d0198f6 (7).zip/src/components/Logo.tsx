export function LogoMark({ size = 36 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none" aria-hidden="true" className="shrink-0">
      <defs>
        <linearGradient id="pzg" x1="4" y1="2" x2="36" y2="38" gradientUnits="userSpaceOnUse">
          <stop stopColor="#2A5FFF" />
          <stop offset="1" stopColor="#0F36B8" />
        </linearGradient>
      </defs>
      <rect width="40" height="40" rx="11" fill="url(#pzg)" />
      <path d="M14.5 31V11.5h7.25a6.75 6.75 0 0 1 0 13.5H14.5" stroke="#fff" strokeWidth="5.2" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="21.6" cy="18.25" r="2.15" fill="#FFC22E" />
    </svg>
  );
}

export default function Logo({ light = false, size = 36 }: { light?: boolean; size?: number }) {
  return (
    <span className="inline-flex select-none items-center gap-2" aria-label="PAZARLA">
      <LogoMark size={size} />
      <span className="font-display font-extrabold leading-none tracking-tight" style={{ fontSize: size * 0.62 }}>
        <span className={light ? 'text-white' : 'text-ink'}>PAZAR</span>
        <span className={light ? 'text-sun' : 'text-brand-600'}>LA</span>
      </span>
    </span>
  );
}
