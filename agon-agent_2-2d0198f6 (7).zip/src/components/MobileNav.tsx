import { NavLink, useLocation } from 'react-router-dom';
import { Home, MessageCircle, Plus, Search, User } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export default function MobileNav() {
  const { unread } = useAuth();
  const loc = useLocation();
  // İlan detayında ve sohbet ekranında kendi alt çubukları olduğu için gizlenir
  if (/^\/ilan\/\d+/.test(loc.pathname) || /^\/mesajlar\/.+/.test(loc.pathname) || loc.pathname.startsWith('/yonetim')) return null;
  const item = ({ isActive }: { isActive: boolean }) =>
    `relative flex min-w-0 flex-1 flex-col items-center gap-0.5 py-2 text-[0.68rem] font-bold ${isActive ? 'text-brand-700' : 'text-muted'}`;
  return (
    <nav aria-label="Alt menü" className="pb-safe fixed inset-x-0 bottom-0 z-40 border-t border-line bg-white/97 backdrop-blur-md md:hidden">
      <div className="mx-auto flex max-w-lg items-end px-1">
        <NavLink to="/" end className={item}><Home size={22} /><span>Ana sayfa</span></NavLink>
        <NavLink to="/ilanlar" className={item}><Search size={22} /><span>Keşfet</span></NavLink>
        <NavLink to="/ilan-ver" className="flex flex-1 flex-col items-center gap-0.5 pb-2 text-[0.68rem] font-extrabold text-ink" aria-label="İlan ver">
          <span className="-mt-5 grid h-[52px] w-[52px] place-items-center rounded-2xl bg-sun text-ink shadow-[0_8px_18px_-6px_rgb(255_170_0/0.9)] ring-4 ring-white">
            <Plus size={26} strokeWidth={2.8} />
          </span>
          <span>İlan ver</span>
        </NavLink>
        <NavLink to="/mesajlar" className={item}>
          <span className="relative">
            <MessageCircle size={22} />
            {unread > 0 && <span className="absolute -right-2 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-coral px-1 text-[9px] font-extrabold text-white ring-2 ring-white">{unread > 9 ? '9+' : unread}</span>}
          </span>
          <span>Mesajlar</span>
        </NavLink>
        <NavLink to="/hesabim" className={item}><User size={22} /><span>Hesabım</span></NavLink>
      </div>
    </nav>
  );
}
