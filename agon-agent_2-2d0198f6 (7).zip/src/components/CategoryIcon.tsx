import {
  Apple, Baby, Bike, BookOpen, Building2, Car, CookingPot, Dumbbell, Hammer, Laptop, Package, PawPrint, Puzzle,
  Shirt, ShoppingBag, Smartphone, Sofa, Sparkles, Tractor, WashingMachine,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

const ICONS: Record<string, LucideIcon> = {
  Apple, Baby, Bike, BookOpen, Building2, Car, CookingPot, Dumbbell, Hammer, Laptop, Package, PawPrint, Puzzle,
  Shirt, ShoppingBag, Smartphone, Sofa, Sparkles, Tractor, WashingMachine,
};

export default function CategoryIcon({ name, size = 22, className }: { name: string | null | undefined; size?: number; className?: string }) {
  const Icon = (name && ICONS[name]) || Package;
  return <Icon size={size} className={className} aria-hidden="true" />;
}
