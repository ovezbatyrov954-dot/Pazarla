import { useEffect, useRef, useState } from 'react';
import { Link, NavLink, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { ChevronDown, CreditCard, Download, Globe, Heart, LayoutList, LogOut, MessageCircle, Plus, Search, ShieldCheck, User as UserIcon } from 'lucide-react';
import Logo from './Logo';
import { Avatar } from './ui';
import NotificationBell from './NotificationBell';
import { useApp } from '../contexts/AppContext';
import { useAuth } from '../contexts/AuthContext';

export default function Header() {
  const { topCats, countries, country, setCountry } = useApp();
  const { user, profile, unread, signOut, loading } = useAuth();
  const [sp] = useSearchParams();
  const loc = useLocation();
  const nav = useNavigate();
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const onSearchPage = loc.pathname.startsWith('/ilanlar') || loc.pathname.startsWith('/kategori');

  useEffect(() => {
    setQ(onSearchPage ? sp.get('q') || '' : '');
    setOpen(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loc.pathname, loc.search]);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const term = q.trim();
    if (onSearchPage && loc.pathname.startsWith('/kategori')) {
      const next = new URLSearchParams(sp);
      if (term) next.set('q', term);
      else next.delete('q');
      next.delete('sayfa');
      nav(`${loc.pathname}?${next.toString()}`);
    } else {
      nav(term ? `/ilanlar?q=${encodeURIComponent(term)}` : '/ilanlar');
    }
  };

  const searchForm = (id: string) => (
    <form onSubmit={submit} role="search" className="flex w-full items-center rounded-2xl border-[1.5px] border-line bg-surface pl-3.5 transition-colors focus-within:border-brand-500 focus-within:bg-white focus-within:shadow-[0_0_0_4px_rgb(42_95_255/0.14)]">
      <Search size={18} className="shrink-0 text-muted" aria-hidden="true" />
      <label htmlFor={id} className="sr-only">İlan ara</label>
      <input
        id={id}
        type="search"
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Ürün, marka veya model ara"
        className="h-11 min-w-0 flex-1 bg-transparent px-2.5 text-[0.97rem] text-ink placeholder:text-[#8b96b0] focus:outline-none"
        enterKeyHint="search"
        maxLength={80}
      />
      <button type="submit" className="m-1 rounded-xl bg-brand-600 px-4 py-2 text-sm font-bold text-white transition-colors hover:bg-brand-700">
        Ara
      </button>
    </form>
  );

  const iconLink = 'relative grid h-11 w-11 place-items-center rounded-xl text-ink-soft transition-colors hover:bg-brand-50 hover:text-brand-700';
  const menuItem = 'flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm font-semibold text-ink-soft hover:bg-brand-50 hover:text-brand-700';

  return (
    <header className="sticky top-0 z-50 border-b border-line bg-white/95 backdrop-blur-md">
      <div className="wrap flex h-16 items-center gap-3 lg:gap-5">
        <Link to="/" className="shrink-0 rounded-lg" aria-label="PAZARLA ana sayfa">
          <Logo size={34} />
        </Link>
        <div className="hidden min-w-0 flex-1 md:block md:max-w-2xl">{searchForm('search-desktop')}</div>
        <div className="ml-auto flex items-center gap-1 lg:gap-1.5">
          {countries.length > 1 && (
            <label className="relative hidden items-center sm:flex">
              <span className="sr-only">Ülke</span>
              <Globe size={15} className="pointer-events-none absolute left-2.5 text-muted" aria-hidden="true" />
              <select value={country} onChange={(e) => setCountry(e.target.value)} className="input input-sm !w-auto !min-h-10 !pl-8 !pr-8 text-sm font-semibold">
                {countries.map((c) => <option key={c.code} value={c.code}>{c.name}</option>)}
              </select>
            </label>
          )}
          {user ? (
            <>
              <Link to="/hesabim/favoriler" className={`${iconLink} hidden md:grid`} aria-label="Favorilerim">
                <Heart size={21} />
              </Link>
              <Link to="/mesajlar" className={`${iconLink} hidden md:grid`} aria-label={unread ? `Mesajlar, ${unread} okunmamış` : 'Mesajlar'}>
                <MessageCircle size={21} />
                {unread > 0 && <span className="absolute right-1 top-1 grid h-[18px] min-w-[18px] place-items-center rounded-full bg-coral px-1 text-[10px] font-extrabold text-white ring-2 ring-white">{unread > 99 ? '99+' : unread}</span>}
              </Link>
              <NotificationBell />
              <div className="relative" ref={menuRef}>
                <button onClick={() => setOpen((o) => !o)} aria-haspopup="menu" aria-expanded={open} className="flex items-center gap-1.5 rounded-xl p-1 pr-1.5 hover:bg-brand-50">
                  <Avatar name={profile?.full_name || user.email} url={profile?.avatar_url} size={36} />
                  <ChevronDown size={15} className={`hidden text-muted transition-transform sm:block ${open ? 'rotate-180' : ''}`} />
                  <span className="sr-only">Hesap menüsü</span>
                </button>
                {open && (
                  <div role="menu" className="absolute right-0 top-[calc(100%+8px)] w-64 animate-rise rounded-2xl border border-line bg-white p-2 shadow-pop">
                    <div className="border-b border-line px-3 pb-2.5 pt-1.5">
                      <p className="truncate text-sm font-bold text-ink">{profile?.full_name || 'PAZARLA üyesi'}</p>
                      <p className="truncate text-xs text-muted">{user.email}</p>
                    </div>
                    <nav className="mt-1.5 flex flex-col">
                      <Link role="menuitem" to="/hesabim" className={menuItem}><LayoutList size={17} /> İlanlarım</Link>
                      <Link role="menuitem" to="/hesabim/favoriler" className={menuItem}><Heart size={17} /> Favorilerim</Link>
                      <Link role="menuitem" to="/mesajlar" className={menuItem}><MessageCircle size={17} /> Mesajlar{unread > 0 && <span className="ml-auto rounded-full bg-coral px-1.5 text-[11px] font-extrabold text-white">{unread}</span>}</Link>
                      <Link role="menuitem" to="/hesabim/odemeler" className={menuItem}><CreditCard size={17} /> Ödemelerim</Link>
                      <Link role="menuitem" to="/hesabim/profil" className={menuItem}><UserIcon size={17} /> Profil ve ayarlar</Link>
                      {profile?.is_admin && (
                        <Link role="menuitem" to="/yonetim" className={`${menuItem} !text-brand-700`}><ShieldCheck size={17} /> Yönetim paneli</Link>
                      )}
                      {profile?.is_admin && (
                        <Link role="menuitem" to="/yonetim?sekme=play" className={`${menuItem} !text-brand-700`}><Download size={17} /> Google Play dosyaları</Link>
                      )}
                      {!profile?.is_admin && profile?.can_setup_admin && (
                        <Link role="menuitem" to="/yonetici-kurulum" className={`${menuItem} !text-brand-700`}><ShieldCheck size={17} /> Yönetici kurulumu</Link>
                      )}
                      <button role="menuitem" onClick={signOut} className={`${menuItem} mt-1 border-t border-line !rounded-t-none pt-3 text-left`}>
                        <LogOut size={17} /> Çıkış yap
                      </button>
                    </nav>
                  </div>
                )}
              </div>
            </>
          ) : (
            !loading && (
              <Link to="/giris" className="btn btn-ghost btn-sm !min-h-10 !px-3">
                <UserIcon size={17} /> Giriş yap
              </Link>
            )
          )}
          <Link to="/ilan-ver" className="btn btn-sun !hidden !min-h-11 md:!inline-flex">
            <Plus size={18} strokeWidth={2.8} /> Ücretsiz İlan Ver
          </Link>
        </div>
      </div>
      <div className="wrap pb-2.5 md:hidden">{searchForm('search-mobile')}</div>
      <nav aria-label="Kategoriler" className="hidden border-t border-line md:block">
        <div className="wrap no-scrollbar flex items-center gap-1 overflow-x-auto py-1.5">
          <NavLink to="/ilanlar" end className={({ isActive }) => `shrink-0 rounded-lg px-2.5 py-1.5 text-[0.82rem] font-bold ${isActive ? 'bg-brand-600 text-white' : 'text-brand-700 hover:bg-brand-50'}`}>
            Tüm ilanlar
          </NavLink>
          {topCats.map((c) => (
            <NavLink key={c.id} to={`/kategori/${c.slug}`} className={({ isActive }) => `shrink-0 rounded-lg px-2.5 py-1.5 text-[0.82rem] font-semibold ${isActive ? 'bg-brand-50 text-brand-700' : 'text-ink-soft hover:bg-surface hover:text-ink'}`}>
              {c.name}
            </NavLink>
          ))}
        </div>
      </nav>
    </header>
  );
}
