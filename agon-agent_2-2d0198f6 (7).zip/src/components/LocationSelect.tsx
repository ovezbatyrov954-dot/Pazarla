import { useEffect, useState } from 'react';
import { useApp } from '../contexts/AppContext';
import type { City, District } from '../lib/types';

export interface Loc { country_code: string; city_id: number | null; district_id: number | null }

interface Props {
  value: Loc;
  onChange: (v: Loc) => void;
  errors?: { city?: string | null; district?: string | null };
  showDistrict?: boolean;
  idPrefix?: string;
  required?: boolean;
}

export function useCities(code: string) {
  const { getCities } = useApp();
  const [cities, setCities] = useState<City[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let on = true;
    setLoading(true);
    getCities(code)
      .then((c) => on && setCities(c))
      .catch(() => on && setCities([]))
      .finally(() => on && setLoading(false));
    return () => { on = false; };
  }, [code, getCities]);
  return { cities, loading };
}

export function useDistricts(cityId: number | null) {
  const { getDistricts } = useApp();
  const [districts, setDistricts] = useState<District[]>([]);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    if (!cityId) {
      setDistricts([]);
      return;
    }
    let on = true;
    setLoading(true);
    getDistricts(cityId)
      .then((d) => on && setDistricts(d))
      .catch(() => on && setDistricts([]))
      .finally(() => on && setLoading(false));
    return () => { on = false; };
  }, [cityId, getDistricts]);
  return { districts, loading };
}

export default function LocationSelect({ value, onChange, errors, showDistrict = true, idPrefix = 'loc', required }: Props) {
  const { countries, countryOf } = useApp();
  const { cities, loading: lc } = useCities(value.country_code);
  const { districts, loading: ld } = useDistricts(value.city_id);
  const c = countryOf(value.country_code);
  const star = required ? <span className="ml-0.5 text-coral-ink" aria-hidden="true">*</span> : null;
  return (
    <div className={`grid gap-4 ${countries.length > 1 ? 'sm:grid-cols-3' : 'sm:grid-cols-2'}`}>
      {countries.length > 1 && (
        <div>
          <label className="label" htmlFor={`${idPrefix}-country`}>Ülke{star}</label>
          <select id={`${idPrefix}-country`} className="input" value={value.country_code} onChange={(e) => onChange({ country_code: e.target.value, city_id: null, district_id: null })}>
            {countries.map((x) => <option key={x.code} value={x.code}>{x.name}</option>)}
          </select>
        </div>
      )}
      <div>
        <label className="label" htmlFor={`${idPrefix}-city`}>{c?.region_label || 'Şehir'}{star}</label>
        <select
          id={`${idPrefix}-city`}
          className={`input ${errors?.city ? 'input-error' : ''}`}
          value={value.city_id ?? ''}
          disabled={lc}
          onChange={(e) => onChange({ ...value, city_id: e.target.value ? Number(e.target.value) : null, district_id: null })}
        >
          <option value="">{lc ? 'Yükleniyor…' : 'Seçin'}</option>
          {cities.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
        </select>
        {errors?.city && <p role="alert" className="mt-1.5 text-[0.82rem] font-semibold text-coral-ink">{errors.city}</p>}
      </div>
      {showDistrict && (
        <div>
          <label className="label" htmlFor={`${idPrefix}-district`}>{c?.district_label || 'İlçe'}{star}</label>
          <select
            id={`${idPrefix}-district`}
            className={`input ${errors?.district ? 'input-error' : ''}`}
            value={value.district_id ?? ''}
            disabled={!value.city_id || ld}
            onChange={(e) => onChange({ ...value, district_id: e.target.value ? Number(e.target.value) : null })}
          >
            <option value="">{!value.city_id ? `Önce ${(c?.region_label || 'şehir').toLocaleLowerCase('tr-TR')} seçin` : ld ? 'Yükleniyor…' : 'Seçin'}</option>
            {districts.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
          </select>
          {errors?.district && <p role="alert" className="mt-1.5 text-[0.82rem] font-semibold text-coral-ink">{errors.district}</p>}
        </div>
      )}
    </div>
  );
}
