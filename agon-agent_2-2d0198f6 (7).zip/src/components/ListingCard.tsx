import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Camera, Heart, MapPin, Star, Zap } from 'lucide-react';
import type { Card } from '../lib/types';
import { formatDate, formatPrice } from '../lib/format';
import { useAuth } from '../contexts/AuthContext';

export default function ListingCard({ item, hideFav = false }: { item: Card; hideFav?: boolean }) {
  const { favIds, toggleFavorite } = useAuth();
  const [broken, setBroken] = useState(false);
  const fav = favIds.has(item.id);
  const place = [item.district_name, item.city_name].filter(Boolean).join(', ');
  return (
    <article className="group relative flex h-full flex-col overflow-hidden rounded-2xl border border-line bg-white transition-all duration-200 hover:-translate-y-0.5 hover:border-brand-300 hover:shadow-card">
      <Link to={`/ilan/${item.id}`} className="flex h-full flex-col focus-visible:outline-offset-[-2px]" aria-label={`${item.title}, ${formatPrice(item.price, item.currency)}`}>
        <div className="relative aspect-[4/3] overflow-hidden bg-surface">
          {item.cover && !broken ? (
            <img src={item.cover} alt="" loading="lazy" decoding="async" onError={() => setBroken(true)} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.04]" />
          ) : (
            <div className="grid h-full w-full place-items-center text-brand-200">
              <Camera size={34} />
            </div>
          )}
          <div className="absolute left-2 top-2 flex flex-col items-start gap-1">
            {item.is_showcase && (
              <span className="chip bg-ink text-sun shadow"><Star size={11} fill="currentColor" /> Vitrin</span>
            )}
            {item.is_featured && !item.is_showcase && (
              <span className="chip bg-sun text-ink shadow"><Zap size={11} fill="currentColor" /> Öne çıkan</span>
            )}
          </div>
          {item.photo_count > 1 && (
            <span className="chip absolute bottom-2 left-2 bg-ink/75 text-white backdrop-blur">
              <Camera size={11} /> {item.photo_count}
            </span>
          )}
        </div>
        <div className="flex flex-1 flex-col gap-1.5 p-3">
          <div className="flex items-baseline justify-between gap-2">
            <p className="font-display text-[1.08rem] font-extrabold leading-tight text-brand-700">{formatPrice(item.price, item.currency)}</p>
            <span className={`chip shrink-0 ${item.condition === 'new' ? 'bg-mint-soft text-mint-ink' : 'bg-surface text-ink-soft'}`}>
              {item.condition === 'new' ? 'Sıfır' : 'İkinci el'}
            </span>
          </div>
          <h3 className="line-clamp-2 min-h-[2.5em] text-[0.92rem] font-semibold leading-tight text-ink">{item.title}</h3>
          <div className="mt-auto flex items-center justify-between gap-2 pt-1 text-[0.76rem] font-medium text-muted">
            <span className="flex min-w-0 items-center gap-1">
              <MapPin size={12} className="shrink-0" />
              <span className="truncate">{place || '—'}</span>
            </span>
            <time dateTime={item.date} className="shrink-0">{formatDate(item.date)}</time>
          </div>
        </div>
      </Link>
      {!hideFav && (
        <button
          onClick={() => toggleFavorite(item.id)}
          aria-label={fav ? 'Favorilerden çıkar' : 'Favorilere ekle'}
          aria-pressed={fav}
          className={`absolute right-2 top-2 grid h-9 w-9 place-items-center rounded-full shadow-md backdrop-blur transition-transform hover:scale-110 active:scale-95 ${fav ? 'bg-coral text-white' : 'bg-white/95 text-ink-soft hover:text-coral-ink'}`}
        >
          <Heart size={17} fill={fav ? 'currentColor' : 'none'} />
        </button>
      )}
    </article>
  );
}

export function CardSkeleton() {
  return (
    <div className="overflow-hidden rounded-2xl border border-line bg-white" aria-hidden="true">
      <div className="skeleton aspect-[4/3] !rounded-none" />
      <div className="space-y-2 p-3">
        <div className="skeleton h-5 w-1/2" />
        <div className="skeleton h-4 w-full" />
        <div className="skeleton h-4 w-2/3" />
      </div>
    </div>
  );
}

export function CardGrid({ children, dense = false }: { children: React.ReactNode; dense?: boolean }) {
  return (
    <div className={`grid grid-cols-2 gap-3 sm:gap-4 ${dense ? 'md:grid-cols-3 xl:grid-cols-4' : 'md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5'}`}>
      {children}
    </div>
  );
}
