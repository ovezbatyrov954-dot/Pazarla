import { useEffect, useRef, useState } from 'react';
import { AlertTriangle, ArrowLeft, ArrowRight, ImagePlus, RotateCw, Trash2 } from 'lucide-react';
import { api, errMsg } from '../lib/api';
import { prepareImage } from '../lib/image';
import { thumbOf } from '../lib/format';
import { Spinner } from './ui';

interface Item { key: string; url?: string; preview: string; state: 'up' | 'ok' | 'err'; error?: string; file?: File }

interface Props {
  value: string[];
  onChange: (urls: string[]) => void;
  onBusy?: (busy: boolean) => void;
  max: number;
  error?: string | null;
}

let seq = 0;

export default function PhotoUploader({ value, onChange, onBusy, max, error }: Props) {
  const [items, setItems] = useState<Item[]>(() => value.map((u) => ({ key: `i${seq++}`, url: u, preview: thumbOf(u), state: 'ok' as const })));
  const [drag, setDrag] = useState(false);
  const [note, setNote] = useState<string | null>(null);
  const input = useRef<HTMLInputElement>(null);
  const lastSent = useRef(value.join('|'));
  const cb = useRef({ onChange, onBusy });
  cb.current = { onChange, onBusy };

  // Düzenleme ekranında ilan sonradan yüklendiğinde mevcut fotoğrafları al
  useEffect(() => {
    const joined = value.join('|');
    if (joined !== lastSent.current) {
      lastSent.current = joined;
      setItems(value.map((u) => ({ key: `i${seq++}`, url: u, preview: thumbOf(u), state: 'ok' as const })));
    }
  }, [value]);

  useEffect(() => {
    const urls = items.filter((i) => i.state === 'ok' && i.url).map((i) => i.url as string);
    const joined = urls.join('|');
    if (joined !== lastSent.current) {
      lastSent.current = joined;
      cb.current.onChange(urls);
    }
    cb.current.onBusy?.(items.some((i) => i.state === 'up'));
  }, [items]);

  const upload = async (key: string, file: File) => {
    try {
      const p = await prepareImage(file);
      setItems((list) => list.map((i) => (i.key === key ? { ...i, preview: p.preview } : i)));
      const r = await api<{ url: string }>('upload', { method: 'POST', body: { kind: 'listing', main: p.main, thumb: p.thumb } });
      setItems((list) => list.map((i) => (i.key === key ? { ...i, url: r.url, state: 'ok', error: undefined, file: undefined } : i)));
    } catch (e) {
      setItems((list) => list.map((i) => (i.key === key ? { ...i, state: 'err', error: errMsg(e), file } : i)));
    }
  };

  const add = async (files: FileList | File[]) => {
    const list = Array.from(files);
    const room = max - items.length;
    if (room <= 0) {
      setNote(`En fazla ${max} fotoğraf ekleyebilirsiniz.`);
      return;
    }
    const take = list.slice(0, room);
    setNote(list.length > room ? `En fazla ${max} fotoğraf ekleyebilirsiniz; ilk ${room} fotoğraf alındı.` : null);
    const fresh = take.map((file) => ({ key: `i${seq++}`, preview: '', state: 'up' as const, file }));
    setItems((prev) => [...prev, ...fresh]);
    // Sırayla yükle: mobil bağlantılarda daha güvenilir
    for (const f of fresh) await upload(f.key, f.file);
  };

  const move = (idx: number, dir: -1 | 1) =>
    setItems((list) => {
      const j = idx + dir;
      if (j < 0 || j >= list.length) return list;
      const n = [...list];
      [n[idx], n[j]] = [n[j], n[idx]];
      return n;
    });

  const retry = (it: Item) => {
    if (!it.file) return;
    setItems((list) => list.map((i) => (i.key === it.key ? { ...i, state: 'up', error: undefined } : i)));
    upload(it.key, it.file);
  };

  return (
    <div>
      <div
        onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
        onDragLeave={() => setDrag(false)}
        onDrop={(e) => { e.preventDefault(); setDrag(false); if (e.dataTransfer.files.length) add(e.dataTransfer.files); }}
        className={`rounded-2xl border-2 border-dashed p-3 transition-colors sm:p-4 ${drag ? 'border-brand-500 bg-brand-50' : error ? 'border-coral-ink/60 bg-coral-soft/40' : 'border-brand-200 bg-brand-50/40'}`}
      >
        <div className="grid grid-cols-3 gap-2.5 sm:grid-cols-4 md:grid-cols-6">
          {items.map((it, idx) => (
            <div key={it.key} className="group relative aspect-square overflow-hidden rounded-xl border border-line bg-white">
              {it.preview ? <img src={it.preview} alt={`Fotoğraf ${idx + 1}`} className="h-full w-full object-cover" /> : <div className="skeleton h-full w-full !rounded-none" />}
              {idx === 0 && it.state === 'ok' && <span className="chip absolute left-1.5 top-1.5 bg-brand-600 text-white">Kapak</span>}
              {it.state === 'up' && (
                <div className="absolute inset-0 grid place-items-center bg-white/70" role="status" aria-label="Yükleniyor">
                  <Spinner className="text-brand-600" size={24} />
                </div>
              )}
              {it.state === 'err' && (
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-1 bg-coral-soft/95 p-1.5 text-center">
                  <AlertTriangle size={16} className="text-coral-ink" />
                  <p className="line-clamp-3 text-[10px] font-semibold leading-tight text-coral-ink">{it.error}</p>
                  {it.file && (
                    <button type="button" onClick={() => retry(it)} className="flex items-center gap-1 rounded-md bg-white px-1.5 py-0.5 text-[10px] font-bold text-ink shadow">
                      <RotateCw size={10} /> Tekrar
                    </button>
                  )}
                </div>
              )}
              <div className="absolute inset-x-0 bottom-0 flex items-center justify-between gap-1 bg-gradient-to-t from-ink/80 to-transparent p-1 pt-4">
                <div className="flex gap-1">
                  <button type="button" disabled={idx === 0} onClick={() => move(idx, -1)} aria-label={`Fotoğraf ${idx + 1}: öne al`} className="grid h-7 w-7 place-items-center rounded-lg bg-white/95 text-ink disabled:opacity-30">
                    <ArrowLeft size={14} />
                  </button>
                  <button type="button" disabled={idx === items.length - 1} onClick={() => move(idx, 1)} aria-label={`Fotoğraf ${idx + 1}: sona al`} className="grid h-7 w-7 place-items-center rounded-lg bg-white/95 text-ink disabled:opacity-30">
                    <ArrowRight size={14} />
                  </button>
                </div>
                <button type="button" onClick={() => setItems((l) => l.filter((x) => x.key !== it.key))} aria-label={`Fotoğraf ${idx + 1}: kaldır`} className="grid h-7 w-7 place-items-center rounded-lg bg-white/95 text-coral-ink">
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))}
          {items.length < max && (
            <button
              type="button"
              onClick={() => input.current?.click()}
              className="flex aspect-square flex-col items-center justify-center gap-1 rounded-xl border-2 border-dashed border-brand-300 bg-white p-1 text-center text-brand-700 transition-colors hover:border-brand-500 hover:bg-brand-50"
            >
              <ImagePlus size={24} />
              <span className="text-[0.74rem] font-bold leading-tight">Fotoğraf ekle</span>
            </button>
          )}
        </div>
        <input
          ref={input}
          type="file"
          accept="image/*"
          multiple
          className="sr-only"
          aria-label="Fotoğraf seç"
          onChange={(e) => {
            if (e.target.files?.length) add(e.target.files);
            e.target.value = '';
          }}
        />
        <p className="mt-3 text-[0.82rem] leading-snug text-muted">
          <strong className="text-ink-soft">{items.filter((i) => i.state === 'ok').length} / {max}</strong> fotoğraf. İlk fotoğraf kapak olur; oklarla sıralayabilirsiniz. Fotoğraflar yüklenmeden önce cihazınızda küçültülür.
        </p>
      </div>
      {note && <p className="mt-1.5 text-[0.82rem] font-semibold text-sun-ink">{note}</p>}
      {error && <p role="alert" className="mt-1.5 text-[0.82rem] font-semibold text-coral-ink">{error}</p>}
    </div>
  );
}
