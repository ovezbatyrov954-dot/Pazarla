import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App.tsx';
import { handleGoogleRedirect } from './lib/googleAuth';

handleGoogleRedirect();

// Uygulama hissi: yazı alanları dışında kopyalama, dokunmatik ekranda uzun basma menüsü ve görsel/bağlantı sürükleme kapalı.
const editable = (t: EventTarget | null) => t instanceof Element && !!t.closest('input, textarea, select, [contenteditable], pre, code');
for (const type of ['copy', 'cut'] as const) {
  document.addEventListener(type, (e) => { if (!editable(e.target)) e.preventDefault(); });
}
document.addEventListener('contextmenu', (e) => {
  if (editable(e.target)) return;
  const touch = (e as PointerEvent).pointerType === 'touch' || (e as PointerEvent).pointerType === 'pen' || window.matchMedia('(pointer: coarse)').matches;
  if (touch) e.preventDefault();
});
document.addEventListener('dragstart', (e) => {
  if (e.target instanceof Element && e.target.closest('img, a')) e.preventDefault();
});

// PWA: "ana ekrana ekle" istemini yakala; alt bilgideki düğme bunu kullanır.
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  (window as any).__pzInstall = e;
  window.dispatchEvent(new Event('pz:install'));
});

if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch((err) => console.warn('service worker', err));
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
