import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import type { Session, User } from '@supabase/supabase-js';
import supabase from '../lib/supabase';
import { api, ApiError, errMsg } from '../lib/api';
import type { Profile, Quota } from '../lib/types';
import { useApp } from './AppContext';

interface AuthState {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  quota: Quota | null;
  loading: boolean;
  unread: number;
  favIds: Set<number>;
  refresh: () => Promise<void>;
  refreshUnread: () => Promise<void>;
  toggleFavorite: (listingId: number) => Promise<void>;
  signOut: () => Promise<void>;
}

const Ctx = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { toast } = useApp();
  const navigate = useNavigate();
  const location = useLocation();
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [quota, setQuota] = useState<Quota | null>(null);
  const [unread, setUnread] = useState(0);
  const [favIds, setFavIds] = useState<Set<number>>(new Set());
  const [sessionReady, setSessionReady] = useState(false);
  const [profileReady, setProfileReady] = useState(false);
  const userId = session?.user?.id || null;
  const locRef = useRef(location);
  locRef.current = location;

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setSessionReady(true);
    });
    const { data } = supabase.auth.onAuthStateChange((_event, s) => {
      setSession(s);
      setSessionReady(true);
    });
    return () => data.subscription.unsubscribe();
  }, []);

  const refresh = useCallback(async () => {
    try {
      const d = await api<{ profile: Profile; unread: number; favorite_ids: number[]; quota: Quota }>('user?action=me');
      setProfile(d.profile);
      setUnread(d.unread);
      setFavIds(new Set(d.favorite_ids));
      setQuota(d.quota);
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) {
        await supabase.auth.signOut();
      } else {
        console.error('profile load failed', e);
      }
    } finally {
      setProfileReady(true);
    }
  }, []);

  const refreshUnread = useCallback(async () => {
    try {
      const d = await api<{ unread: number }>('messages?action=unread');
      setUnread(d.unread);
    } catch {
      /* sessiz */
    }
  }, []);

  useEffect(() => {
    if (!sessionReady) return;
    if (!userId) {
      setProfile(null);
      setQuota(null);
      setUnread(0);
      setFavIds(new Set());
      setProfileReady(true);
      return;
    }
    setProfileReady(false);
    refresh();
  }, [userId, sessionReady, refresh]);

  // Gerçek zamanlı bildirim: sunucu, kullanıcıya özel gizli kanala yalnızca "yeni mesaj var" sinyali gönderir.
  const rtKey = profile?.rt_key || null;
  useEffect(() => {
    if (!rtKey) return;
    const channel = supabase
      .channel(`rt-${rtKey}`)
      .on('broadcast', { event: 'msg' }, (payload) => {
        window.dispatchEvent(new CustomEvent('pz:msg', { detail: payload.payload }));
        refreshUnread();
      })
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [rtKey, refreshUnread]);

  // Gerçek zamanlı bağlantı kesilirse okunmamış sayacı için yedek yoklama
  useEffect(() => {
    if (!userId) return;
    const t = window.setInterval(() => {
      if (document.visibilityState === 'visible') refreshUnread();
    }, 45000);
    return () => window.clearInterval(t);
  }, [userId, refreshUnread]);

  const toggleFavorite = useCallback(
    async (listingId: number) => {
      if (!userId) {
        const l = locRef.current;
        toast('Favorilere eklemek için giriş yapın.', 'info');
        navigate(`/giris?next=${encodeURIComponent(l.pathname + l.search)}`);
        return;
      }
      const had = favIds.has(listingId);
      const flip = (on: boolean) =>
        setFavIds((prev) => {
          const n = new Set(prev);
          if (on) n.add(listingId);
          else n.delete(listingId);
          return n;
        });
      flip(!had);
      try {
        const r = await api<{ favorite: boolean }>('user?action=favorite', { method: 'POST', body: { listing_id: listingId } });
        flip(r.favorite);
        toast(r.favorite ? 'Favorilere eklendi.' : 'Favorilerden çıkarıldı.');
      } catch (e) {
        flip(had);
        toast(errMsg(e), 'error');
      }
    },
    [userId, favIds, toast, navigate],
  );

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setProfile(null);
    navigate('/');
  }, [navigate]);

  const value = useMemo<AuthState>(
    () => ({
      user: session?.user ?? null,
      session,
      profile,
      quota,
      loading: !sessionReady || (!!userId && !profileReady),
      unread,
      favIds,
      refresh,
      refreshUnread,
      toggleFavorite,
      signOut,
    }),
    [session, profile, quota, sessionReady, userId, profileReady, unread, favIds, refresh, refreshUnread, toggleFavorite, signOut],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const v = useContext(Ctx);
  if (!v) throw new Error('useAuth must be used inside AuthProvider');
  return v;
}
