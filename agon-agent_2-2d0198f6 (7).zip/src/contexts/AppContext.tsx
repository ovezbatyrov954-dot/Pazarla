import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { CheckCircle2, AlertTriangle, Info, X } from 'lucide-react';
import { api, errMsg } from '../lib/api';
import type { Banner, Category, City, Country, District, Settings } from '../lib/types';

type ToastKind = 'success' | 'error' | 'info';
interface Toast { id: number; msg: string; kind: ToastKind }

interface AppState {
  categories: Category[];
  topCats: Category[];
  subsOf: (parentId: number) => Category[];
  catById: (id: number | null | undefined) => Category | undefined;
  catBySlug: (slug: string) => Category | undefined;
  countries: Country[];
  countryOf: (code: string) => Country | undefined;
  settings: Settings | null;
  banners: Banner[];
  loading: boolean;
  error: string | null;
  reload: (fresh?: unknown) => Promise<void>;
  country: string;
  setCountry: (code: string) => void;
  getCities: (code: string) => Promise<City[]>;
  getDistricts: (cityId: number) => Promise<District[]>;
  toast: (msg: string, kind?: ToastKind) => void;
}

const Ctx = createContext<AppState | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [countries, setCountries] = useState<Country[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [banners, setBanners] = useState<Banner[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [country, setCountryState] = useState<string>(() => localStorage.getItem('pz_country') || 'TR');
  const [toasts, setToasts] = useState<Toast[]>([]);
  const cityCache = useRef(new Map<string, Promise<City[]>>());
  const districtCache = useRef(new Map<number, Promise<District[]>>());

  // fresh === true: sunucu önbelleği atlanır (yönetici bir ayarı kaydettikten hemen sonra güncel hâlini görsün diye).
  const reload = useCallback(async (fresh?: unknown) => {
    try {
      setError(null);
      const d = await api<{ categories: Category[]; countries: Country[]; settings: Settings; banners: Banner[] }>(`catalog?action=bootstrap${fresh === true ? `&v=${Date.now()}` : ''}`, { anon: true });
      setCategories(d.categories);
      setCountries(d.countries);
      setSettings(d.settings);
      setBanners(d.banners);
      if (!d.countries.some((c) => c.code === (localStorage.getItem('pz_country') || 'TR'))) setCountryState('TR');
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { reload(); }, [reload]);

  // Google AdSense'in siteyi doğrulayabilmesi için yayıncı kimliği sayfa başlığına eklenir (çerez kullanmaz).
  const adClient = settings?.ads?.client || '';
  useEffect(() => {
    let m = document.querySelector<HTMLMetaElement>('meta[name="google-adsense-account"]');
    if (!adClient) { m?.remove(); return; }
    if (!m) { m = document.createElement('meta'); m.name = 'google-adsense-account'; document.head.appendChild(m); }
    m.content = adClient;
  }, [adClient]);

  const setCountry = useCallback((code: string) => {
    localStorage.setItem('pz_country', code);
    setCountryState(code);
  }, []);

  const getCities = useCallback((code: string) => {
    const hit = cityCache.current.get(code);
    if (hit) return hit;
    const p = api<City[]>(`catalog?action=cities&country=${code}`, { anon: true }).catch((e) => {
      cityCache.current.delete(code);
      throw e;
    });
    cityCache.current.set(code, p);
    return p;
  }, []);

  const getDistricts = useCallback((cityId: number) => {
    const hit = districtCache.current.get(cityId);
    if (hit) return hit;
    const p = api<District[]>(`catalog?action=districts&city_id=${cityId}`, { anon: true })
      .then((rows) => [...rows].sort((a, b) => a.name.localeCompare(b.name, 'tr')))
      .catch((e) => {
        districtCache.current.delete(cityId);
        throw e;
      });
    districtCache.current.set(cityId, p);
    return p;
  }, []);

  const toast = useCallback((msg: string, kind: ToastKind = 'success') => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-2), { id, msg, kind }]);
    window.setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), kind === 'error' ? 6500 : 4000);
  }, []);

  const value = useMemo<AppState>(() => {
    const byId = new Map(categories.map((c) => [c.id, c]));
    const topCats = categories.filter((c) => !c.parent_id);
    return {
      categories,
      topCats,
      subsOf: (pid) => categories.filter((c) => c.parent_id === pid),
      catById: (id) => (id ? byId.get(id) : undefined),
      catBySlug: (slug) => topCats.find((c) => c.slug === slug),
      countries,
      countryOf: (code) => countries.find((c) => c.code === code),
      settings,
      banners,
      loading,
      error,
      reload,
      country,
      setCountry,
      getCities,
      getDistricts,
      toast,
    };
  }, [categories, countries, settings, banners, loading, error, reload, country, setCountry, getCities, getDistricts, toast]);

  return (
    <Ctx.Provider value={value}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 top-3 z-[100] flex flex-col items-center gap-2 px-3" aria-live="polite">
        {toasts.map((t) => (
          <div
            key={t.id}
            role={t.kind === 'error' ? 'alert' : 'status'}
            className={`pointer-events-auto flex w-full max-w-md animate-rise items-start gap-2.5 rounded-2xl border bg-white px-4 py-3 text-sm font-semibold shadow-pop ${
              t.kind === 'error' ? 'border-[#ffc9bd] text-coral-ink' : t.kind === 'info' ? 'border-brand-200 text-brand-800' : 'border-[#b5ecd3] text-mint-ink'
            }`}
          >
            {t.kind === 'error' ? <AlertTriangle size={18} className="mt-0.5 shrink-0" /> : t.kind === 'info' ? <Info size={18} className="mt-0.5 shrink-0" /> : <CheckCircle2 size={18} className="mt-0.5 shrink-0" />}
            <span className="min-w-0 flex-1 break-words text-ink">{t.msg}</span>
            <button aria-label="Bildirimi kapat" className="-mr-1 rounded-md p-0.5 text-muted hover:text-ink" onClick={() => setToasts((x) => x.filter((y) => y.id !== t.id))}>
              <X size={16} />
            </button>
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}

export function useApp() {
  const v = useContext(Ctx);
  if (!v) throw new Error('useApp must be used inside AppProvider');
  return v;
}
