export interface FilterDef {
  key: string;
  label: string;
  type: 'select' | 'number' | 'text';
  options?: string[];
  unit?: string;
  min?: number;
  max?: number;
  only?: number[];
}

export interface Category {
  id: number;
  parent_id: number | null;
  slug: string;
  name: string;
  icon: string | null;
  color: string | null;
  sort_order: number;
  filters: FilterDef[] | null;
}

export interface Country {
  code: string;
  name: string;
  currency: string;
  currency_symbol: string;
  phone_prefix: string;
  region_label: string;
  district_label: string;
  is_active?: boolean;
}

export interface City { id: number; name: string; country_code: string; sort_order: number }
export interface District { id: number; name: string; city_id: number }

export interface HouseAd { image_url: string; mobile_image_url: string; link_url: string; title: string; is_active: boolean }

export interface AdsConfig { enabled: boolean; client: string; slots: Record<string, string> }

export interface Settings {
  free_listing_count: number;
  paid_listings_enabled: boolean;
  listing_fee: number;
  featured_sales_enabled: boolean;
  featured_fee: number;
  featured_days: number;
  showcase_sales_enabled: boolean;
  showcase_fee: number;
  showcase_days: number;
  moderation_enabled: boolean;
  max_photos: number;
  paytr_ready: boolean;
  ads: AdsConfig;
  house_ads: Record<string, HouseAd>;
  company_name: string;
  company_address: string;
  contact_email: string;
  contact_phone: string;
}

export interface Banner {
  id: number;
  title: string;
  subtitle: string | null;
  image_url: string | null;
  link_url: string | null;
  cta_label: string | null;
  sort_order: number;
  is_active?: boolean;
}

export type ListingStatus = 'active' | 'pending' | 'pending_payment' | 'rejected' | 'passive' | 'under_review' | 'suspended';

export interface Card {
  id: number;
  user_id: string;
  title: string;
  price: number;
  currency: string;
  country_code: string;
  city_name: string | null;
  district_name: string | null;
  condition: 'new' | 'used';
  cover: string | null;
  photo_count: number;
  date: string;
  view_count: number;
  category_id: number;
  subcategory_id: number;
  status: ListingStatus;
  is_featured: boolean;
  is_showcase: boolean;
}

export interface MyListing extends Card {
  created_at: string;
  reject_reason: string | null;
  featured_until: string | null;
  showcase_until: string | null;
  is_paid: boolean;
}

export interface ListingDetail {
  id: number;
  user_id: string;
  title: string;
  description: string;
  price: number;
  currency: string;
  category_id: number;
  subcategory_id: number;
  country_code: string;
  city_id: number;
  district_id: number;
  city_name: string | null;
  district_name: string | null;
  condition: 'new' | 'used';
  images: string[];
  attributes: Record<string, string | number>;
  status: ListingStatus;
  view_count: number;
  date: string;
  created_at: string;
  is_featured: boolean;
  is_showcase: boolean;
  reject_reason?: string | null;
  featured_until?: string | null;
  showcase_until?: string | null;
  is_paid?: boolean;
  flags?: string[];
}

export interface SellerPublic {
  id: string;
  full_name: string;
  avatar_url: string | null;
  created_at: string;
  city_name: string | null;
  bio?: string | null;
  has_phone: boolean;
  whatsapp?: boolean;
  active_count?: number;
}

export interface Profile {
  id: string;
  email: string;
  full_name: string | null;
  phone: string | null;
  show_phone: boolean;
  whatsapp: boolean;
  avatar_url: string | null;
  country_code: string;
  city_id: number | null;
  city_name: string | null;
  bio: string | null;
  is_admin: boolean;
  is_blocked: boolean;
  block_reason: string | null;
  rt_key: string | null;
  listings_created: number;
  created_at: string;
  can_setup_admin?: boolean;
}

export interface Quota {
  free_total: number;
  used: number;
  free_left: number;
  paid_enabled: boolean;
  listing_fee: number;
  next_requires_payment: boolean;
}

export interface ConversationItem {
  id: string;
  listing_id: number | null;
  listing_title: string | null;
  listing_image: string | null;
  other: { id: string; full_name: string; avatar_url: string | null };
  last_message: string | null;
  last_message_at: string | null;
  last_from_me: boolean;
  unread: number;
  role: 'buyer' | 'seller';
}

export interface ChatMessage { id: number; sender_id: string; body: string; created_at: string }

export interface PaymentRow {
  id: number;
  merchant_oid: string;
  listing_id: number | null;
  listing_title: string | null;
  type: 'listing_fee' | 'featured' | 'showcase';
  amount: number;
  currency: string;
  days: number | null;
  status: 'pending' | 'paid' | 'failed';
  failed_reason: string | null;
  test_mode: boolean;
  created_at: string;
  paid_at: string | null;
  user_email?: string;
  user_id?: string;
}
