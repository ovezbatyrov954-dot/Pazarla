import supabase from './supabase';

export class ApiError extends Error {
  status: number;
  code?: string;
  data?: Record<string, unknown>;
  constructor(message: string, status: number, code?: string, data?: Record<string, unknown>) {
    super(message);
    this.status = status;
    this.code = code;
    this.data = data;
  }
}

interface Opts {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
  body?: unknown;
  anon?: boolean;
  signal?: AbortSignal;
}

// Tüm veri okuma/yazma işlemleri sunucu API'sinden geçer; oturum belirteci Authorization başlığıyla gönderilir.
export async function api<T = any>(path: string, opts: Opts = {}): Promise<T> {
  const headers: Record<string, string> = {};
  if (!opts.anon) {
    const { data } = await supabase.auth.getSession();
    const token = data.session?.access_token;
    if (token) headers.Authorization = `Bearer ${token}`;
  }
  if (opts.body !== undefined) headers['Content-Type'] = 'application/json';
  let res: Response;
  try {
    res = await fetch(`/api/${path}`, {
      method: opts.method || 'GET',
      headers,
      body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
      signal: opts.signal,
    });
  } catch (e) {
    if ((e as Error)?.name === 'AbortError') throw e;
    throw new ApiError('Sunucuya ulaşılamadı. İnternet bağlantınızı kontrol edip tekrar deneyin.', 0, 'NETWORK');
  }
  let json: any = null;
  try {
    json = await res.json();
  } catch {
    /* gövde yok */
  }
  if (!res.ok) {
    const msg = json?.error || (res.status === 413 ? 'Dosya çok büyük.' : 'Bir hata oluştu. Lütfen tekrar deneyin.');
    throw new ApiError(json?.detail ? `${msg} (${json.detail})` : msg, res.status, json?.code, json || undefined);
  }
  return json as T;
}

export const errMsg = (e: unknown) => (e instanceof Error ? e.message : 'Bir hata oluştu.');
