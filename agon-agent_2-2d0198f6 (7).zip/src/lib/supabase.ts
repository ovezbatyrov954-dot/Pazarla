import { createClient } from '@supabase/supabase-js';

// Tarayıcıda yalnızca herkese açık (anon) anahtar bulunur; tüm yazma işlemleri sunucu API'si üzerinden yapılır.
const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL as string,
  import.meta.env.VITE_SUPABASE_ANON_KEY as string,
  { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } },
);

export default supabase;
