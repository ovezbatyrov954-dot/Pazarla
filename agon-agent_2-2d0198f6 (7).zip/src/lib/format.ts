import type { ListingStatus } from './types';

const SYMBOL: Record<string, string> = { TRY: 'TL', CNY: '¥', USD: '$', EUR: '€' };

export function formatPrice(price: number, currency = 'TRY') {
  const n = new Intl.NumberFormat('tr-TR', { maximumFractionDigits: price % 1 === 0 ? 0 : 2 }).format(price);
  const s = SYMBOL[currency] || currency;
  return currency === 'TRY' ? `${n} ${s}` : `${s}${n}`;
}

export const formatNumber = (n: number) => new Intl.NumberFormat('tr-TR').format(n);

export function formatDate(iso: string | null | undefined) {
  if (!iso) return '';
  const d = new Date(iso);
  const now = new Date();
  const startOf = (x: Date) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const days = Math.round((startOf(now) - startOf(d)) / 864e5);
  if (days <= 0) return 'Bugün';
  if (days === 1) return 'Dün';
  if (days < 7) return `${days} gün önce`;
  return d.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: d.getFullYear() === now.getFullYear() ? undefined : 'numeric' });
}

export const formatFullDate = (iso: string | null | undefined) =>
  iso ? new Date(iso).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' }) : '';

export const formatDateTime = (iso: string | null | undefined) =>
  iso ? new Date(iso).toLocaleString('tr-TR', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '';

export const formatTime = (iso: string) => new Date(iso).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });

export function formatChatDay(iso: string) {
  const d = new Date(iso);
  const now = new Date();
  if (d.toDateString() === now.toDateString()) return 'Bugün';
  const y = new Date(now.getTime() - 864e5);
  if (d.toDateString() === y.toDateString()) return 'Dün';
  return d.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' });
}

export const memberSince = (iso: string) => new Date(iso).toLocaleDateString('tr-TR', { month: 'long', year: 'numeric' });

export const slugify = (s: string) =>
  s.replace(/İ/g, 'i').replace(/I/g, 'i').toLowerCase()
    .replace(/ç/g, 'c').replace(/ğ/g, 'g').replace(/ı/g, 'i').replace(/ö/g, 'o').replace(/ş/g, 's').replace(/ü/g, 'u')
    .replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

export const thumbOf = (url: string) => url.replace(/\.jpg$/, '_t.jpg');

export const initials = (name: string | null | undefined) =>
  (name || 'P').trim().split(/\s+/).slice(0, 2).map((w) => w[0]?.toLocaleUpperCase('tr-TR') || '').join('') || 'P';

export const STATUS: Record<ListingStatus, { label: string; cls: string; hint: string }> = {
  active: { label: 'Yayında', cls: 'bg-mint-soft text-mint-ink', hint: 'İlanınız yayında ve aramalarda görünüyor.' },
  pending: { label: 'Onay bekliyor', cls: 'bg-sun-soft text-sun-ink', hint: 'İlanınız editör onayı bekliyor. Onaylandığında yayına girecek.' },
  pending_payment: { label: 'Ödeme bekliyor', cls: 'bg-brand-50 text-brand-700', hint: 'İlan ücreti ödendikten ve ödeme doğrulandıktan sonra işleme alınır.' },
  rejected: { label: 'Reddedildi', cls: 'bg-coral-soft text-coral-ink', hint: 'İlanınız reddedildi. Düzenleyip yeniden gönderebilirsiniz.' },
  passive: { label: 'Yayında değil', cls: 'bg-slate-100 text-slate-700', hint: 'İlanı yayından kaldırdınız. Dilediğinizde yeniden yayına alabilirsiniz.' },
  under_review: { label: 'İncelemede', cls: 'bg-coral-soft text-coral-ink', hint: 'İlanınız şikâyetler nedeniyle incelemeye alındı.' },
  suspended: { label: 'Askıda', cls: 'bg-coral-soft text-coral-ink', hint: 'İlanınız yönetici tarafından askıya alındı.' },
};

export const PAYMENT_TYPE: Record<string, string> = {
  listing_fee: 'İlan yayınlama ücreti',
  featured: 'Öne çıkarma',
  showcase: 'Vitrin ilanı',
};

export const REPORT_REASONS: { value: string; label: string }[] = [
  { value: 'sahte_ilan', label: 'Sahte veya yanıltıcı ilan' },
  { value: 'dolandiricilik', label: 'Dolandırıcılık şüphesi (kapora, ön ödeme isteği vb.)' },
  { value: 'yasakli_urun', label: 'Satışı yasak ürün' },
  { value: 'yanlis_kategori', label: 'Yanlış kategori' },
  { value: 'uygunsuz_icerik', label: 'Uygunsuz içerik veya fotoğraf' },
  { value: 'mukerrer', label: 'Tekrarlanan (mükerrer) ilan' },
  { value: 'diger', label: 'Diğer' },
];

export const FLAG_LABEL: Record<string, string> = {
  supheli_ifade: 'Şüpheli ifade',
  yasakli_urun_suphesi: 'Yasaklı ürün şüphesi',
  baglanti_iceriyor: 'Bağlantı içeriyor',
  baslikta_telefon: 'Başlıkta telefon',
  buyuk_harf: 'Büyük harf kullanımı',
  tekrarli_karakter: 'Tekrarlı karakter',
  supheli_dusuk_fiyat: 'Şüpheli düşük fiyat',
  yeni_hesap_cok_ilan: 'Yeni hesap, çok ilan',
  supheli_kullanici: 'Şüpheli kullanıcı',
  kategori_uyumsuz: 'Kategori uyumsuz olabilir',
};

export function passwordIssues(pw: string): string[] {
  const out: string[] = [];
  if (pw.length < 8) out.push('en az 8 karakter');
  if (!/[a-zçğıöşü]/.test(pw)) out.push('bir küçük harf');
  if (!/[A-ZÇĞİÖŞÜ]/.test(pw)) out.push('bir büyük harf');
  if (!/\d/.test(pw)) out.push('bir rakam');
  return out;
}
