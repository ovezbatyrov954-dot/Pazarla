// Fotoğraflar yüklenmeden önce tarayıcıda küçültülüp JPEG'e dönüştürülür (konum gibi EXIF verileri de böylece silinir).

async function loadBitmap(file: File): Promise<{ source: CanvasImageSource; w: number; h: number; close: () => void }> {
  if ('createImageBitmap' in window) {
    try {
      const bmp = await createImageBitmap(file, { imageOrientation: 'from-image' });
      return { source: bmp, w: bmp.width, h: bmp.height, close: () => bmp.close() };
    } catch {
      /* yedek yönteme geç */
    }
  }
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error('Bu dosya bir fotoğraf olarak açılamadı.'));
      el.src = url;
    });
    return { source: img, w: img.naturalWidth, h: img.naturalHeight, close: () => URL.revokeObjectURL(url) };
  } catch (e) {
    URL.revokeObjectURL(url);
    throw e;
  }
}

function draw(source: CanvasImageSource, w: number, h: number, maxSide: number, quality: number, square = false) {
  const scale = Math.min(1, maxSide / Math.max(w, h));
  let cw = Math.max(1, Math.round(w * scale));
  let ch = Math.max(1, Math.round(h * scale));
  let sx = 0;
  let sy = 0;
  let sw = w;
  let sh = h;
  if (square) {
    const side = Math.min(w, h);
    sx = (w - side) / 2;
    sy = (h - side) / 2;
    sw = side;
    sh = side;
    cw = Math.min(maxSide, side);
    ch = cw;
  }
  const canvas = document.createElement('canvas');
  canvas.width = cw;
  canvas.height = ch;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Fotoğraf işlenemedi.');
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, cw, ch);
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(source, sx, sy, sw, sh, 0, 0, cw, ch);
  return canvas.toDataURL('image/jpeg', quality);
}

const b64 = (dataUrl: string) => dataUrl.slice(dataUrl.indexOf(',') + 1);

export interface Prepared { main: string; thumb: string; preview: string }

export async function prepareImage(file: File, opts: { maxSide?: number; square?: boolean; minSide?: number } = {}): Promise<Prepared> {
  if (!file.type.startsWith('image/') && !/\.(jpe?g|png|webp|heic|heif|gif|bmp)$/i.test(file.name)) {
    throw new Error('Yalnızca fotoğraf dosyaları yüklenebilir.');
  }
  if (file.size > 30 * 1024 * 1024) throw new Error('Fotoğraf 30 MB’tan büyük olamaz.');
  const { source, w, h, close } = await loadBitmap(file);
  try {
    const minSide = opts.minSide ?? 200;
    if (w < minSide || h < minSide) throw new Error(`Fotoğraf çok küçük (en az ${minSide} piksel olmalı).`);
    const maxSide = opts.maxSide || 1600;
    let main = draw(source, w, h, maxSide, 0.82, opts.square);
    if (main.length > 2_600_000) main = draw(source, w, h, maxSide, 0.68, opts.square);
    if (main.length > 2_600_000) main = draw(source, w, h, Math.round(maxSide * 0.75), 0.62, opts.square);
    const thumb = draw(source, w, h, 520, 0.74, opts.square);
    return { main: b64(main), thumb: b64(thumb), preview: thumb };
  } finally {
    close();
  }
}
