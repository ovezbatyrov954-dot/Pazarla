import { Link } from 'react-router-dom';
import { Compass } from 'lucide-react';
import { useTitle } from '../components/ui';

export default function NotFound() {
  useTitle('Sayfa bulunamadı');
  return (
    <div className="wrap flex min-h-[55vh] flex-col items-center justify-center gap-4 py-16 text-center">
      <div className="grid h-16 w-16 place-items-center rounded-3xl bg-brand-50 text-brand-600">
        <Compass size={30} />
      </div>
      <h1 className="text-3xl font-extrabold text-ink">Sayfa bulunamadı</h1>
      <p className="max-w-md text-muted">Aradığınız sayfa taşınmış, kaldırılmış ya da hiç var olmamış olabilir.</p>
      <div className="flex flex-wrap justify-center gap-2">
        <Link to="/" className="btn btn-primary">Ana sayfaya dön</Link>
        <Link to="/ilanlar" className="btn btn-outline">İlanlara göz at</Link>
      </div>
    </div>
  );
}
