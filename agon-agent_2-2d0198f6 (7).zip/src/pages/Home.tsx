import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, ChevronLeft, ChevronRight, PackageOpen, Plus, Star, Zap } from 'lucide-react';
import { api, errMsg } from '../lib/api';
import type { Card } from '../lib/types';
import { useApp } from '../contexts/AppContext';
import ListingCard, { CardGrid, CardSkeleton } from '../components/ListingCard';
import CategoryIcon from '../components/CategoryIcon';
import AdSlot from '../components/AdSlot';
import { EmptyState, ErrorBox, useTitle } from '../components/ui';

interface HomeData { showcase: Card[]; featured: Card[]; latest: Card[]; total: number }

function Hero() {
  const { banners } = useApp();
  const [idx, setIdx] = useState(0);

  useEffect(() => {
    if (banners.length < 2) return;
    const t = window.setInterval(() => setIdx((i) => (i + 1) % banners.length), 7000);
    return () => window.clearInterval(t);
  }, [banners.length]);

  if (banners.length > 0) {
    const b = banners[idx % banners.length];
    const inner = (
      <>
        {b.image_url && <img src={b.image_url} alt="" className="absolute inset-0 h-full w-full object-cover" />}
        <div className={`absolute inset-0 ${b.image_url ? 'bg-gradient-to-r from-brand-950/90 via-brand-900/65 to-brand-900/10' : 'hero-grid bg-gradient-to-br from-brand-600 to-brand-900'}`} />
        <div className="relative flex min-h-[230px] flex-col justify-center gap-3 p-6 sm:min-h-[300px] sm:p-10 lg:p-14">
          <h1 className="max-w-2xl text-3xl font-extrabold leading-[1.05] text-white sm:text-5xl">{b.title}</h1>
          {b.subtitle && <p className="max-w-xl text-base text-brand-100 sm:text-lg">{b.subtitle}</p>}
          {b.link_url && (
            <span className="btn btn-sun mt-2 self-start">
              {b.cta_label || 'İncele'} <ArrowRight size={17} />
            </span>
          )}
        </div>
      </>
    );
    return (
      <section aria-label="Duyurular" className="relative overflow-hidden rounded-[1.75rem] bg-brand-800">
        {b.link_url ? (
          b.link_url.startsWith('/') ? <Link to={b.link_url} className="block">{inner}</Link> : <a href={b.link_url} target="_blank" rel="noopener noreferrer" className="block">{inner}</a>
        ) : inner}
        {banners.length > 1 && (
          <div className="absolute bottom-3 right-3 flex items-center gap-1.5">
            <button onClick={() => setIdx((i) => (i - 1 + banners.length) % banners.length)} aria-label="Önceki duyuru" className="grid h-9 w-9 place-items-center rounded-full bg-white/90 text-ink hover:bg-white"><ChevronLeft size={18} /></button>
            <span className="rounded-full bg-ink/60 px-2 py-1 text-xs font-bold text-white">{(idx % banners.length) + 1} / {banners.length}</span>
            <button onClick={() => setIdx((i) => (i + 1) % banners.length)} aria-label="Sonraki duyuru" className="grid h-9 w-9 place-items-center rounded-full bg-white/90 text-ink hover:bg-white"><ChevronRight size={18} /></button>
          </div>
        )}
      </section>
    );
  }

  // Banner yoksa sayfa doğrudan kategorilerle başlar.
  return <h1 className="sr-only">PAZARLA — kategoriler ve son eklenen ilanlar</h1>;
}

function Row({ title, icon, items, to }: { title: string; icon: React.ReactNode; items: Card[]; to?: string }) {
  if (!items.length) return null;
  return (
    <section className="mt-12">
      <div className="mb-4 flex items-end justify-between gap-3">
        <h2 className="flex items-center gap-2 text-2xl font-extrabold text-ink">{icon}{title}</h2>
        {to && <Link to={to} className="shrink-0 text-sm font-bold text-brand-700 hover:underline">Tümünü gör →</Link>}
      </div>
      <div className="no-scrollbar -mx-4 flex snap-x gap-3 overflow-x-auto px-4 pb-2 sm:mx-0 sm:grid sm:grid-cols-3 sm:gap-4 sm:overflow-visible sm:px-0 lg:grid-cols-4 xl:grid-cols-5">
        {items.map((it) => (
          <div key={it.id} className="w-[46vw] max-w-[230px] shrink-0 snap-start sm:w-auto sm:max-w-none">
            <ListingCard item={it} />
          </div>
        ))}
      </div>
    </section>
  );
}

export default function Home() {
  useTitle(null);
  const { topCats, country, banners } = useApp();
  const [data, setData] = useState<HomeData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await api<HomeData>(`listings?action=home&country=${country}`, { anon: true }));
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [country]);

  return (
    <div className="wrap pt-4 sm:pt-6">
      <Hero />

      {/* Küçük reklam alanı: yöneticinin kendi reklamı */}
      <AdSlot placement="home" only="house" compact className={banners.length ? 'mt-4' : 'mb-5'} />

      <section className={banners.length ? 'mt-10' : 'mt-1'} aria-labelledby="cats-h">
        <div className="mb-4 flex items-end justify-between gap-3">
          <h2 id="cats-h" className="text-2xl font-extrabold text-ink">Kategoriler</h2>
          <Link to="/ilanlar" className="text-sm font-bold text-brand-700 hover:underline">Tüm ilanlar →</Link>
        </div>
        <ul className="grid grid-cols-2 gap-2.5 sm:grid-cols-4 sm:gap-3 lg:grid-cols-5">
          {topCats.map((c, i) => (
            <li key={c.id} className="animate-rise" style={{ animationDelay: `${Math.min(i, 12) * 30}ms` }}>
              <Link to={`/kategori/${c.slug}`} className="group flex h-full items-center gap-3 rounded-2xl border border-line bg-white p-3 transition-all hover:-translate-y-0.5 hover:border-brand-300 hover:shadow-card">
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl text-white transition-transform group-hover:scale-105" style={{ background: c.color || '#1447E6' }}>
                  <CategoryIcon name={c.icon} size={22} />
                </span>
                <span className="text-[0.86rem] font-bold leading-tight text-ink">{c.name}</span>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      {/* Küçük Google banner alanı (AdSense) */}
      <AdSlot placement="home" only="adsense" compact className="mt-8" />

      {error ? (
        <div className="mt-12"><ErrorBox message={error} onRetry={load} /></div>
      ) : loading ? (
        <section className="mt-12" aria-busy="true">
          <div className="skeleton mb-4 h-8 w-48" />
          <CardGrid>{Array.from({ length: 10 }).map((_, i) => <CardSkeleton key={i} />)}</CardGrid>
        </section>
      ) : data ? (
        <>
          <Row title="Vitrin" icon={<Star size={22} className="text-sun" fill="currentColor" />} items={data.showcase} />
          <Row title="Öne çıkan ilanlar" icon={<Zap size={22} className="text-sun" fill="currentColor" />} items={data.featured} />
          <section className="mt-12" aria-labelledby="latest-h">
            <div className="mb-4 flex items-end justify-between gap-3">
              <h2 id="latest-h" className="text-2xl font-extrabold text-ink">Son eklenen ilanlar</h2>
              {data.latest.length > 0 && <Link to="/ilanlar" className="shrink-0 text-sm font-bold text-brand-700 hover:underline">Tümünü gör →</Link>}
            </div>
            {data.latest.length ? (
              <CardGrid>{data.latest.map((it) => <ListingCard key={it.id} item={it} />)}</CardGrid>
            ) : (
              <EmptyState
                icon={<PackageOpen size={26} />}
                title="Henüz yayında ilan yok"
                text="PAZARLA yeni açıldı. İlk ilanı siz verin; burada görünsün."
                action={<Link to="/ilan-ver" className="btn btn-sun mt-1"><Plus size={18} strokeWidth={2.8} /> İlk ilanı ver</Link>}
              />
            )}
          </section>
        </>
      ) : null}
    </div>
  );
}
