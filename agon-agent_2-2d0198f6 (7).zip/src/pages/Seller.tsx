import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { CalendarDays, MapPin, PackageOpen, Phone } from 'lucide-react';
import { api, errMsg } from '../lib/api';
import type { Card, SellerPublic } from '../lib/types';
import ListingCard, { CardGrid } from '../components/ListingCard';
import { Avatar, EmptyState, ErrorBox, PageLoader, useTitle } from '../components/ui';
import { memberSince } from '../lib/format';

export default function Seller() {
  const { id } = useParams();
  const [data, setData] = useState<{ seller: SellerPublic; items: Card[] } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  useTitle(data ? `${data.seller.full_name} ilanları` : 'Satıcı');

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await api(`user?action=seller&id=${id}`, { anon: true }));
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (loading) return <PageLoader />;
  if (error || !data) return <div className="wrap py-16"><ErrorBox message={error || 'Satıcı bulunamadı.'} onRetry={load} /></div>;
  const s = data.seller;
  return (
    <div className="wrap pt-5 sm:pt-8">
      <section className="relative overflow-hidden rounded-[1.75rem] bg-gradient-to-br from-brand-600 to-brand-900 p-6 text-white sm:p-9">
        <div className="hero-grid absolute inset-0" aria-hidden="true" />
        <div className="relative flex flex-col gap-4 sm:flex-row sm:items-center">
          <div className="rounded-full ring-4 ring-white/25"><Avatar name={s.full_name} url={s.avatar_url} size={84} /></div>
          <div className="min-w-0">
            <h1 className="break-words text-3xl font-extrabold">{s.full_name}</h1>
            <ul className="mt-2 flex flex-wrap gap-x-5 gap-y-1.5 text-sm font-medium text-brand-100">
              <li className="flex items-center gap-1.5"><CalendarDays size={15} /> {memberSince(s.created_at)} tarihinden beri üye</li>
              {s.city_name && <li className="flex items-center gap-1.5"><MapPin size={15} /> {s.city_name}</li>}
              <li className="flex items-center gap-1.5"><PackageOpen size={15} /> {data.items.length} yayında ilan</li>
              {s.has_phone && <li className="flex items-center gap-1.5"><Phone size={15} /> Telefonla ulaşılabilir</li>}
            </ul>
            {s.bio && <p className="mt-3 max-w-2xl whitespace-pre-line text-[0.95rem] leading-relaxed text-white/90">{s.bio}</p>}
          </div>
        </div>
      </section>
      <h2 className="mb-4 mt-8 text-2xl font-extrabold text-ink">Satıcının ilanları</h2>
      {data.items.length ? (
        <CardGrid>{data.items.map((it) => <ListingCard key={it.id} item={it} />)}</CardGrid>
      ) : (
        <EmptyState icon={<PackageOpen size={26} />} title="Yayında ilan yok" text="Bu satıcının şu anda yayında ilanı bulunmuyor." />
      )}
    </div>
  );
}
