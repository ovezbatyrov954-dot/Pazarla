import { useEffect, useState } from 'react';
import { Link, Navigate, useNavigate, useSearchParams } from 'react-router-dom';
import { Check, Eye, EyeOff, MailCheck, MessagesSquare, ShieldCheck, Tag } from 'lucide-react';
import supabase from '../lib/supabase';
import { googleEnabled, signInWithGoogle } from '../lib/googleAuth';
import { useAuth } from '../contexts/AuthContext';
import { useApp } from '../contexts/AppContext';
import Logo from '../components/Logo';
import { Field, PageLoader, Spinner, useTitle } from '../components/ui';
import { passwordIssues } from '../lib/format';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function trError(message: string) {
  const m = message.toLowerCase();
  if (m.includes('invalid login credentials')) return 'E-posta veya şifre hatalı.';
  if (m.includes('already registered') || m.includes('already been registered')) return 'Bu e-posta adresiyle kayıtlı bir hesap var. Giriş yapmayı deneyin.';
  if (m.includes('email not confirmed')) return 'E-posta adresiniz henüz doğrulanmamış. Gelen kutunuzdaki bağlantıya tıklayın.';
  if (m.includes('banned')) return 'Bu hesap engellenmiştir.';
  if (m.includes('rate limit') || m.includes('too many') || m.includes('security purposes')) return 'Çok fazla deneme yapıldı. Lütfen birkaç dakika sonra tekrar deneyin.';
  if (m.includes('weak') || m.includes('password should')) return 'Şifre yeterince güçlü değil. Daha uzun ve karmaşık bir şifre seçin.';
  if (m.includes('different from the old')) return 'Yeni şifreniz eski şifrenizden farklı olmalı.';
  if (m.includes('invalid email') || m.includes('email address') ) return 'Geçerli bir e-posta adresi girin.';
  if (m.includes('failed to fetch') || m.includes('network')) return 'Sunucuya ulaşılamadı. İnternet bağlantınızı kontrol edin.';
  return 'İşlem tamamlanamadı. Lütfen bilgilerinizi kontrol edip tekrar deneyin.';
}

const safeNext = (v: string | null) => (v && v.startsWith('/') && !v.startsWith('//') ? v : '/');

function Shell({ title, subtitle, children }: { title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <div className="wrap py-6 sm:py-12">
      <div className="mx-auto grid max-w-5xl overflow-hidden rounded-[1.75rem] border border-line bg-white shadow-card lg:grid-cols-[0.9fr_1.1fr]">
        <div className="relative hidden overflow-hidden bg-gradient-to-br from-brand-600 to-brand-900 p-10 text-white lg:block">
          <div className="hero-grid absolute inset-0" aria-hidden="true" />
          <div className="relative">
            <Logo light size={40} />
            <p className="mt-10 font-display text-4xl font-extrabold leading-[1.05]">Al, sat,<br /><span className="text-sun">pazarla.</span></p>
            <ul className="mt-10 flex flex-col gap-5 text-[0.95rem] text-brand-100">
              <li className="flex gap-3"><Tag size={20} className="mt-0.5 shrink-0 text-sun" /> Dakikalar içinde fotoğraflı ilan verin.</li>
              <li className="flex gap-3"><MessagesSquare size={20} className="mt-0.5 shrink-0 text-sun" /> Alıcı ve satıcıyla anında mesajlaşın.</li>
              <li className="flex gap-3"><ShieldCheck size={20} className="mt-0.5 shrink-0 text-sun" /> Şüpheli ilanlar denetlenir ve şikâyet edilebilir.</li>
            </ul>
          </div>
        </div>
        <div className="p-6 sm:p-10">
          <h1 className="text-[1.75rem] font-extrabold leading-tight text-ink">{title}</h1>
          {subtitle && <p className="mt-1.5 text-muted">{subtitle}</p>}
          <div className="mt-6">{children}</div>
        </div>
      </div>
    </div>
  );
}

function PasswordInput({ id, value, onChange, error, autoComplete }: { id: string; value: string; onChange: (v: string) => void; error?: boolean; autoComplete: string }) {
  const [show, setShow] = useState(false);
  return (
    <div className="relative">
      <input id={id} type={show ? 'text' : 'password'} className={`input !pr-12 ${error ? 'input-error' : ''}`} value={value} onChange={(e) => onChange(e.target.value)} autoComplete={autoComplete} maxLength={72} />
      <button type="button" onClick={() => setShow((s) => !s)} aria-label={show ? 'Şifreyi gizle' : 'Şifreyi göster'} aria-pressed={show} className="absolute right-1.5 top-1/2 grid h-9 w-9 -translate-y-1/2 place-items-center rounded-lg text-muted hover:bg-surface hover:text-ink">
        {show ? <EyeOff size={18} /> : <Eye size={18} />}
      </button>
    </div>
  );
}

function PasswordRules({ pw }: { pw: string }) {
  const rules = [
    { ok: pw.length >= 8, t: 'En az 8 karakter' },
    { ok: /[a-zçğıöşü]/.test(pw) && /[A-ZÇĞİÖŞÜ]/.test(pw), t: 'Büyük ve küçük harf' },
    { ok: /\d/.test(pw), t: 'En az bir rakam' },
  ];
  return (
    <ul className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[0.8rem] font-semibold">
      {rules.map((r) => (
        <li key={r.t} className={`flex items-center gap-1 ${r.ok ? 'text-mint-ink' : 'text-muted'}`}>
          <Check size={13} strokeWidth={3} className={r.ok ? '' : 'opacity-30'} /> {r.t}
        </li>
      ))}
    </ul>
  );
}

export function Login({ mode }: { mode: 'login' | 'signup' }) {
  const signup = mode === 'signup';
  useTitle(signup ? 'Üye ol' : 'Giriş yap');
  const { user, loading } = useAuth();
  const { toast } = useApp();
  const nav = useNavigate();
  const [sp] = useSearchParams();
  const next = safeNext(sp.get('next'));
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [accept, setAccept] = useState(false);
  const [errors, setErrors] = useState<Record<string, string | null>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);

  useEffect(() => {
    setErrors({});
    setFormError(null);
  }, [mode]);

  if (loading) return <PageLoader />;
  if (user) return <Navigate to={next} replace />;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const er: Record<string, string | null> = {};
    const mail = email.trim().toLowerCase();
    if (!EMAIL_RE.test(mail)) er.email = 'Geçerli bir e-posta adresi girin.';
    if (signup) {
      if (name.trim().length < 2) er.name = 'Adınızı ve soyadınızı girin.';
      const issues = passwordIssues(pw);
      if (issues.length) er.pw = `Şifrenizde şunlar eksik: ${issues.join(', ')}.`;
      if (!accept) er.accept = 'Devam etmek için koşulları kabul etmelisiniz.';
    } else if (!pw) er.pw = 'Şifrenizi girin.';
    setErrors(er);
    setFormError(null);
    if (Object.values(er).some(Boolean)) return;
    setBusy(true);
    try {
      if (signup) {
        const { data, error } = await supabase.auth.signUp({
          email: mail,
          password: pw,
          options: { data: { full_name: name.trim().replace(/\s+/g, ' ').slice(0, 60) }, emailRedirectTo: `${window.location.origin}/giris` },
        });
        if (error) throw error;
        if (data.session) {
          toast('Hoş geldiniz! Hesabınız oluşturuldu.');
          nav(next, { replace: true });
        } else if (data.user && data.user.identities && data.user.identities.length === 0) {
          setFormError('Bu e-posta adresiyle kayıtlı bir hesap var. Giriş yapmayı deneyin.');
        } else {
          setSent(true);
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: mail, password: pw });
        if (error) throw error;
        nav(next, { replace: true });
      }
    } catch (err) {
      setFormError(trError((err as Error).message || ''));
    } finally {
      setBusy(false);
    }
  };

  if (sent) {
    return (
      <Shell title="E-postanızı doğrulayın">
        <div className="flex items-start gap-3 rounded-2xl bg-mint-soft p-4 text-sm font-semibold leading-relaxed text-ink">
          <MailCheck size={22} className="mt-0.5 shrink-0 text-mint-ink" />
          <span><strong>{email}</strong> adresine bir doğrulama bağlantısı gönderdik. Bağlantıya tıkladıktan sonra giriş yapabilirsiniz. E-posta gelmediyse gereksiz (spam) klasörünü kontrol edin.</span>
        </div>
        <Link to="/giris" className="btn btn-primary mt-5">Giriş sayfasına dön</Link>
      </Shell>
    );
  }

  const qs = next !== '/' ? `?next=${encodeURIComponent(next)}` : '';
  return (
    <Shell title={signup ? 'Ücretsiz üye olun' : 'Tekrar hoş geldiniz'} subtitle={signup ? 'İlan vermek, mesajlaşmak ve favori eklemek için hesap oluşturun.' : 'Hesabınıza giriş yapın.'}>
      <form onSubmit={submit} noValidate className="flex flex-col gap-4">
        {signup && (
          <Field label="Ad soyad" htmlFor="a-name" error={errors.name} required>
            <input id="a-name" className={`input ${errors.name ? 'input-error' : ''}`} value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" maxLength={60} />
          </Field>
        )}
        <Field label="E-posta" htmlFor="a-email" error={errors.email} required>
          <input id="a-email" type="email" inputMode="email" className={`input ${errors.email ? 'input-error' : ''}`} value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" autoCapitalize="none" spellCheck={false} maxLength={120} />
        </Field>
        <div>
          <div className="flex items-baseline justify-between">
            <label className="label" htmlFor="a-pw">Şifre<span className="ml-0.5 text-coral-ink" aria-hidden="true">*</span></label>
            {!signup && <Link to="/sifremi-unuttum" className="text-[0.82rem] font-bold text-brand-700 hover:underline">Şifremi unuttum</Link>}
          </div>
          <PasswordInput id="a-pw" value={pw} onChange={setPw} error={!!errors.pw} autoComplete={signup ? 'new-password' : 'current-password'} />
          {signup && <PasswordRules pw={pw} />}
          {errors.pw && <p role="alert" className="mt-1.5 text-[0.82rem] font-semibold text-coral-ink">{errors.pw}</p>}
        </div>
        {signup && (
          <div>
            <label className="flex cursor-pointer items-start gap-2.5 text-[0.86rem] leading-relaxed text-ink-soft">
              <input type="checkbox" checked={accept} onChange={(e) => setAccept(e.target.checked)} className="mt-1 h-4 w-4 shrink-0 accent-[#1447e6]" />
              <span>
                <Link to="/kullanim-kosullari" target="_blank" className="font-bold text-brand-700 underline">Kullanım koşullarını</Link> kabul ediyorum;{' '}
                <Link to="/kvkk" target="_blank" className="font-bold text-brand-700 underline">KVKK aydınlatma metnini</Link> ve{' '}
                <Link to="/gizlilik" target="_blank" className="font-bold text-brand-700 underline">gizlilik politikasını</Link> okudum.
              </span>
            </label>
            {errors.accept && <p role="alert" className="mt-1.5 text-[0.82rem] font-semibold text-coral-ink">{errors.accept}</p>}
          </div>
        )}
        {formError && <p role="alert" className="rounded-xl bg-coral-soft px-4 py-3 text-sm font-bold text-coral-ink">{formError}</p>}
        <button type="submit" className="btn btn-primary btn-lg w-full" disabled={busy}>
          {busy && <Spinner size={18} />} {signup ? 'Hesap oluştur' : 'Giriş yap'}
        </button>
      </form>
      {googleEnabled() && (
        <>
          <div className="my-5 flex items-center gap-3 text-xs font-bold uppercase tracking-wider text-muted"><span className="h-px flex-1 bg-line" />veya<span className="h-px flex-1 bg-line" /></div>
          <button type="button" onClick={() => signInWithGoogle('PAZARLA')} className="btn btn-outline btn-lg w-full">
            <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.5 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.2C12.4 13.6 17.7 9.5 24 9.5z" /><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.5 5.8c4.4-4.1 7.1-10.1 7.1-17.5z" /><path fill="#FBBC05" d="M10.5 28.6c-.5-1.5-.8-3-.8-4.6s.3-3.1.8-4.6l-7.9-6.2C.9 16.5 0 20.1 0 24s.9 7.5 2.6 10.8l7.9-6.2z" /><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.5-5.8c-2.1 1.4-4.8 2.3-8.4 2.3-6.3 0-11.6-4.1-13.5-9.9l-7.9 6.2C6.5 42.6 14.6 48 24 48z" /></svg>
            Google ile devam et
          </button>
        </>
      )}
      <p className="mt-6 text-center text-sm text-muted">
        {signup ? 'Zaten hesabınız var mı?' : 'Henüz hesabınız yok mu?'}{' '}
        <Link to={`${signup ? '/giris' : '/kayit'}${qs}`} className="font-bold text-brand-700 hover:underline">{signup ? 'Giriş yapın' : 'Ücretsiz üye olun'}</Link>
      </p>
    </Shell>
  );
}

export function ForgotPassword() {
  useTitle('Şifremi unuttum');
  const [email, setEmail] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const mail = email.trim().toLowerCase();
    if (!EMAIL_RE.test(mail)) return setError('Geçerli bir e-posta adresi girin.');
    setBusy(true);
    setError(null);
    const { error: err } = await supabase.auth.resetPasswordForEmail(mail, { redirectTo: `${window.location.origin}/sifre-yenile` });
    setBusy(false);
    if (err && /rate limit|too many|security purposes/i.test(err.message)) return setError('Çok fazla istek gönderildi. Lütfen birkaç dakika sonra tekrar deneyin.');
    if (err && /failed to fetch|network/i.test(err.message)) return setError('Sunucuya ulaşılamadı. İnternet bağlantınızı kontrol edin.');
    setSent(true);
  };

  return (
    <Shell title="Şifrenizi sıfırlayın" subtitle="Hesabınıza kayıtlı e-posta adresini yazın; size şifre yenileme bağlantısı gönderelim.">
      {sent ? (
        <>
          <div className="flex items-start gap-3 rounded-2xl bg-mint-soft p-4 text-sm font-semibold leading-relaxed text-ink">
            <MailCheck size={22} className="mt-0.5 shrink-0 text-mint-ink" />
            <span>Bu adresle kayıtlı bir hesap varsa şifre yenileme bağlantısı gönderildi. Birkaç dakika içinde gelmezse gereksiz (spam) klasörünü kontrol edin.</span>
          </div>
          <Link to="/giris" className="btn btn-primary mt-5">Giriş sayfasına dön</Link>
        </>
      ) : (
        <form onSubmit={submit} noValidate className="flex flex-col gap-4">
          <Field label="E-posta" htmlFor="fp-email" error={error} required>
            <input id="fp-email" type="email" inputMode="email" className={`input ${error ? 'input-error' : ''}`} value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" autoCapitalize="none" />
          </Field>
          <button className="btn btn-primary btn-lg w-full" disabled={busy}>{busy && <Spinner size={18} />} Sıfırlama bağlantısı gönder</button>
          <Link to="/giris" className="text-center text-sm font-bold text-brand-700 hover:underline">Giriş sayfasına dön</Link>
        </form>
      )}
    </Shell>
  );
}

export function ResetPassword() {
  useTitle('Yeni şifre belirle');
  const { user, loading } = useAuth();
  const { toast } = useApp();
  const nav = useNavigate();
  const [pw, setPw] = useState('');
  const [pw2, setPw2] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [waited, setWaited] = useState(false);

  // Bağlantıdaki kurtarma belirtecinin oturuma dönüşmesi için kısa bir süre tanı
  useEffect(() => {
    const t = window.setTimeout(() => setWaited(true), 2500);
    return () => window.clearTimeout(t);
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const issues = passwordIssues(pw);
    if (issues.length) return setError(`Şifrenizde şunlar eksik: ${issues.join(', ')}.`);
    if (pw !== pw2) return setError('Şifreler birbiriyle aynı değil.');
    setBusy(true);
    setError(null);
    const { error: err } = await supabase.auth.updateUser({ password: pw });
    setBusy(false);
    if (err) return setError(trError(err.message));
    toast('Şifreniz güncellendi.');
    nav('/hesabim', { replace: true });
  };

  if (loading || (!user && !waited)) return <PageLoader />;
  if (!user) {
    return (
      <Shell title="Bağlantı geçersiz" subtitle="Şifre yenileme bağlantısının süresi dolmuş ya da bağlantı daha önce kullanılmış olabilir.">
        <Link to="/sifremi-unuttum" className="btn btn-primary">Yeni bağlantı iste</Link>
      </Shell>
    );
  }
  return (
    <Shell title="Yeni şifre belirleyin" subtitle={user.email || undefined}>
      <form onSubmit={submit} noValidate className="flex flex-col gap-4">
        <div>
          <label className="label" htmlFor="rp-pw">Yeni şifre</label>
          <PasswordInput id="rp-pw" value={pw} onChange={setPw} autoComplete="new-password" />
          <PasswordRules pw={pw} />
        </div>
        <div>
          <label className="label" htmlFor="rp-pw2">Yeni şifre (tekrar)</label>
          <PasswordInput id="rp-pw2" value={pw2} onChange={setPw2} autoComplete="new-password" />
        </div>
        {error && <p role="alert" className="rounded-xl bg-coral-soft px-4 py-3 text-sm font-bold text-coral-ink">{error}</p>}
        <button className="btn btn-primary btn-lg w-full" disabled={busy}>{busy && <Spinner size={18} />} Şifreyi güncelle</button>
      </form>
    </Shell>
  );
}

export { PasswordInput, PasswordRules, trError };
