import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Clock, Lock, ShieldCheck } from 'lucide-react';
import { api, errMsg } from '../lib/api';
import type { ListingDetail } from '../lib/types';
import { useApp } from '../contexts/AppContext';
import { useAuth } from '../contexts/AuthContext';
import { ErrorBox, Field, PageLoader, Spinner, useTitle } from '../components/ui';
import { formatPrice, PAYMENT_TYPE } from '../lib/format';

declare global {
  interface Window { iFrameResize?: (opts: Record<string, unknown>, selector: string) => void }
}

export default function Payment() {
  useTitle('Ödeme');
  const { type = '', listingId } = useParams();
  const { settings } = useApp();
  const { profile } = useAuth();
  const [listing, setListing] = useState<ListingDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [name, setName] = useState(profile?.full_name || '');
  const [phone, setPhone] = useState(profile?.phone || '');
  const [address, setAddress] = useState('');
  const [errors, setErrors] = useState<Record<string, string | null>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [token, setToken] = useState<string | null>(null);
  const [testMode, setTestMode] = useState(false);

  useEffect(() => {
    let on = true;
    api<{ listing: ListingDetail; is_owner: boolean }>(`listings?id=${listingId}`)
      .then((d) => {
        if (!on) return;
        if (!d.is_owner) setLoadError('Bu ilan size ait değil.');
        else setListing(d.listing);
      })
      .catch((e) => on && setLoadError(errMsg(e)))
      .finally(() => on && setLoading(false));
    return () => { on = false; };
  }, [listingId]);

  // PayTR'nin ödeme formu yüksekliğini ayarlayan resmi betiği (yalnızca ödeme başlatıldığında yüklenir)
  useEffect(() => {
    if (!token) return;
    const s = document.createElement('script');
    s.src = 'https://www.paytr.com/js/iframeResizer.min.js';
    s.onload = () => window.iFrameResize?.({}, '#paytriframe');
    document.body.appendChild(s);
    return () => { s.remove(); };
  }, [token]);

  if (loading) return <PageLoader />;
  const valid = type in PAYMENT_TYPE;
  if (loadError || !listing || !valid || !settings) {
    return <div className="wrap py-16"><ErrorBox message={loadError || 'Geçersiz ödeme bağlantısı.'} /></div>;
  }

  const amount = type === 'listing_fee' ? settings.listing_fee : type === 'featured' ? settings.featured_fee : settings.showcase_fee;
  const days = type === 'featured' ? settings.featured_days : type === 'showcase' ? settings.showcase_days : null;
  const allowed =
    (type === 'listing_fee' && listing.status === 'pending_payment') ||
    (type === 'featured' && settings.featured_sales_enabled && listing.status === 'active') ||
    (type === 'showcase' && settings.showcase_sales_enabled && listing.status === 'active');

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const er: Record<string, string | null> = {};
    if (name.trim().length < 3) er.name = 'Adınızı ve soyadınızı girin.';
    if (phone.replace(/\D/g, '').length < 10) er.phone = 'Geçerli bir telefon numarası girin.';
    if (address.trim().length < 10) er.address = 'Fatura adresinizi girin (en az 10 karakter).';
    setErrors(er);
    setFormError(null);
    if (Object.values(er).some(Boolean)) return;
    setBusy(true);
    try {
      const r = await api<{ iframe_token: string; merchant_oid: string; test_mode: boolean }>('payments?action=create', {
        method: 'POST',
        body: { type, listing_id: listing.id, name: name.trim(), phone, address: address.trim() },
      });
      setTestMode(r.test_mode);
      setToken(r.iframe_token);
    } catch (err) {
      setFormError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="wrap max-w-3xl pt-5 sm:pt-8">
      <h1 className="text-3xl font-extrabold text-ink">Ödeme</h1>
      <div className="card mt-5 p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-extrabold uppercase tracking-wider text-brand-700">{PAYMENT_TYPE[type]}{days ? ` · ${days} gün` : ''}</p>
            <p className="mt-1 truncate font-bold text-ink">{listing.title}</p>
            <Link to={`/ilan/${listing.id}`} className="text-sm font-semibold text-brand-700 hover:underline">İlan #{listing.id}</Link>
          </div>
          {amount > 0 && <p className="font-display text-3xl font-extrabold text-ink">{formatPrice(amount)}</p>}
        </div>
      </div>

      {!settings.paytr_ready ? (
        <div className="mt-5 rounded-3xl border border-sun/70 bg-sun-soft/70 p-6">
          <h2 className="flex items-center gap-2 text-lg font-bold text-ink"><Clock size={20} className="text-sun-ink" /> Online ödeme henüz etkin değil</h2>
          <p className="mt-2 text-sm leading-relaxed text-ink-soft">
            Ödeme altyapısı (PayTR) kurulum aşamasındadır. Şu anda ücretli hizmet satın alınamaz ve sizden herhangi bir ödeme alınmaz. Ödeme sistemi etkinleştirildiğinde bu sayfadan işlem yapabileceksiniz.
          </p>
          <Link to="/hesabim" className="btn btn-outline mt-4">İlanlarıma dön</Link>
        </div>
      ) : !allowed ? (
        <div className="mt-5"><ErrorBox message="Bu ilan için bu ödeme şu anda yapılamıyor. İlanın durumunu kontrol edin." /></div>
      ) : token ? (
        <div className="card mt-5 overflow-hidden p-2 sm:p-4">
          {testMode && <p className="mb-3 rounded-xl bg-sun-soft px-3 py-2 text-sm font-bold text-sun-ink">Test modu: bu işlem gerçek bir tahsilat değildir.</p>}
          <iframe id="paytriframe" title="PayTR güvenli ödeme formu" src={`https://www.paytr.com/odeme/guvenli/${token}`} className="min-h-[640px] w-full" style={{ border: 0 }} />
        </div>
      ) : (
        <form onSubmit={submit} noValidate className="card mt-5 flex flex-col gap-4 p-5 sm:p-6">
          <h2 className="text-lg font-bold text-ink">Fatura bilgileri</h2>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Ad soyad" htmlFor="p-name" error={errors.name} required>
              <input id="p-name" className={`input ${errors.name ? 'input-error' : ''}`} value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" maxLength={60} />
            </Field>
            <Field label="Telefon" htmlFor="p-phone" error={errors.phone} required>
              <input id="p-phone" type="tel" inputMode="tel" className={`input ${errors.phone ? 'input-error' : ''}`} value={phone} onChange={(e) => setPhone(e.target.value)} autoComplete="tel" maxLength={20} placeholder="05xx xxx xx xx" />
            </Field>
          </div>
          <Field label="Fatura adresi" htmlFor="p-address" error={errors.address} required>
            <textarea id="p-address" className={`input !min-h-24 ${errors.address ? 'input-error' : ''}`} value={address} onChange={(e) => setAddress(e.target.value)} autoComplete="street-address" maxLength={400} />
          </Field>
          {formError && <p role="alert" className="rounded-xl bg-coral-soft px-4 py-3 text-sm font-bold text-coral-ink">{formError}</p>}
          <button className="btn btn-primary btn-lg" disabled={busy}>{busy ? <Spinner size={18} /> : <Lock size={18} />} Güvenli ödemeye geç · {formatPrice(amount)}</button>
          <p className="flex items-start gap-2 text-[0.82rem] leading-relaxed text-muted">
            <ShieldCheck size={16} className="mt-0.5 shrink-0 text-brand-600" />
            Kart bilgileriniz PayTR’nin güvenli ödeme sayfasında girilir; PAZARLA kart bilgilerinizi görmez ve saklamaz. Hizmet, ödeme PayTR tarafından doğrulandıktan sonra etkinleşir.
          </p>
        </form>
      )}
    </div>
  );
}
