import { useEffect, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import {
  AlertTriangle, Ban, BarChart3, Database, Download, FolderInput, Smartphone, Camera, Check, CheckCircle2, Copy, CreditCard, Flag, Image as ImageIcon, LayoutList, Megaphone, Pencil, Plus,
  Search, Settings as SettingsIcon, ShieldAlert, ShieldCheck, Star, Trash2, Users, Wrench, X, XCircle, Zap,
} from 'lucide-react';
import { api, errMsg } from '../lib/api';
import { useLoad } from '../lib/useLoad';
import type { Banner, Card, Country, HouseAd, PaymentRow, Settings } from '../lib/types';
import { useApp } from '../contexts/AppContext';
import { useAuth } from '../contexts/AuthContext';
import NotFound from './NotFound';
import { Avatar, EmptyState, ErrorBox, Field, Modal, PageLoader, Pagination, Spinner, Toggle, useTitle } from '../components/ui';
import { prepareImage } from '../lib/image';
import { HouseAdView, setConsent, useConsent } from '../components/AdSlot';
import { FLAG_LABEL, formatDate, formatDateTime, formatNumber, formatPrice, PAYMENT_TYPE, REPORT_REASONS, STATUS } from '../lib/format';

type TabKey = 'ozet' | 'ilanlar' | 'kullanicilar' | 'sikayetler' | 'odemeler' | 'ayarlar' | 'reklam' | 'bannerlar' | 'play' | 'kurulum';

interface Rls { checked: boolean; enforced: boolean; private_read_blocked: boolean; direct_write_blocked: boolean; tables_checked?: number; open_tables?: string[] }
interface Stats {
  users: { total: number; today: number; blocked: number; suspicious: number };
  listings: { total: number; active: number; pending: number; pending_payment: number; rejected: number; under_review: number; passive: number };
  reports: { open: number };
  payments: { paid_count: number; test_count: number; revenue: number; revenue_month: number };
  conversations: number;
  days: { day: string; listings: number; users: number }[];
  integrations: { paytr: boolean; paytr_test_mode: boolean; adsense: boolean; moderation: boolean; rls: Rls };
}
interface AdminListing extends Card {
  description: string;
  created_at: string;
  flags: string[];
  suggested_category_id: number | null;
  reject_reason: string | null;
  report_count: number;
  is_paid: boolean;
  requires_payment: boolean;
  owner: { id: string; full_name: string | null; email: string; is_suspicious: boolean; is_blocked: boolean } | null;
}
interface AdminUser {
  id: string; email: string; full_name: string | null; phone: string | null; avatar_url: string | null; city_name: string | null;
  is_admin: boolean; is_blocked: boolean; is_suspicious: boolean; block_reason: string | null; listings_created: number; created_at: string; last_seen_at: string | null;
}
interface Person { id: string; full_name: string | null; email: string; is_blocked: boolean; is_suspicious: boolean }
interface AdminReport {
  id: number; listing_id: number | null; listing_title: string | null; reason: string; details: string | null; status: string; admin_note: string | null;
  created_at: string; reporter: Person | null; seller: Person | null; listing_status: string | null;
}
interface AllSettings {
  settings: Settings & { ads: { enabled: boolean; client: string; slots: Record<string, string> } };
  ad_placements: string[];
  paytr: { configured: boolean; source: string | null; merchant_id_masked: string; test_mode: boolean; callback_url: string };
  rls: Rls;
  server_key_ok?: boolean;
  countries: Country[];
  source_zip?: string | null;
  android?: { package: string; upload_fingerprint: string; fingerprints: string[]; zip: string | null; key_password?: string | null; assetlinks_url: string; info?: { version?: string; version_code?: number; host?: string }; files?: { kind: string; name: string; url: string; size: number }[] };
}
interface Ask { title: string; text?: string; label?: string; kind: 'text' | 'number' | 'none'; initial?: string; confirm: string; danger?: boolean; onOk: (v: string) => Promise<void> }

// Bu sitenin veritabanının Supabase panelindeki SQL Editor adresi (proje kimliği herkese açık adresten okunur).
const SQL_EDITOR_URL = `https://supabase.com/dashboard/project/${String(import.meta.env.VITE_SUPABASE_URL || '').replace(/^https?:\/\//, '').split('.')[0]}/sql/new`;

function AskModal({ ask, onClose }: { ask: Ask | null; onClose: () => void }) {
  const [v, setV] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => { setV(ask?.initial || ''); setErr(null); setBusy(false); }, [ask]);
  if (!ask) return null;
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    try {
      await ask.onOk(v.trim());
      onClose();
    } catch (er) {
      setErr(errMsg(er));
      setBusy(false);
    }
  };
  return (
    <Modal open onClose={onClose} title={ask.title}>
      <form onSubmit={submit} noValidate>
        {ask.text && <p className="mb-3 text-sm leading-relaxed text-ink-soft">{ask.text}</p>}
        {ask.kind !== 'none' && (
          <>
            <label className="label" htmlFor="ask-input">{ask.label}</label>
            {ask.kind === 'number' ? (
              <input id="ask-input" inputMode="numeric" className="input" value={v} onChange={(e) => setV(e.target.value.replace(/[^\d]/g, ''))} autoFocus />
            ) : (
              <textarea id="ask-input" className="input !min-h-24" value={v} onChange={(e) => setV(e.target.value)} maxLength={300} autoFocus />
            )}
          </>
        )}
        {err && <p role="alert" className="mt-2 text-sm font-semibold text-coral-ink">{err}</p>}
        <div className="mt-5 flex justify-end gap-2">
          <button type="button" className="btn btn-ghost" onClick={onClose}>Vazgeç</button>
          <button className={`btn ${ask.danger ? 'btn-danger-solid' : 'btn-primary'}`} disabled={busy}>{busy && <Spinner size={16} />} {ask.confirm}</button>
        </div>
      </form>
    </Modal>
  );
}

const StatusDot = ({ ok, warn }: { ok: boolean; warn?: boolean }) =>
  ok ? <CheckCircle2 size={18} className="shrink-0 text-mint-ink" /> : warn ? <AlertTriangle size={18} className="shrink-0 text-sun-ink" /> : <XCircle size={18} className="shrink-0 text-coral-ink" />;

/* ------------------------------------------------------------------ Özet */
function Overview({ go }: { go: (t: TabKey) => void }) {
  const { data, loading, error, reload } = useLoad<Stats>('admin?action=stats');
  if (loading && !data) return <PageLoader />;
  if (error || !data) return <ErrorBox message={error || 'İstatistikler yüklenemedi.'} onRetry={reload} />;
  const max = Math.max(1, ...data.days.map((d) => Math.max(d.listings, d.users)));
  const cards = [
    { l: 'Toplam kullanıcı', v: formatNumber(data.users.total), s: `Bugün +${data.users.today}`, icon: <Users size={20} />, tab: 'kullanicilar' as TabKey },
    { l: 'Yayındaki ilan', v: formatNumber(data.listings.active), s: `Toplam ${formatNumber(data.listings.total)} ilan`, icon: <LayoutList size={20} />, tab: 'ilanlar' as TabKey },
    { l: 'Onay bekleyen', v: formatNumber(data.listings.pending), s: data.listings.pending ? 'İnceleme gerekiyor' : 'Bekleyen yok', icon: <Check size={20} />, tab: 'ilanlar' as TabKey, hot: data.listings.pending > 0 },
    { l: 'Açık şikâyet', v: formatNumber(data.reports.open), s: `${data.listings.under_review} ilan incelemede`, icon: <Flag size={20} />, tab: 'sikayetler' as TabKey, hot: data.reports.open > 0 },
  ];
  const i = data.integrations;
  return (
    <div className="flex flex-col gap-5">
      {!i.rls.enforced && (
        <div role="alert" className="flex items-start gap-3 rounded-2xl border border-[#ffc9bd] bg-coral-soft p-4">
          <ShieldAlert size={22} className="mt-0.5 shrink-0 text-coral-ink" />
          <div className="min-w-0">
            <p className="font-bold text-coral-ink">Veritabanı dışarıdan erişime açık</p>
            <p className="mt-1 text-sm leading-relaxed text-ink-soft">Canlı denetim, veritabanına herkese açık anahtarla doğrudan erişilebildiğini gösteriyor. Gerçek kullanıcı almadan önce bu adımı tamamlayın.</p>
            <button onClick={() => go('kurulum')} className="btn btn-danger btn-sm mt-2">Nasıl düzeltilir?</button>
          </div>
        </div>
      )}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {cards.map((c) => (
          <button key={c.l} onClick={() => go(c.tab)} className={`card p-4 text-left transition-colors hover:border-brand-300 ${c.hot ? '!border-sun bg-sun-soft/50' : ''}`}>
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand-50 text-brand-700">{c.icon}</span>
            <p className="mt-3 text-[0.8rem] font-bold text-muted">{c.l}</p>
            <p className="font-display text-3xl font-extrabold text-ink">{c.v}</p>
            <p className="text-[0.78rem] font-semibold text-muted">{c.s}</p>
          </button>
        ))}
      </div>

      <div className="grid gap-5 lg:grid-cols-[1.4fr_1fr]">
        <section className="card p-5">
          <h2 className="text-lg font-bold text-ink">Son 14 gün</h2>
          <div className="mt-1 flex gap-4 text-xs font-bold text-muted">
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-brand-600" /> Yeni ilan</span>
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-sun" /> Yeni üye</span>
          </div>
          <div className="mt-4 flex h-40 items-end gap-1.5" role="img" aria-label={`Son 14 günde ${data.days.reduce((n, d) => n + d.listings, 0)} yeni ilan ve ${data.days.reduce((n, d) => n + d.users, 0)} yeni üye`}>
            {data.days.map((d) => (
              <div key={d.day} className="flex h-full min-w-0 flex-1 flex-col justify-end gap-1" title={`${d.day}: ${d.listings} ilan, ${d.users} üye`}>
                <div className="flex flex-1 items-end gap-0.5">
                  <div className="flex-1 rounded-t bg-brand-600" style={{ height: `${Math.max(d.listings ? 6 : 1.5, (d.listings / max) * 100)}%`, opacity: d.listings ? 1 : 0.25 }} />
                  <div className="flex-1 rounded-t bg-sun" style={{ height: `${Math.max(d.users ? 6 : 1.5, (d.users / max) * 100)}%`, opacity: d.users ? 1 : 0.35 }} />
                </div>
                <span className="text-center text-[9px] font-bold text-muted">{d.day.slice(8)}</span>
              </div>
            ))}
          </div>
        </section>

        <section className="card p-5">
          <h2 className="text-lg font-bold text-ink">Gelir</h2>
          <p className="mt-3 text-[0.8rem] font-bold text-muted">Doğrulanmış toplam ödeme</p>
          <p className="font-display text-3xl font-extrabold text-ink">{formatPrice(data.payments.revenue)}</p>
          <p className="text-sm font-semibold text-muted">Bu ay: {formatPrice(data.payments.revenue_month)} · {data.payments.paid_count} ödeme</p>
          {data.payments.test_count > 0 && <p className="mt-1 text-xs font-semibold text-sun-ink">{data.payments.test_count} test ödemesi gelire dahil edilmedi.</p>}
          <p className="mt-3 rounded-xl bg-surface p-3 text-[0.8rem] leading-relaxed text-muted">
            Yalnızca PayTR tarafından doğrulanmış gerçek ödemeler sayılır. Reklam gelirleri burada gösterilmez; Google AdSense hesabınızdan izlenir.
          </p>
        </section>
      </div>

      <section className="card p-5">
        <h2 className="text-lg font-bold text-ink">Entegrasyon durumu</h2>
        <ul className="mt-3 grid gap-2 sm:grid-cols-2">
          <li className="flex items-center gap-2.5 rounded-xl bg-surface p-3 text-sm font-semibold text-ink"><StatusDot ok={i.rls.enforced} /> Veritabanına dış erişim: {i.rls.enforced ? 'kapalı (güvenli)' : 'AÇIK'}</li>
          <li className="flex items-center gap-2.5 rounded-xl bg-surface p-3 text-sm font-semibold text-ink"><StatusDot ok={i.paytr} warn /> PayTR ödeme: {i.paytr ? (i.paytr_test_mode ? 'test modunda' : 'canlı') : 'kurulum bekliyor'}</li>
          <li className="flex items-center gap-2.5 rounded-xl bg-surface p-3 text-sm font-semibold text-ink"><StatusDot ok={i.adsense} warn /> Google AdSense: {i.adsense ? 'reklam kodu tanımlı' : 'kurulum bekliyor'}</li>
          <li className="flex items-center gap-2.5 rounded-xl bg-surface p-3 text-sm font-semibold text-ink"><StatusDot ok={i.moderation} warn /> İlan onayı: {i.moderation ? 'her ilan onaydan geçiyor' : 'yalnızca şüpheli ilanlar inceleniyor'}</li>
        </ul>
        <p className="mt-3 text-[0.8rem] text-muted">Mesajlaşma: {formatNumber(data.conversations)} sohbet · Engelli kullanıcı: {data.users.blocked} · Şüpheli işaretli: {data.users.suspicious} · Ödeme bekleyen ilan: {data.listings.pending_payment}</p>
      </section>
    </div>
  );
}

/* ---------------------------------------------------------------- İlanlar */
// İlanı başka bir kategoriye taşıma penceresi (yönetici)
function MoveModal({ listing, onClose, onDone }: { listing: AdminListing | null; onClose: () => void; onDone: () => void }) {
  const { topCats, subsOf, toast } = useApp();
  const [catId, setCatId] = useState<number | null>(null);
  const [subId, setSubId] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => {
    if (!listing) return;
    const start = listing.suggested_category_id || listing.category_id;
    setCatId(start);
    setSubId(start === listing.category_id ? listing.subcategory_id : null);
    setErr(null);
    setBusy(false);
  }, [listing]);
  if (!listing) return null;
  const subs = catId ? subsOf(catId) : [];
  const same = catId === listing.category_id && subId === listing.subcategory_id;
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!catId || !subId) return setErr('Kategori ve alt kategori seçin.');
    setBusy(true);
    setErr(null);
    try {
      await api('admin?action=listing', { method: 'PUT', body: { id: listing.id, op: 'move', category_id: catId, subcategory_id: subId } });
      toast('İlan yeni kategorisine taşındı.');
      onDone();
      onClose();
    } catch (er) {
      setErr(errMsg(er));
      setBusy(false);
    }
  };
  return (
    <Modal open onClose={onClose} title="Kategoriyi değiştir">
      <form onSubmit={submit} noValidate className="flex flex-col gap-4">
        <p className="text-sm leading-relaxed text-ink-soft">“{listing.title}” ilanını doğru kategoriye taşıyın. İlan sahibine bildirim gönderilir. Ana kategori değişirse eski kategoriye özel alanlar (marka, model yılı vb.) silinir.</p>
        <Field label="Kategori" htmlFor="mv-cat">
          <select id="mv-cat" className="input" value={catId ?? ''} onChange={(e) => { setCatId(e.target.value ? Number(e.target.value) : null); setSubId(null); }}>
            {topCats.map((c) => <option key={c.id} value={c.id}>{c.name}{c.id === listing.suggested_category_id ? ' (önerilen)' : ''}</option>)}
          </select>
        </Field>
        <Field label="Alt kategori" htmlFor="mv-sub">
          <select id="mv-sub" className="input" value={subId ?? ''} onChange={(e) => setSubId(e.target.value ? Number(e.target.value) : null)}>
            <option value="">Seçin</option>
            {subs.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </Field>
        {listing.status === 'pending' && <p className="text-[0.82rem] text-muted">Bu ilan onay bekliyor; taşıdıktan sonra yayına girmesi için ayrıca “Onayla” düğmesine basın.</p>}
        {err && <p role="alert" className="text-sm font-semibold text-coral-ink">{err}</p>}
        <div className="flex justify-end gap-2">
          <button type="button" className="btn btn-ghost" onClick={onClose}>Vazgeç</button>
          <button className="btn btn-primary" disabled={busy || !subId || same}>{busy && <Spinner size={16} />} Taşı</button>
        </div>
      </form>
    </Modal>
  );
}

function ListingsTab({ setAsk }: { setAsk: (a: Ask) => void }) {
  const { toast, catById } = useApp();
  const [move, setMove] = useState<AdminListing | null>(null);
  const [status, setStatus] = useState('pending');
  const [q, setQ] = useState('');
  const [term, setTerm] = useState('');
  const [page, setPage] = useState(1);
  const { data, loading, error, reload } = useLoad<{ items: AdminListing[]; total: number; per: number }>(`admin?action=listings&status=${status}&q=${encodeURIComponent(term)}&page=${page}`);

  const op = async (id: number, body: Record<string, unknown>, ok: string) => {
    await api('admin?action=listing', { method: 'PUT', body: { id, ...body } });
    toast(ok);
    await reload();
  };
  const quick = (id: number, body: Record<string, unknown>, ok: string) => op(id, body, ok).catch((e) => toast(errMsg(e), 'error'));

  const filters = [
    ['pending', 'Onay bekleyen'], ['flagged', 'Otomatik işaretli'], ['miscat', 'Kategorisi uyumsuz görünenler'], ['under_review', 'İncelemede'], ['active', 'Yayında'], ['featured', 'Öne çıkan / vitrin'],
    ['pending_payment', 'Ödeme bekleyen'], ['rejected', 'Reddedilen'], ['passive', 'Yayında değil'], ['all', 'Tümü'],
  ];
  return (
    <div>
      <div className="flex flex-col gap-3 sm:flex-row">
        <label className="sr-only" htmlFor="adm-l-status">Durum</label>
        <select id="adm-l-status" className="input input-sm sm:!w-56" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
          {filters.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </select>
        <form className="flex flex-1 gap-2" onSubmit={(e) => { e.preventDefault(); setTerm(q.trim()); setPage(1); }}>
          <label className="sr-only" htmlFor="adm-l-q">İlan ara</label>
          <input id="adm-l-q" className="input input-sm" placeholder="Başlık veya ilan no" value={q} onChange={(e) => setQ(e.target.value)} />
          <button className="btn btn-outline btn-sm"><Search size={15} /> Ara</button>
        </form>
      </div>
      <div className="mt-4">
        {loading && !data ? <PageLoader /> : error || !data ? <ErrorBox message={error || 'İlanlar yüklenemedi.'} onRetry={reload} /> : data.items.length === 0 ? (
          <EmptyState icon={<LayoutList size={26} />} title="Bu listede ilan yok" text={status === 'pending' ? 'Onay bekleyen ilan bulunmuyor.' : undefined} />
        ) : (
          <>
            <p className="mb-2 text-sm font-semibold text-muted">{formatNumber(data.total)} ilan</p>
            <ul className={`flex flex-col gap-3 ${loading ? 'opacity-60' : ''}`}>
              {data.items.map((l) => {
                const st = STATUS[l.status];
                const unpaid = l.status === 'pending_payment' || (l.requires_payment && !l.is_paid);
                return (
                  <li key={l.id} className="card p-3 sm:p-4">
                    <div className="flex gap-3">
                      <Link to={`/ilan/${l.id}`} className="h-20 w-24 shrink-0 overflow-hidden rounded-xl bg-surface sm:h-24 sm:w-32">
                        {l.cover ? <img src={l.cover} alt="" loading="lazy" className="h-full w-full object-cover" /> : <div className="grid h-full place-items-center text-brand-200"><Camera size={22} /></div>}
                      </Link>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className={`chip ${st.cls}`}>{st.label}</span>
                          {l.is_showcase && <span className="chip bg-ink text-sun">Vitrin</span>}
                          {l.is_featured && <span className="chip bg-sun text-ink">Öne çıkan</span>}
                          {l.report_count > 0 && <span className="chip bg-coral-soft text-coral-ink"><Flag size={10} /> {l.report_count} şikâyet</span>}
                          {l.flags.map((f) => <span key={f} className="chip bg-sun-soft text-sun-ink">{FLAG_LABEL[f] || f}</span>)}
                        </div>
                        <Link to={`/ilan/${l.id}`} className="mt-1 block truncate font-bold text-ink hover:text-brand-700">#{l.id} · {l.title}</Link>
                        <p className="text-sm font-bold text-brand-700">{formatPrice(l.price, l.currency)} <span className="font-medium text-muted">· {[l.district_name, l.city_name].filter(Boolean).join(', ')} · {l.photo_count} fotoğraf · {formatDateTime(l.created_at)}</span></p>
                        <p className="mt-1 line-clamp-2 text-[0.84rem] leading-snug text-ink-soft">{l.description}</p>
                        <p className="mt-1 text-[0.8rem] font-semibold text-ink-soft">
                          Kategori: {catById(l.category_id)?.name || '—'} › {catById(l.subcategory_id)?.name || '—'}
                          {l.suggested_category_id && <span className="chip ml-1.5 bg-sun-soft text-sun-ink">Önerilen: {catById(l.suggested_category_id)?.name}</span>}
                        </p>
                        <p className="mt-1 truncate text-[0.8rem] font-semibold text-muted">
                          Satıcı: {l.owner ? <>{l.owner.full_name || 'Adsız'} · {l.owner.email}{l.owner.is_suspicious && <span className="ml-1.5 text-coral-ink">şüpheli</span>}{l.owner.is_blocked && <span className="ml-1.5 text-coral-ink">engelli</span>}</> : 'silinmiş hesap'}
                        </p>
                        {l.reject_reason && <p className="mt-1 text-[0.8rem] font-semibold text-coral-ink">Ret nedeni: {l.reject_reason}</p>}
                      </div>
                    </div>
                    <div className="mt-3 flex flex-wrap gap-1.5 border-t border-line pt-3">
                      {['pending', 'under_review', 'rejected', 'suspended'].includes(l.status) && !unpaid && (
                        <button className="btn btn-mint btn-sm" onClick={() => quick(l.id, { op: 'approve' }, 'İlan onaylandı ve yayına alındı.')}><Check size={15} /> Onayla</button>
                      )}
                      {unpaid && <span className="chip bg-brand-50 px-3 text-brand-700">Ödeme doğrulanmadan onaylanamaz</span>}
                      {l.status !== 'rejected' && (
                        <button className="btn btn-outline btn-sm" onClick={() => setAsk({ title: 'İlanı reddet', label: 'Ret nedeni (satıcıya gösterilir)', kind: 'text', confirm: 'Reddet', danger: true, onOk: (v) => op(l.id, { op: 'reject', reason: v }, 'İlan reddedildi.') })}><X size={15} /> Reddet</button>
                      )}
                      {l.status === 'active' && (
                        <>
                          <button className="btn btn-outline btn-sm" onClick={() => setAsk({ title: 'Öne çıkar', text: 'İlan arama sonuçlarının üstünde ve ana sayfada “Öne çıkan” olarak gösterilir. Kaldırmak için 0 yazın.', label: 'Kaç gün?', kind: 'number', initial: l.is_featured ? '0' : '7', confirm: 'Kaydet', onOk: (v) => op(l.id, { op: 'feature', days: Number(v || 0) }, 'Öne çıkarma güncellendi.') })}><Zap size={15} /> Öne çıkar</button>
                          <button className="btn btn-outline btn-sm" onClick={() => setAsk({ title: 'Vitrine al', text: 'İlan ana sayfadaki Vitrin bölümünde gösterilir. Kaldırmak için 0 yazın.', label: 'Kaç gün?', kind: 'number', initial: l.is_showcase ? '0' : '7', confirm: 'Kaydet', onOk: (v) => op(l.id, { op: 'showcase', days: Number(v || 0) }, 'Vitrin güncellendi.') })}><Star size={15} /> Vitrin</button>
                          <button className="btn btn-outline btn-sm" onClick={() => quick(l.id, { op: 'review' }, 'İlan incelemeye alındı ve yayından kaldırıldı.')}><ShieldAlert size={15} /> İncelemeye al</button>
                        </>
                      )}
                      <button className={`btn btn-sm ${l.suggested_category_id ? 'btn-sun' : 'btn-outline'}`} onClick={() => setMove(l)}><FolderInput size={15} /> Kategoriyi değiştir</button>
                      <button className="btn btn-danger btn-sm" onClick={() => setAsk({ title: 'İlanı sil', text: `“${l.title}” ilanı ve fotoğrafları kalıcı olarak silinecek.`, kind: 'none', confirm: 'Sil', danger: true, onOk: () => op(l.id, { op: 'delete' }, 'İlan silindi.') })}><Trash2 size={15} /> Sil</button>
                    </div>
                  </li>
                );
              })}
            </ul>
            <Pagination page={page} total={data.total} per={data.per} onChange={setPage} />
          </>
        )}
      </div>
      <MoveModal listing={move} onClose={() => setMove(null)} onDone={reload} />
    </div>
  );
}

/* ----------------------------------------------------------- Kullanıcılar */
function UsersTab({ setAsk }: { setAsk: (a: Ask) => void }) {
  const { toast } = useApp();
  const [filter, setFilter] = useState('all');
  const [q, setQ] = useState('');
  const [term, setTerm] = useState('');
  const [page, setPage] = useState(1);
  const { data, loading, error, reload } = useLoad<{ items: AdminUser[]; total: number; per: number }>(`admin?action=users&filter=${filter}&q=${encodeURIComponent(term)}&page=${page}`);
  const op = async (id: string, body: Record<string, unknown>, ok: string) => {
    await api('admin?action=user', { method: 'PUT', body: { id, ...body } });
    toast(ok);
    await reload();
  };
  const quick = (id: string, body: Record<string, unknown>, ok: string) => op(id, body, ok).catch((e) => toast(errMsg(e), 'error'));
  return (
    <div>
      <div className="flex flex-col gap-3 sm:flex-row">
        <label className="sr-only" htmlFor="adm-u-filter">Filtre</label>
        <select id="adm-u-filter" className="input input-sm sm:!w-52" value={filter} onChange={(e) => { setFilter(e.target.value); setPage(1); }}>
          <option value="all">Tüm kullanıcılar</option>
          <option value="suspicious">Şüpheli işaretliler</option>
          <option value="blocked">Engelliler</option>
        </select>
        <form className="flex flex-1 gap-2" onSubmit={(e) => { e.preventDefault(); setTerm(q.trim()); setPage(1); }}>
          <label className="sr-only" htmlFor="adm-u-q">Kullanıcı ara</label>
          <input id="adm-u-q" className="input input-sm" placeholder="Ad veya e-posta" value={q} onChange={(e) => setQ(e.target.value)} />
          <button className="btn btn-outline btn-sm"><Search size={15} /> Ara</button>
        </form>
      </div>
      <div className="mt-4">
        {loading && !data ? <PageLoader /> : error || !data ? <ErrorBox message={error || 'Kullanıcılar yüklenemedi.'} onRetry={reload} /> : data.items.length === 0 ? (
          <EmptyState icon={<Users size={26} />} title="Kullanıcı bulunamadı" />
        ) : (
          <>
            <p className="mb-2 text-sm font-semibold text-muted">{formatNumber(data.total)} kullanıcı</p>
            <ul className={`flex flex-col gap-2.5 ${loading ? 'opacity-60' : ''}`}>
              {data.items.map((u) => (
                <li key={u.id} className="card flex flex-col gap-3 p-4 md:flex-row md:items-center">
                  <div className="flex min-w-0 flex-1 items-center gap-3">
                    <Avatar name={u.full_name || u.email} url={u.avatar_url} size={46} />
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <Link to={`/satici/${u.id}`} className="truncate font-bold text-ink hover:text-brand-700">{u.full_name || 'Adsız üye'}</Link>
                        {u.is_admin && <span className="chip bg-brand-600 text-white">Yönetici</span>}
                        {u.is_blocked && <span className="chip bg-coral-soft text-coral-ink">Engelli</span>}
                        {u.is_suspicious && <span className="chip bg-sun-soft text-sun-ink">Şüpheli</span>}
                      </div>
                      <p className="truncate text-sm text-muted">{u.email || 'e-posta yok'}{u.phone ? ` · ${u.phone}` : ''}</p>
                      <p className="text-[0.78rem] font-medium text-muted">{u.city_name ? `${u.city_name} · ` : ''}{u.listings_created} ilan verdi · Üyelik: {formatDate(u.created_at)}{u.last_seen_at ? ` · Son görülme: ${formatDate(u.last_seen_at)}` : ''}</p>
                      {u.is_blocked && u.block_reason && <p className="text-[0.78rem] font-semibold text-coral-ink">Engel nedeni: {u.block_reason}</p>}
                    </div>
                  </div>
                  {!u.is_admin && (
                    <div className="flex flex-wrap gap-1.5">
                      <button className="btn btn-outline btn-sm" onClick={() => quick(u.id, { op: u.is_suspicious ? 'unflag' : 'flag' }, u.is_suspicious ? 'Şüpheli işareti kaldırıldı.' : 'Kullanıcı şüpheli olarak işaretlendi.')}>
                        <AlertTriangle size={15} /> {u.is_suspicious ? 'İşareti kaldır' : 'Şüpheli işaretle'}
                      </button>
                      {u.is_blocked ? (
                        <button className="btn btn-outline btn-sm" onClick={() => quick(u.id, { op: 'unblock' }, 'Engel kaldırıldı. İlanları yeniden onaya gönderildi.')}><Check size={15} /> Engeli kaldır</button>
                      ) : (
                        <button className="btn btn-danger btn-sm" onClick={() => setAsk({ title: 'Kullanıcıyı engelle', text: `${u.full_name || u.email} giriş yapamayacak, ilanları yayından kaldırılacak.`, label: 'Engel nedeni', kind: 'text', confirm: 'Engelle', danger: true, onOk: (v) => op(u.id, { op: 'block', reason: v }, 'Kullanıcı engellendi.') })}><Ban size={15} /> Engelle</button>
                      )}
                    </div>
                  )}
                </li>
              ))}
            </ul>
            <Pagination page={page} total={data.total} per={data.per} onChange={setPage} />
          </>
        )}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------- Şikâyetler */
function ReportsTab({ setAsk }: { setAsk: (a: Ask) => void }) {
  const { toast } = useApp();
  const [status, setStatus] = useState('open');
  const { data, loading, error, reload } = useLoad<{ items: AdminReport[] }>(`admin?action=reports&status=${status}`);
  const op = async (id: number, body: Record<string, unknown>, ok: string) => {
    await api('admin?action=report', { method: 'PUT', body: { id, ...body } });
    toast(ok);
    await reload();
  };
  const reason = (v: string) => REPORT_REASONS.find((r) => r.value === v)?.label || v;
  const lbl: Record<string, string> = { open: 'Açık', resolved: 'Çözüldü', dismissed: 'Geçersiz sayıldı' };
  return (
    <div>
      <label className="sr-only" htmlFor="adm-r-status">Durum</label>
      <select id="adm-r-status" className="input input-sm sm:!w-56" value={status} onChange={(e) => setStatus(e.target.value)}>
        <option value="open">Açık şikâyetler</option>
        <option value="resolved">Çözülenler</option>
        <option value="dismissed">Geçersiz sayılanlar</option>
        <option value="all">Tümü</option>
      </select>
      <div className="mt-4">
        {loading && !data ? <PageLoader /> : error || !data ? <ErrorBox message={error || 'Şikâyetler yüklenemedi.'} onRetry={reload} /> : data.items.length === 0 ? (
          <EmptyState icon={<Flag size={26} />} title="Şikâyet yok" text={status === 'open' ? 'İncelenmeyi bekleyen şikâyet bulunmuyor.' : undefined} />
        ) : (
          <ul className="flex flex-col gap-3">
            {data.items.map((r) => (
              <li key={r.id} className="card p-4">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className={`chip ${r.status === 'open' ? 'bg-coral-soft text-coral-ink' : 'bg-surface text-ink-soft'}`}>{lbl[r.status] || r.status}</span>
                  <span className="chip bg-sun-soft text-sun-ink">{reason(r.reason)}</span>
                  <span className="text-xs font-semibold text-muted">{formatDateTime(r.created_at)}</span>
                </div>
                <p className="mt-2 font-bold text-ink">
                  {r.listing_id ? <Link to={`/ilan/${r.listing_id}`} className="hover:text-brand-700">#{r.listing_id} · {r.listing_title}</Link> : <>{r.listing_title} <span className="font-medium text-muted">(ilan silinmiş)</span></>}
                  {r.listing_status && <span className={`chip ml-2 ${STATUS[r.listing_status as keyof typeof STATUS]?.cls || ''}`}>{STATUS[r.listing_status as keyof typeof STATUS]?.label}</span>}
                </p>
                {r.details && <p className="mt-1.5 whitespace-pre-line rounded-xl bg-surface p-3 text-sm leading-relaxed text-ink-soft">{r.details}</p>}
                <p className="mt-2 text-[0.8rem] font-medium text-muted">
                  Şikâyet eden: {r.reporter ? `${r.reporter.full_name || 'Adsız'} · ${r.reporter.email}` : 'silinmiş hesap'}<br />
                  Satıcı: {r.seller ? `${r.seller.full_name || 'Adsız'} · ${r.seller.email}` : 'silinmiş hesap'}
                  {r.seller?.is_suspicious && <span className="ml-1.5 font-bold text-coral-ink">şüpheli</span>}
                  {r.seller?.is_blocked && <span className="ml-1.5 font-bold text-coral-ink">engelli</span>}
                </p>
                {r.admin_note && <p className="mt-1 text-[0.8rem] font-semibold text-ink-soft">Not: {r.admin_note}</p>}
                {r.status === 'open' && (
                  <div className="mt-3 flex flex-wrap gap-1.5 border-t border-line pt-3">
                    {r.listing_id && <button className="btn btn-danger btn-sm" onClick={() => setAsk({ title: 'İlanı kaldır', text: 'İlan kalıcı olarak silinir ve bu ilanla ilgili açık şikâyetler çözüldü olarak işaretlenir.', kind: 'none', confirm: 'İlanı kaldır', danger: true, onOk: () => op(r.id, { op: 'remove_listing' }, 'İlan kaldırıldı.') })}><Trash2 size={15} /> İlanı kaldır</button>}
                    <button className="btn btn-outline btn-sm" onClick={() => setAsk({ title: 'Şikâyeti çözüldü olarak işaretle', label: 'Not (isteğe bağlı)', kind: 'text', confirm: 'Çözüldü', onOk: (v) => op(r.id, { op: 'resolve', note: v }, 'Şikâyet çözüldü olarak işaretlendi.') })}><Check size={15} /> Çözüldü</button>
                    <button className="btn btn-outline btn-sm" onClick={() => setAsk({ title: 'Şikâyeti geçersiz say', label: 'Not (isteğe bağlı)', kind: 'text', confirm: 'Geçersiz say', onOk: (v) => op(r.id, { op: 'dismiss', note: v }, 'Şikâyet geçersiz sayıldı.') })}><X size={15} /> Geçersiz</button>
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

/* --------------------------------------------------------------- Ödemeler */
function PaymentsTab() {
  const { data, loading, error, reload } = useLoad<{ items: PaymentRow[] }>('admin?action=payments');
  if (loading && !data) return <PageLoader />;
  if (error || !data) return <ErrorBox message={error || 'Ödemeler yüklenemedi.'} onRetry={reload} />;
  if (!data.items.length) return <EmptyState icon={<CreditCard size={26} />} title="Henüz ödeme kaydı yok" text="PayTR entegrasyonu etkinleştirildikten sonra kullanıcıların ödeme girişimleri ve doğrulanan ödemeler burada listelenir." />;
  const cls: Record<string, string> = { paid: 'bg-mint-soft text-mint-ink', pending: 'bg-sun-soft text-sun-ink', failed: 'bg-coral-soft text-coral-ink' };
  const lbl: Record<string, string> = { paid: 'Ödendi', pending: 'Bekliyor', failed: 'Başarısız' };
  return (
    <div className="card overflow-x-auto">
      <table className="w-full min-w-[720px] text-left text-sm">
        <thead className="border-b border-line bg-surface text-xs font-extrabold uppercase tracking-wider text-muted">
          <tr><th className="px-4 py-3">Tarih</th><th className="px-4 py-3">Kullanıcı</th><th className="px-4 py-3">Hizmet</th><th className="px-4 py-3">İlan</th><th className="px-4 py-3">Durum</th><th className="px-4 py-3 text-right">Tutar</th></tr>
        </thead>
        <tbody>
          {data.items.map((p) => (
            <tr key={p.id} className="border-b border-line last:border-0">
              <td className="whitespace-nowrap px-4 py-3 text-muted">{formatDateTime(p.created_at)}</td>
              <td className="max-w-[200px] truncate px-4 py-3 font-semibold text-ink">{p.user_email || 'silinmiş hesap'}</td>
              <td className="px-4 py-3">{PAYMENT_TYPE[p.type] || p.type}{p.days ? ` · ${p.days} gün` : ''}</td>
              <td className="max-w-[200px] truncate px-4 py-3">{p.listing_id ? <Link to={`/ilan/${p.listing_id}`} className="font-semibold text-brand-700 hover:underline">#{p.listing_id} {p.listing_title}</Link> : p.listing_title || '—'}</td>
              <td className="px-4 py-3"><span className={`chip ${cls[p.status]}`}>{lbl[p.status]}</span>{p.test_mode && <span className="chip ml-1 bg-surface text-muted">Test</span>}{p.failed_reason && <p className="mt-0.5 max-w-[180px] truncate text-xs text-coral-ink" title={p.failed_reason}>{p.failed_reason}</p>}</td>
              <td className="whitespace-nowrap px-4 py-3 text-right font-display font-extrabold text-ink">{formatPrice(p.amount)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ---------------------------------------------------------------- Ayarlar */
function SettingsTab() {
  const { toast, reload: reloadApp } = useApp();
  const { data, loading, error, reload } = useLoad<AllSettings>('admin?action=settings');
  const [f, setF] = useState<Record<string, string | boolean>>({});
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => {
    if (!data) return;
    const s = data.settings as unknown as Record<string, unknown>;
    const next: Record<string, string | boolean> = {};
    for (const k of ['free_listing_count', 'listing_fee', 'featured_fee', 'featured_days', 'showcase_fee', 'showcase_days', 'max_photos', 'company_name', 'company_address', 'contact_email', 'contact_phone']) next[k] = String(s[k] ?? '');
    for (const k of ['paid_listings_enabled', 'featured_sales_enabled', 'showcase_sales_enabled', 'moderation_enabled']) next[k] = !!s[k];
    setF(next);
  }, [data]);
  if (loading && !data) return <PageLoader />;
  if (error || !data) return <ErrorBox message={error || 'Ayarlar yüklenemedi.'} onRetry={reload} />;
  const paytr = data.paytr.configured;
  const num = (k: string, label: string, hint?: string) => (
    <Field label={label} htmlFor={`s-${k}`} hint={hint}>
      <input id={`s-${k}`} inputMode="decimal" className="input" value={String(f[k] ?? '')} onChange={(e) => setF((x) => ({ ...x, [k]: e.target.value.replace(',', '.').replace(/[^\d.]/g, '') }))} />
    </Field>
  );
  const txt = (k: string, label: string, hint?: string) => (
    <Field label={label} htmlFor={`s-${k}`} hint={hint}>
      <input id={`s-${k}`} className="input" value={String(f[k] ?? '')} onChange={(e) => setF((x) => ({ ...x, [k]: e.target.value }))} />
    </Field>
  );
  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    try {
      const body: Record<string, unknown> = { ...f };
      for (const k of ['free_listing_count', 'listing_fee', 'featured_fee', 'featured_days', 'showcase_fee', 'showcase_days', 'max_photos']) body[k] = Number(f[k] || 0);
      await api('admin?action=settings', { method: 'PUT', body });
      toast('Ayarlar kaydedildi.');
      await reload();
      reloadApp(true);
    } catch (er) {
      setErr(errMsg(er));
    } finally {
      setBusy(false);
    }
  };
  const lock = !paytr ? 'PayTR mağaza bilgileri tanımlanmadan açılamaz.' : undefined;
  return (
    <form onSubmit={save} noValidate className="flex flex-col gap-5">
      <section className="card flex flex-col gap-4 p-5 sm:p-6">
        <h2 className="text-lg font-bold text-ink">İlan kuralları</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          {num('free_listing_count', 'Kullanıcı başına ücretsiz ilan sayısı', 'Her üyenin ücretsiz verebileceği ilk ilan sayısı.')}
          {num('max_photos', 'İlan başına en fazla fotoğraf', '10 ile 20 arasında.')}
        </div>
        <Toggle checked={!!f.moderation_enabled} onChange={(v) => setF((x) => ({ ...x, moderation_enabled: v }))} label="Her ilan yayınlanmadan önce onayımdan geçsin" description="Kapatırsanız ilanlar doğrudan yayına girer; yalnızca otomatik denetimin şüpheli bulduğu ilanlar onayınıza düşer." />
      </section>

      <section className="card flex flex-col gap-4 p-5 sm:p-6">
        <h2 className="text-lg font-bold text-ink">Ücretli hizmetler</h2>
        {!paytr && (
          <p className="flex items-start gap-2.5 rounded-xl bg-sun-soft p-3 text-sm font-semibold leading-relaxed text-sun-ink">
            <AlertTriangle size={17} className="mt-0.5 shrink-0" /> PayTR henüz kurulmadı. Ücretleri şimdiden belirleyebilirsiniz; ancak ücretli seçenekler PayTR bilgileri “Kurulum ve güvenlik” sekmesinden girildikten sonra açılabilir. O zamana kadar tüm ilanlar ücretsizdir.
          </p>
        )}
        <div className="grid gap-4 border-b border-line pb-4 sm:grid-cols-[1fr_200px] sm:items-start">
          <Toggle checked={!!f.paid_listings_enabled} disabled={!paytr} onChange={(v) => setF((x) => ({ ...x, paid_listings_enabled: v }))} label="Ücretsiz haktan sonraki ilanlar ücretli olsun" description={lock || 'Kapalıyken ücretsiz hak dolsa bile ilan vermek ücretsizdir.'} />
          {num('listing_fee', 'İlan ücreti (TL)')}
        </div>
        <div className="grid gap-4 border-b border-line pb-4 sm:grid-cols-[1fr_200px_120px] sm:items-start">
          <Toggle checked={!!f.featured_sales_enabled} disabled={!paytr} onChange={(v) => setF((x) => ({ ...x, featured_sales_enabled: v }))} label="Öne çıkarma satışı açık" description={lock || 'Kullanıcılar ilanlarını ücret karşılığı öne çıkarabilir.'} />
          {num('featured_fee', 'Öne çıkarma ücreti (TL)')}
          {num('featured_days', 'Süre (gün)')}
        </div>
        <div className="grid gap-4 sm:grid-cols-[1fr_200px_120px] sm:items-start">
          <Toggle checked={!!f.showcase_sales_enabled} disabled={!paytr} onChange={(v) => setF((x) => ({ ...x, showcase_sales_enabled: v }))} label="Vitrin ilanı satışı açık" description={lock || 'Vitrin ilanları ana sayfanın en üstünde gösterilir.'} />
          {num('showcase_fee', 'Vitrin ücreti (TL)')}
          {num('showcase_days', 'Süre (gün)')}
        </div>
        <p className="text-[0.8rem] text-muted">İlanları ücret almadan öne çıkarmak veya vitrine almak için “İlanlar” sekmesindeki düğmeleri kullanabilirsiniz.</p>
      </section>

      <section className="card flex flex-col gap-4 p-5 sm:p-6">
        <h2 className="text-lg font-bold text-ink">İşletme ve iletişim bilgileri</h2>
        <p className="-mt-2 text-sm text-muted">KVKK aydınlatma metninde, gizlilik politikasında ve alt bilgide “veri sorumlusu” olarak gösterilir.</p>
        <div className="grid gap-4 sm:grid-cols-2">
          {txt('company_name', 'Unvan (şirket veya şahıs adı)')}
          {txt('contact_email', 'İletişim e-postası', String(f.contact_email || '').trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(f.contact_email).trim()) ? 'Bu bir e-posta adresi değil; sitede gösterilmez. Örnek: destek@alanadiniz.com' : undefined)}
          {txt('contact_phone', 'İletişim telefonu')}
          {txt('company_address', 'Adres')}
        </div>
      </section>

      {err && <p role="alert" className="rounded-xl bg-coral-soft px-4 py-3 text-sm font-bold text-coral-ink">{err}</p>}
      <div className="flex justify-end"><button className="btn btn-primary btn-lg" disabled={busy}>{busy && <Spinner size={18} />} Ayarları kaydet</button></div>
    </form>
  );
}

/* ----------------------------------------------------------------- Reklam */
const PLACEMENT_LABEL: Record<string, string> = {
  home_desktop: 'Ana sayfa küçük banner — bilgisayar (728×90)', home_mobile: 'Ana sayfa küçük banner — mobil (320×50)',
  category_desktop: 'Kategori ve arama sayfaları — bilgisayar', category_mobile: 'Kategori ve arama sayfaları — mobil',
  detail_desktop: 'İlan detayı — bilgisayar', detail_mobile: 'İlan detayı — mobil',
};

const HOUSE_SPOTS: { k: string; l: string; where: string; size: string; mobile: string; compact: boolean; path: string | null }[] = [
  { k: 'home', l: 'Ana sayfa — küçük reklam alanı', where: 'Ana sayfanın en üstünde, kategorilerin üzerinde küçük bir şerit olarak gösterilir.', size: 'Yatay görsel en iyi sonucu verir (ör. 1200×150).', mobile: 'Telefonlarda bu görsel gösterilir (ör. 640×160).', compact: true, path: '/' },
  { k: 'category', l: 'Kategori ve arama sayfaları', where: 'İlan listesinde ilk 8 ilandan sonra (ilan azsa listenin altında) gösterilir.', size: 'Yatay görsel en iyi sonucu verir (ör. 1200×300).', mobile: 'Telefonlarda bu görsel gösterilir (ör. 800×400).', compact: false, path: '/ilanlar' },
  { k: 'detail', l: 'İlan detayı', where: 'Her ilanın açıklamasının altında gösterilir.', size: 'Yatay görsel en iyi sonucu verir (ör. 1200×300).', mobile: 'Telefonlarda bu görsel gösterilir (ör. 800×400).', compact: false, path: null },
];
const EMPTY_HOUSE: HouseAd = { image_url: '', mobile_image_url: '', link_url: '', title: '', is_active: false };
const normHouse = (src?: Record<string, HouseAd>) => Object.fromEntries(HOUSE_SPOTS.map((sp) => [sp.k, { ...EMPTY_HOUSE, ...(src?.[sp.k] || {}) }])) as Record<string, HouseAd>;

// Kendi görsel reklamlarınız. Her değişiklik (görsel yükleme, kaldırma, yayına alma, adres) KENDİLİĞİNDEN kaydedilir;
// ayrıca bir "kaydet" düğmesine basmayı unutmak ya da yanlış düğmeye basmak reklamı kaybettirmez.
function HouseAdsSection({ initial, onSaved }: { initial?: Record<string, HouseAd>; onSaved: () => void }) {
  const { toast } = useApp();
  const [ads, setAds] = useState<Record<string, HouseAd>>(() => normHouse(initial));
  const adsRef = useRef(ads);
  adsRef.current = ads;
  const saved = useRef(JSON.stringify(normHouse(initial)));
  const [saving, setSaving] = useState(false);
  const [up, setUp] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const persist = async (next: Record<string, HouseAd>, ok: string) => {
    setAds(next);
    setSaving(true);
    setErr(null);
    try {
      const r = await api<{ house_ads: Record<string, HouseAd> }>('admin?action=house-ads', { method: 'PUT', body: { ads: next } });
      const n = normHouse(r.house_ads);
      saved.current = JSON.stringify(n);
      // Sunucunun düzelttiği adres (ör. "site.com" → "https://site.com") alana yansıtılır; bu sırada yazılmış başka bir alan ezilmez.
      setAds((cur) => Object.fromEntries(HOUSE_SPOTS.map((sp) => [sp.k, { ...cur[sp.k], link_url: cur[sp.k].link_url === next[sp.k].link_url ? n[sp.k].link_url : cur[sp.k].link_url }])) as Record<string, HouseAd>);
      toast(ok);
      onSaved();
      return true;
    } catch (er) {
      setErr(errMsg(er));
      return false;
    } finally {
      setSaving(false);
    }
  };
  const change = (k: string, p: Partial<HouseAd>, ok: string) => persist({ ...adsRef.current, [k]: { ...EMPTY_HOUSE, ...adsRef.current[k], ...p } }, ok);
  const typed = (k: string, p: Partial<HouseAd>) => setAds((a) => ({ ...a, [k]: { ...EMPTY_HOUSE, ...a[k], ...p } }));
  const saveIfChanged = () => { if (JSON.stringify(adsRef.current) !== saved.current) persist(adsRef.current, 'Kaydedildi.'); };

  const upload = async (k: string, field: 'image_url' | 'mobile_image_url', file: File) => {
    setUp(`${k}:${field}`);
    setErr(null);
    try {
      const p = await prepareImage(file, { maxSide: 1920, minSide: 50 });
      const r = await api<{ url: string }>('upload', { method: 'POST', body: { kind: 'banner', main: p.main } });
      // Görsel yüklenir yüklenmez kaydedilir; ana görsel yüklendiğinde reklam yayına da alınır.
      if (field === 'image_url') await change(k, { image_url: r.url, is_active: true }, 'Reklam görseli yüklendi ve yayına alındı.');
      else await change(k, { mobile_image_url: r.url }, 'Mobil görsel kaydedildi.');
    } catch (er) {
      setErr(errMsg(er));
    } finally {
      setUp(null);
    }
  };

  const picker = (k: string, field: 'image_url' | 'mobile_image_url', label: string, hint: string) => {
    const url = ads[k]?.[field] || '';
    const id = `house-${k}-${field}`;
    return (
      <div>
        <p className="label">{label}</p>
        <div className="relative grid min-h-24 place-items-center overflow-hidden rounded-xl border border-dashed border-brand-200 bg-surface">
          {url ? <img src={url} alt="" className="max-h-40 w-full object-contain" /> : <span className="px-3 py-6 text-center text-xs font-semibold text-muted">Görsel yok</span>}
          {up === `${k}:${field}` && <div className="absolute inset-0 grid place-items-center bg-white/70"><Spinner className="text-brand-600" size={24} /></div>}
        </div>
        <div className="mt-2 flex flex-wrap gap-2">
          <label htmlFor={id} className={`btn btn-outline btn-sm cursor-pointer ${up || saving ? 'pointer-events-none opacity-55' : ''}`}><Camera size={15} /> {url ? 'Görseli değiştir' : 'Görsel yükle'}</label>
          <input id={id} type="file" accept="image/*" className="sr-only" disabled={!!up || saving} onChange={(e) => { const fl = e.target.files?.[0]; if (fl) upload(k, field, fl); e.target.value = ''; }} />
          {url && <button type="button" className="btn btn-ghost btn-sm" disabled={!!up || saving} onClick={() => (field === 'image_url' ? change(k, { image_url: '', mobile_image_url: '', is_active: false }, 'Reklam kaldırıldı.') : change(k, { mobile_image_url: '' }, 'Mobil görsel kaldırıldı.'))}>Kaldır</button>}
        </div>
        <p className="mt-1 text-[0.78rem] text-muted">{hint}</p>
      </div>
    );
  };

  return (
    <section className="card flex flex-col gap-5 p-5 sm:p-6">
      <div>
        <h2 className="text-lg font-bold text-ink">Kendi reklam alanlarınız</h2>
        <p className="mt-1 text-sm leading-relaxed text-muted">
          Reklam görselini yüklemeniz yeterli: görsel <strong className="text-ink">yüklenir yüklenmez kaydedilir ve yayına alınır</strong>. Google hesabı gerekmez. Görsel hangi biçimde olursa olsun kırpılmadan, ortalanarak gösterilir. Tıklama ve gösterim sayısı tutulmaz.
        </p>
        <p className="mt-2 flex items-center gap-2 text-[0.8rem] font-semibold text-ink-soft" aria-live="polite">
          {saving || up ? <><Spinner size={14} className="text-brand-600" /> Kaydediliyor…</> : <><CheckCircle2 size={15} className="text-mint-ink" /> Değişiklikler kendiliğinden kaydedilir.</>}
        </p>
      </div>
      {err && <p role="alert" className="rounded-xl bg-coral-soft px-4 py-3 text-sm font-bold text-coral-ink">{err}</p>}
      {HOUSE_SPOTS.map((sp) => {
        const a = ads[sp.k] || EMPTY_HOUSE;
        return (
          <fieldset key={sp.k} className="min-w-0 rounded-2xl border border-line p-4">
            <legend className="px-1.5 text-sm font-extrabold text-ink">{sp.l}</legend>
            <div className="mb-3 flex flex-wrap items-center gap-2">
              <span className={`chip ${a.image_url && a.is_active ? 'bg-mint-soft text-mint-ink' : 'bg-surface text-muted'}`}>{a.image_url && a.is_active ? 'Yayında' : a.image_url ? 'Yayında değil' : 'Boş'}</span>
              <p className="min-w-0 flex-1 text-[0.82rem] text-muted">{sp.where}</p>
            </div>
            {a.image_url && (
              <div className="mb-4">
                <p className="mb-1 text-xs font-extrabold uppercase tracking-wider text-muted">Önizleme — sitede böyle görünür</p>
                <HouseAdView ad={a} compact={sp.compact} />
                {sp.path && a.is_active && <Link to={sp.path} className="mt-1.5 inline-block text-[0.82rem] font-bold text-brand-700 hover:underline">Sitede gör →</Link>}
              </div>
            )}
            <div className="grid gap-4 md:grid-cols-2">
              {picker(sp.k, 'image_url', 'Reklam görseli', `${sp.size} Hareketli GIF desteklenmez.`)}
              {picker(sp.k, 'mobile_image_url', 'Mobil görseli (isteğe bağlı)', `${sp.mobile} Boşsa üstteki görsel küçültülerek gösterilir.`)}
              <Field label="Tıklanınca gidilecek adres (isteğe bağlı)" htmlFor={`house-${sp.k}-link`} hint="Ör. ornek.com ya da https://ornek.com; site içi sayfa için /ilanlar">
                <input id={`house-${sp.k}-link`} className="input" maxLength={300} value={a.link_url} onChange={(e) => typed(sp.k, { link_url: e.target.value })} onBlur={saveIfChanged} placeholder="https://" inputMode="url" autoCapitalize="none" spellCheck={false} />
              </Field>
              <Field label="Reklam veren / açıklama (isteğe bağlı)" htmlFor={`house-${sp.k}-title`} hint="Görselin açıklama metni olarak kullanılır.">
                <input id={`house-${sp.k}-title`} className="input" maxLength={80} value={a.title} onChange={(e) => typed(sp.k, { title: e.target.value })} onBlur={saveIfChanged} />
              </Field>
            </div>
            <div className="mt-4"><Toggle checked={a.is_active} disabled={!a.image_url || saving} onChange={(v) => change(sp.k, { is_active: v }, v ? 'Reklam yayına alındı.' : 'Reklam yayından kaldırıldı.')} label="Bu alanda reklamı yayınla" description={a.image_url ? undefined : 'Önce bir reklam görseli yükleyin.'} /></div>
          </fieldset>
        );
      })}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-[0.8rem] text-muted">Ziyaretçilerde görünmesi yarım dakikayı bulabilir.</p>
        <button type="button" className="btn btn-outline" disabled={saving || !!up} onClick={() => persist(adsRef.current, 'Reklam alanları kaydedildi.')}>{saving && <Spinner size={16} />} Reklam alanlarını kaydet</button>
      </div>
    </section>
  );
}

interface AdsValue { enabled: boolean; client: string; slots: Record<string, string> }

function AdsTab() {
  const { toast, reload: reloadApp } = useApp();
  const consent = useConsent();
  const { data, loading, error, reload } = useLoad<AllSettings>('admin?action=settings');
  const [enabled, setEnabled] = useState(false);
  const [client, setClient] = useState('');
  const [codes, setCodes] = useState<Record<string, string>>({});
  const [savedAds, setSavedAds] = useState<AdsValue>({ enabled: false, client: '', slots: {} });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const apply = (v?: AdsValue) => {
    const a: AdsValue = { enabled: !!v?.enabled, client: v?.client || '', slots: { ...(v?.slots || {}) } };
    setSavedAds(a);
    setEnabled(a.enabled);
    setClient(a.client);
    setCodes({ ...a.slots });
  };
  useEffect(() => { if (data) apply(data.settings.ads); }, [data]);
  if (loading && !data) return <PageLoader />;
  if (error || !data) return <ErrorBox message={error || 'Reklam ayarları yüklenemedi.'} onRetry={reload} />;

  // Kod ya da kimlik ilk kez giriliyorsa "göster" düğmesi kendiliğinden açılır; yapıştırıp kaydetmek yeterli olur.
  const autoOn = (v: string) => { if (v.trim() && !savedAds.client && !enabled) setEnabled(true); };
  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    try {
      const r = await api<{ ads: AdsValue; mode: 'none' | 'units' | 'auto' }>('admin?action=ads', { method: 'PUT', body: { enabled, client, slots: codes } });
      apply(r.ads);
      if (r.mode === 'none') toast('Google reklam ayarları temizlendi.');
      else if (!r.ads.enabled) toast('Kaydedildi, ancak Google reklamları KAPALI. Göstermek için “Google reklamlarını göster” düğmesini açıp yeniden kaydedin.', 'info');
      else if (r.mode === 'auto') toast('Google reklamları açık (yalnızca otomatik reklamlar). Belirli alanlarda göstermek için reklam birimi kodu ekleyin.', 'info');
      else toast('Google reklamları açık; reklam kodu kaydedildi.');
      reloadApp(true);
    } catch (er) {
      setErr(errMsg(er));
    } finally {
      setBusy(false);
    }
  };
  const unitCount = Object.keys(savedAds.slots).length;
  const hint = (k: string) => (savedAds.slots[k] && codes[k] === savedAds.slots[k] ? `Kayıtlı reklam birimi numarası: ${savedAds.slots[k]}` : undefined);
  return (
    <div className="flex flex-col gap-5">
      <HouseAdsSection initial={data.settings.house_ads} onSaved={() => reloadApp(true)} />
      <form onSubmit={save} noValidate className="flex flex-col gap-5">
        <section className="card p-5 sm:p-6">
          <h2 className="text-lg font-bold text-ink">Google reklamları (AdSense)</h2>
          <p className="mt-2 flex items-start gap-2 rounded-xl bg-surface p-3 text-sm font-semibold text-ink">
            <StatusDot ok={savedAds.enabled && !!savedAds.client} warn />
            <span>
              {!savedAds.client ? 'Henüz Google reklam kodu girilmedi.'
                : !savedAds.enabled ? `Kod kayıtlı (${savedAds.client}) ama Google reklamları KAPALI.`
                  : unitCount ? `Google reklamları AÇIK · ${savedAds.client} · reklam birimi kayıtlı.`
                    : `Google reklamları AÇIK · ${savedAds.client} · yalnızca otomatik reklamlar (reklam birimi kodu yok).`}
            </span>
          </p>
          {consent !== 'all' && (
            <p className="mt-2 rounded-xl border border-sun/70 bg-sun-soft/70 p-3 text-[0.82rem] leading-relaxed text-ink">
              <strong>Bu cihazda Google reklamlarını göremezsiniz:</strong> çerez bildiriminde reklam çerezlerine izin vermediniz. Reklamlar yalnızca izin veren ziyaretçilere gösterilir.{' '}
              <button type="button" className="font-bold text-brand-700 underline" onClick={() => { setConsent('all'); toast('Bu cihazda reklam çerezlerine izin verildi.'); }}>Bu cihazda izin ver</button>
            </p>
          )}
          <div className="mt-4 grid gap-4">
            <Field label="Google reklam kodu" htmlFor="ad-all" hint={hint('all') || 'AdSense panelinde Reklamlar → “Reklam birimine göre” → “Görüntülü reklam” → “Kodu al”. Kodun tamamını buraya yapıştırın; yayıncı kimliği ve reklam birimi numarası koddan okunur. Bu kod, aşağıda ayrı kod girilmemiş bütün reklam alanlarında kullanılır.'}>
              <textarea id="ad-all" className="input !min-h-28 font-mono !text-[0.8rem]" value={codes.all || ''} onChange={(e) => { setCodes((c) => ({ ...c, all: e.target.value })); autoOn(e.target.value); }} spellCheck={false} autoCapitalize="none" placeholder={'<script async src="https://pagead2.googlesyndication.com/…"></script>\n<ins class="adsbygoogle" … data-ad-slot="…"></ins>'} />
            </Field>
            <Field label="Yayıncı kimliği (reklam kodu yapıştırdıysanız boş bırakabilirsiniz)" htmlFor="ad-client" hint="ca-pub-1234567890123456 ya da pub-1234567890123456 biçiminde.">
              <input id="ad-client" className="input font-mono" value={client} onChange={(e) => { setClient(e.target.value); autoOn(e.target.value); }} placeholder="ca-pub-…" spellCheck={false} autoCapitalize="none" />
            </Field>
            <Toggle checked={enabled} onChange={setEnabled} label="Google reklamlarını göster" description="Kapalıyken kod saklanır ama hiçbir Google reklamı gösterilmez." />
          </div>
          <details className="mt-4">
            <summary className="text-sm font-bold text-brand-700">Her alan için ayrı reklam birimi (isteğe bağlı)</summary>
            <p className="mt-2 text-[0.82rem] text-muted">Bir alanı boş bırakırsanız üstteki “Google reklam kodu” kullanılır. Ana sayfadaki Google banner küçük ve sabit boyutludur (telefonda 320×50, geniş ekranda 728×90).</p>
            <div className="mt-3 grid gap-4 md:grid-cols-2">
              {data.ad_placements.map((p) => (
                <Field key={p} label={PLACEMENT_LABEL[p] || p} htmlFor={`ad-${p}`} hint={hint(p) || 'Reklam kodunu ya da reklam birimi numarasını yapıştırın.'}>
                  <textarea id={`ad-${p}`} className="input !min-h-20 font-mono !text-[0.8rem]" value={codes[p] || ''} onChange={(e) => setCodes((c) => ({ ...c, [p]: e.target.value }))} spellCheck={false} autoCapitalize="none" />
                </Field>
              ))}
            </div>
          </details>
          {err && <p role="alert" className="mt-4 rounded-xl bg-coral-soft px-4 py-3 text-sm font-bold leading-relaxed text-coral-ink">{err}</p>}
          <div className="mt-4 flex justify-end"><button className="btn btn-primary btn-lg" disabled={busy}>{busy && <Spinner size={18} />} Google reklam ayarlarını kaydet</button></div>
          <ul className="mt-4 list-disc space-y-1 rounded-xl bg-surface p-3 pl-7 text-[0.8rem] leading-relaxed text-muted">
            <li>Google reklamları ancak AdSense hesabınız ve siteniz Google tarafından onaylandıktan sonra görünür. Onaydan önce alan boş kalır; ziyaretçilere boş kutu gösterilmez.</li>
            <li>Yayıncı kimliğinizi kaydettiğinizde sitenizin <strong>/ads.txt</strong> adresi kendiliğinden oluşur; Google siteyi bununla doğrulayabilir.</li>
            <li><strong>AdMob</strong> kimlikleri (ca-app-pub-…) burada çalışmaz: AdMob yalnızca yerel uygulamalar içindir; bu uygulama siteyi gösterdiği için AdSense gerekir.</li>
            <li>Reklamlar yalnızca çerez bildiriminde izin veren ziyaretçilere yüklenir. Gelir bilgisi yalnızca AdSense hesabınızda görünür.</li>
          </ul>
        </section>
      </form>
    </div>
  );
}

/* -------------------------------------------------------------- Bannerlar */
const EMPTY_BANNER = { id: 0, title: '', subtitle: '', image_url: '', link_url: '', cta_label: '', is_active: true, sort_order: 0 };

function BannersTab({ setAsk }: { setAsk: (a: Ask) => void }) {
  const { toast, reload: reloadApp } = useApp();
  const { data, loading, error, reload } = useLoad<{ items: Banner[]; tampered?: boolean }>('admin?action=banners');
  const [edit, setEdit] = useState<typeof EMPTY_BANNER | null>(null);
  const [busy, setBusy] = useState(false);
  const [upBusy, setUpBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!edit) return;
    if (edit.title.trim().length < 2) return setErr('Banner başlığı girin.');
    setBusy(true);
    setErr(null);
    try {
      await api('admin?action=banner', { method: edit.id ? 'PUT' : 'POST', body: edit });
      toast('Banner kaydedildi.');
      setEdit(null);
      await reload();
      reloadApp(true);
    } catch (er) {
      setErr(errMsg(er));
    } finally {
      setBusy(false);
    }
  };
  const upload = async (file: File) => {
    setUpBusy(true);
    setErr(null);
    try {
      const p = await prepareImage(file, { maxSide: 1920 });
      const r = await api<{ url: string }>('upload', { method: 'POST', body: { kind: 'banner', main: p.main } });
      setEdit((b) => (b ? { ...b, image_url: r.url } : b));
    } catch (er) {
      setErr(errMsg(er));
    } finally {
      setUpBusy(false);
    }
  };
  const remove = async (id: number) => {
    await api('admin?action=banner', { method: 'DELETE', body: { id } });
    toast('Banner silindi.');
    await reload();
    reloadApp(true);
  };

  if (loading && !data) return <PageLoader />;
  if (error || !data) return <ErrorBox message={error || 'Bannerlar yüklenemedi.'} onRetry={reload} />;
  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="max-w-xl text-sm text-muted">Etkin bannerlar ana sayfanın en üstünde sırayla gösterilir. Hiç etkin banner yoksa varsayılan karşılama alanı görünür.</p>
        <button className="btn btn-primary btn-sm" onClick={() => { setEdit({ ...EMPTY_BANNER }); setErr(null); }}><Plus size={16} /> Yeni banner</button>
      </div>
      {data.tampered && (
        <p role="alert" className="mt-4 flex items-start gap-2.5 rounded-2xl border border-[#ffc9bd] bg-coral-soft p-4 text-sm font-semibold leading-relaxed text-coral-ink">
          <ShieldAlert size={18} className="mt-0.5 shrink-0" />
          Banner kayıtları yönetim paneli dışından değiştirilmiş görünüyor; güvenlik nedeniyle sitede hiçbir banner gösterilmiyor. Tanımadığınız bannerları silin, ardından kalanlardan birini “Düzenle → Kaydet” ile yeniden kaydedin.
        </p>
      )}
      <div className="mt-4">
        {data.items.length === 0 ? <EmptyState icon={<ImageIcon size={26} />} title="Henüz banner eklenmedi" text="Kampanya, duyuru veya reklam alanı olarak kullanmak için banner ekleyin." /> : (
          <ul className="grid gap-3 md:grid-cols-2">
            {data.items.map((b) => (
              <li key={b.id} className="card overflow-hidden">
                <div className="relative h-32 bg-gradient-to-br from-brand-600 to-brand-900">
                  {b.image_url && <img src={b.image_url} alt="" className="h-full w-full object-cover" />}
                  <span className={`chip absolute left-2 top-2 ${b.is_active ? 'bg-mint-soft text-mint-ink' : 'bg-white text-muted'}`}>{b.is_active ? 'Etkin' : 'Kapalı'}</span>
                </div>
                <div className="p-4">
                  <p className="truncate font-bold text-ink">{b.title}</p>
                  {b.subtitle && <p className="truncate text-sm text-muted">{b.subtitle}</p>}
                  <p className="mt-1 truncate text-xs font-semibold text-brand-700">{b.link_url || 'Bağlantı yok'} · Sıra: {b.sort_order}</p>
                  <div className="mt-3 flex gap-1.5">
                    <button className="btn btn-outline btn-sm" onClick={() => { setEdit({ id: b.id, title: b.title, subtitle: b.subtitle || '', image_url: b.image_url || '', link_url: b.link_url || '', cta_label: b.cta_label || '', is_active: b.is_active !== false, sort_order: b.sort_order }); setErr(null); }}><Pencil size={14} /> Düzenle</button>
                    <button className="btn btn-danger btn-sm" onClick={() => setAsk({ title: 'Bannerı sil', text: `“${b.title}” kalıcı olarak silinecek.`, kind: 'none', confirm: 'Sil', danger: true, onOk: () => remove(b.id) })}><Trash2 size={14} /> Sil</button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? 'Bannerı düzenle' : 'Yeni banner'} wide>
        {edit && (
          <form onSubmit={save} noValidate className="flex flex-col gap-4">
            <div>
              <p className="label">Görsel (isteğe bağlı)</p>
              <div className="relative h-36 overflow-hidden rounded-2xl bg-gradient-to-br from-brand-600 to-brand-900">
                {edit.image_url && <img src={edit.image_url} alt="" className="h-full w-full object-cover" />}
                {upBusy && <div className="absolute inset-0 grid place-items-center bg-white/70"><Spinner className="text-brand-600" size={26} /></div>}
              </div>
              <div className="mt-2 flex gap-2">
                <button type="button" className="btn btn-outline btn-sm" disabled={upBusy} onClick={() => fileRef.current?.click()}><Camera size={15} /> Görsel yükle</button>
                {edit.image_url && <button type="button" className="btn btn-ghost btn-sm" onClick={() => setEdit({ ...edit, image_url: '' })}>Görseli kaldır</button>}
                <input ref={fileRef} type="file" accept="image/*" className="sr-only" aria-label="Banner görseli seç" onChange={(e) => { const fl = e.target.files?.[0]; if (fl) upload(fl); e.target.value = ''; }} />
              </div>
              <p className="mt-1 text-[0.8rem] text-muted">Yatay (yaklaşık 3:1) bir görsel önerilir. Başlık görselin sol tarafında gösterilir.</p>
            </div>
            <Field label="Başlık" htmlFor="b-title" required><input id="b-title" className="input" maxLength={80} value={edit.title} onChange={(e) => setEdit({ ...edit, title: e.target.value })} /></Field>
            <Field label="Alt başlık" htmlFor="b-sub"><input id="b-sub" className="input" maxLength={160} value={edit.subtitle} onChange={(e) => setEdit({ ...edit, subtitle: e.target.value })} /></Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Bağlantı" htmlFor="b-link" hint="Site içi için /ilanlar gibi; dış bağlantı için https://…"><input id="b-link" className="input" maxLength={300} value={edit.link_url} onChange={(e) => setEdit({ ...edit, link_url: e.target.value })} /></Field>
              <Field label="Düğme metni" htmlFor="b-cta"><input id="b-cta" className="input" maxLength={30} value={edit.cta_label} onChange={(e) => setEdit({ ...edit, cta_label: e.target.value })} placeholder="İncele" /></Field>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 sm:items-center">
              <Field label="Sıra" htmlFor="b-sort" hint="Küçük sayı önce gösterilir."><input id="b-sort" inputMode="numeric" className="input" value={String(edit.sort_order)} onChange={(e) => setEdit({ ...edit, sort_order: Number(e.target.value.replace(/[^\d]/g, '')) || 0 })} /></Field>
              <Toggle checked={edit.is_active} onChange={(v) => setEdit({ ...edit, is_active: v })} label="Ana sayfada göster" />
            </div>
            {err && <p role="alert" className="text-sm font-semibold text-coral-ink">{err}</p>}
            <div className="flex justify-end gap-2">
              <button type="button" className="btn btn-ghost" onClick={() => setEdit(null)}>Vazgeç</button>
              <button className="btn btn-primary" disabled={busy || upBusy}>{busy && <Spinner size={16} />} Kaydet</button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
}

/* ---------------------------------------------------- Kurulum ve güvenlik */
// Google Play sekmesi: Play Console'a yüklenecek dosyalar, anahtar şifresi ve Play imza parmak izinin siteye tanıtılması
type PlayFile = { kind: string; name: string; url: string; size: number };
const fileSize = (n: number) => (n >= 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);
const SHOT_LABEL = ['Ekran görüntüsü 1 — ana sayfa', 'Ekran görüntüsü 2 — filtreler', 'Ekran görüntüsü 3 — güvenli alışveriş', 'Ekran görüntüsü 4 — üye ol'];

function PlayTab() {
  const { toast } = useApp();
  const { data, loading, error, reload } = useLoad<AllSettings>('admin?action=settings');
  const [fp, setFp] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const saved = data?.android?.fingerprints;
  useEffect(() => { if (saved) setFp(saved.join('\n')); }, [saved]);
  if (loading && !data) return <PageLoader />;
  if (error || !data || !data.android) return <ErrorBox message={error || 'Google Play bilgileri yüklenemedi.'} onRetry={reload} />;
  const android = data.android;
  const files: PlayFile[] = android.files || [];
  const one = (kind: string) => files.find((f) => f.kind === kind);
  const shots = files.filter((f) => f.kind === 'shot');
  const aab = one('aab');
  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    try {
      await api('admin?action=android', { method: 'PUT', body: { fingerprints: fp } });
      toast('Parmak izi kaydedildi. Uygulamada etkili olması birkaç dakika sürebilir.');
      reload();
    } catch (er) {
      setErr(errMsg(er));
    } finally {
      setBusy(false);
    }
  };
  const row = (f: PlayFile | undefined, title: string, where: string, primary = false) =>
    f ? (
      <li key={f.name} className="flex flex-col gap-2 rounded-2xl border border-line p-3 sm:flex-row sm:items-center">
        {['icon', 'feature', 'shot'].includes(f.kind) && <img src={f.url} alt="" loading="lazy" className={`shrink-0 rounded-lg border border-line bg-surface object-cover ${f.kind === 'feature' ? 'h-14 w-28' : f.kind === 'icon' ? 'h-14 w-14' : 'h-20 w-11'}`} />}
        <div className="min-w-0 flex-1">
          <p className="text-sm font-bold text-ink">{title}</p>
          <p className="break-all font-mono text-[0.72rem] text-muted">{f.name} · {fileSize(f.size)}</p>
          <p className="mt-0.5 text-[0.8rem] leading-snug text-ink-soft">{where}</p>
        </div>
        <a href={f.url} download={f.name} className={`btn btn-sm shrink-0 ${primary ? 'btn-primary' : 'btn-outline'}`}><Download size={15} /> İndir</a>
      </li>
    ) : null;
  const playReady = android.fingerprints.length > 0;
  return (
    <div className="flex flex-col gap-5">
      <section className="card p-5 sm:p-6">
        <h2 className="flex items-center gap-2 text-lg font-bold text-ink"><Smartphone size={20} className="text-brand-600" /> Google Play Console dosyaları</h2>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          Play Console’a yükleyeceğiniz her şey burada. Uygulama, sitenizi adres çubuğu olmadan tam ekran açar ve sitenin gerçek veritabanını kullanır; sitede yaptığınız değişiklikler uygulamada kendiliğinden görünür.
        </p>
        <ul className="mt-3 grid gap-2 text-[0.82rem] font-semibold text-ink sm:grid-cols-2">
          <li className="rounded-xl bg-surface p-3">Paket adı: <code className="font-mono">{android.package}</code></li>
          <li className="rounded-xl bg-surface p-3">Sürüm: {android.info?.version || '—'} (sürüm kodu {android.info?.version_code ?? '—'})</li>
          <li className="break-all rounded-xl bg-surface p-3 sm:col-span-2">Uygulamanın açtığı adres: <code className="font-mono">{android.info?.host ? `https://${android.info.host}` : '—'}</code></li>
        </ul>
        {!files.length ? (
          <p className="mt-4 rounded-xl bg-sun-soft p-3 text-sm font-semibold text-sun-ink">Dosyalar bu kurulumda bulunmuyor.</p>
        ) : (
          <>
            <h3 className="mt-5 text-sm font-extrabold uppercase tracking-wider text-brand-700">1 · Uygulama paketi</h3>
            <ul className="mt-2 flex flex-col gap-2">
              {row(aab, 'Uygulama paketi (AAB)', 'Play Console → Test ve yayınlama → Dahili test → Yeni sürüm oluştur → “Uygulama paketleri” alanına yükleyin.', true)}
            </ul>
            <h3 className="mt-5 text-sm font-extrabold uppercase tracking-wider text-brand-700">2 · Mağaza görselleri</h3>
            <ul className="mt-2 flex flex-col gap-2">
              {row(one('icon'), 'Uygulama simgesi (512×512)', 'Mağaza girişi → Uygulama simgesi.')}
              {row(one('feature'), 'Öne çıkan görsel (1024×500)', 'Mağaza girişi → Öne çıkan görsel.')}
              {shots.map((f, i) => row(f, SHOT_LABEL[i] || `Ekran görüntüsü ${i + 1}`, 'Mağaza girişi → Telefon ekran görüntüleri (en az 2 tane gerekir).'))}
            </ul>
            <h3 className="mt-5 text-sm font-extrabold uppercase tracking-wider text-brand-700">3 · Metinler ve rehber</h3>
            <ul className="mt-2 flex flex-col gap-2">
              {row(one('texts'), 'Mağaza metinleri', 'Uygulama adı, kısa ve tam açıklama, gizlilik politikası ve hesap silme adresleri. Kopyalayıp Play Console’a yapıştırın.')}
              {row(one('guide'), 'Adım adım yayın rehberi', 'Hesap açmadan yayına kadar bütün adımlar ve Play Console formlarının hazır yanıtları.')}
            </ul>
            <h3 className="mt-5 text-sm font-extrabold uppercase tracking-wider text-brand-700">4 · Yükleme anahtarı (saklayın)</h3>
            <ul className="mt-2 flex flex-col gap-2">
              {row(one('key'), 'Yükleme anahtarı (.jks)', 'Play Console’a yüklenmez. Uygulamanın sonraki sürümlerini üretmek için gerekir; güvenli bir yerde saklayın.')}
            </ul>
            {android.key_password && (
              <div className="mt-2 rounded-xl bg-surface p-3">
                <p className="text-xs font-extrabold uppercase tracking-wider text-muted">Yükleme anahtarının şifresi</p>
                <div className="mt-1 flex flex-wrap items-center gap-2">
                  <code className="min-w-0 flex-1 break-all font-mono text-sm font-semibold text-ink">{showPw ? android.key_password : '•'.repeat(24)}</code>
                  <button type="button" className="btn btn-outline btn-sm" onClick={() => setShowPw((v) => !v)}>{showPw ? 'Gizle' : 'Göster'}</button>
                  <button type="button" className="btn btn-outline btn-sm" onClick={async () => { try { await navigator.clipboard.writeText(android.key_password || ''); toast('Şifre kopyalandı.'); } catch { toast('Kopyalanamadı; “Göster” ile açıp elle not edin.', 'error'); } }}><Copy size={14} /> Kopyala</button>
                </div>
                <p className="mt-1.5 text-[0.78rem] leading-relaxed text-muted">Anahtar takma adı (alias): <code>upload</code>. Şifreyi bir yere not edin ve kimseyle paylaşmayın.</p>
              </div>
            )}
            {android.zip && (
              <div className="mt-5 flex flex-wrap items-center gap-3 border-t border-line pt-4">
                <a href={android.zip} download className="btn btn-outline"><Download size={17} /> Hepsini tek dosyada indir (.zip)</a>
                <p className="min-w-0 flex-1 text-[0.8rem] text-muted">Zip dosyasında ayrıca uygulamanın kaynak kodu vardır. Dosya yüklemeyi bilgisayardan yapmak en rahatıdır.</p>
              </div>
            )}
          </>
        )}
      </section>

      <section className="card p-5 sm:p-6">
        <h2 className="text-lg font-bold text-ink">AAB’yi yükledikten sonra: imza parmak izi</h2>
        <p className="mt-2 flex items-center gap-2 text-sm font-semibold text-ink"><StatusDot ok={playReady} warn /> Google Play imza parmak izi: {playReady ? 'tanımlı' : 'henüz eklenmedi'}</p>
        <form onSubmit={save} noValidate className="mt-3">
          <Field label="Google Play uygulama imzalama anahtarının SHA-256 parmak izi" htmlFor="and-fp" error={err} hint="Play Console → Test ve yayınlama → Uygulama bütünlüğü → Uygulama imzalama → “SHA-256 sertifika parmak izi”. Her satıra bir parmak izi.">
            <textarea id="and-fp" className={`input !min-h-20 font-mono !text-[0.78rem] ${err ? 'input-error' : ''}`} value={fp} onChange={(e) => setFp(e.target.value)} spellCheck={false} autoCapitalize="characters" placeholder="AB:CD:12:…" />
          </Field>
          <p className="mt-2 text-[0.8rem] leading-relaxed text-muted">
            Bu adımı mutlaka yapın. Eklenmezse uygulama çalışır ama üstte tarayıcı adres çubuğu görünür. Yükleme anahtarının parmak izi zaten tanımlıdır.
            {' '}<a href={android.assetlinks_url} target="_blank" rel="noopener noreferrer" className="font-bold text-brand-700 underline">Sitenin bağlantı beyanını görüntüle</a>
          </p>
          <button className="btn btn-outline mt-3" disabled={busy}>{busy && <Spinner size={16} />} Parmak izini kaydet</button>
        </form>
      </section>

      <section className="card p-5 sm:p-6">
        <h2 className="text-lg font-bold text-ink">Yayından önce bilmeniz gerekenler</h2>
        <ul className="mt-3 list-disc space-y-1.5 pl-5 text-sm leading-relaxed text-ink-soft">
          <li>Google Play geliştirici hesabı sizin adınıza açılır (tek seferlik kayıt ücreti ve kimlik doğrulaması vardır). Yeni bireysel hesaplarda Google, yayından önce bir süre kapalı test ister.</li>
          <li>Ücretli ilan, öne çıkarma ve vitrin gibi dijital hizmetlerde Google genellikle kendi ödeme sistemini şart koşar. Bu özellikler şu an kapalıdır; açmadan önce Google Play Ödemeler politikasına bakın.</li>
          <li>Site adresi değişirse uygulama yeni adresle yeniden üretilip Play’e güncelleme olarak yüklenmelidir.</li>
          <li>Google’ın incelemesi birkaç gün sürebilir; onay garantisi verilemez.</li>
        </ul>
      </section>
    </div>
  );
}

function SetupTab({ setAsk }: { setAsk: (a: Ask) => void }) {
  const { toast, reload: reloadApp } = useApp();
  const { data, loading, error, reload } = useLoad<AllSettings>('admin?action=settings');
  const [mid, setMid] = useState('');
  const [key, setKey] = useState('');
  const [salt, setSalt] = useState('');
  const [test, setTest] = useState(true);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  // Kodlar sekme açılırken önceden yüklenir; böylece "kopyala" düğmesi telefonda da tek dokunuşla çalışır.
  const sql = useLoad<{ lockdown: string; tables: string; seed: string }>('admin?action=setup-sql');
  const [copied, setCopied] = useState('');
  useEffect(() => { if (data) setTest(data.paytr.configured ? data.paytr.test_mode : true); }, [data]);
  if (loading && !data) return <PageLoader />;
  if (error || !data) return <ErrorBox message={error || 'Kurulum bilgileri yüklenemedi.'} onRetry={reload} />;
  const copy = async (text: string, ok: string, mark = '') => {
    let done = false;
    try { await navigator.clipboard.writeText(text); done = true; } catch { /* yedek yönteme geç */ }
    if (!done) {
      // Yedek yöntem: metni geçici bir yazı alanına koyup tarayıcının kopyalama komutunu kullan
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.cssText = 'position:fixed;top:0;left:0;width:1px;height:1px;opacity:0';
      document.body.appendChild(ta);
      ta.select();
      ta.setSelectionRange(0, text.length);
      try { done = document.execCommand('copy'); } catch { done = false; }
      ta.remove();
    }
    if (done) {
      toast(ok);
      if (mark) { setCopied(mark); window.setTimeout(() => setCopied((c) => (c === mark ? '' : c)), 4000); }
    } else toast('Kopyalanamadı. Aşağıdaki kod kutusuna uzun basıp “Tümünü seç → Kopyala” ile alabilirsiniz.', 'error');
  };
  const copyBtn = (key: 'lockdown' | 'tables' | 'seed', label: string, cls = 'btn-primary') => (
    <button type="button" className={`btn ${cls}`} disabled={!sql.data} onClick={() => sql.data && copy(sql.data[key], 'Kod kopyalandı. Şimdi Supabase SQL Editor’a yapıştırın.', key)}>
      {copied === key ? <Check size={17} /> : sql.loading && !sql.data ? <Spinner size={16} /> : <Copy size={16} />} {copied === key ? 'Kopyalandı' : label}
    </button>
  );
  const savePaytr = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    try {
      await api('admin?action=paytr', { method: 'PUT', body: { merchant_id: mid, merchant_key: key, merchant_salt: salt, test_mode: test } });
      setMid(''); setKey(''); setSalt('');
      toast('PayTR bilgileri şifrelenerek kaydedildi.');
      await reload();
      reloadApp(true);
    } catch (er) {
      setErr(errMsg(er));
    } finally {
      setBusy(false);
    }
  };
  const toggleCountry = async (c: Country) => {
    try {
      await api('admin?action=country', { method: 'PUT', body: { code: c.code, is_active: !c.is_active } });
      toast(`${c.name} ${c.is_active ? 'kapatıldı' : 'açıldı'}.`);
      await reload();
      reloadApp(true);
    } catch (er) {
      toast(errMsg(er), 'error');
    }
  };
  const p = data.paytr;
  const rls = data.rls;
  return (
    <div className="flex flex-col gap-5">
      <section className={`card p-5 sm:p-6 ${rls.enforced ? '' : '!border-[#ffc9bd]'}`}>
        <h2 className="flex items-center gap-2 text-lg font-bold text-ink">{rls.enforced ? <ShieldCheck size={21} className="text-mint-ink" /> : <ShieldAlert size={21} className="text-coral-ink" />} Veritabanı güvenliği (Row Level Security)</h2>
        <ul className="mt-3 grid gap-2 sm:grid-cols-2">
          <li className="flex items-center gap-2.5 rounded-xl bg-surface p-3 text-sm font-semibold"><StatusDot ok={rls.private_read_blocked} /> Özel tabloların dışarıdan okunması: {rls.private_read_blocked ? 'engelli' : 'AÇIK'}</li>
          <li className="flex items-center gap-2.5 rounded-xl bg-surface p-3 text-sm font-semibold"><StatusDot ok={rls.direct_write_blocked} /> Veritabanına doğrudan yazma: {rls.direct_write_blocked ? 'engelli' : 'AÇIK'}</li>
        </ul>
        {rls.enforced ? (
          <>
            <p className="mt-3 text-sm leading-relaxed text-muted">
              Canlı denetim başarılı{rls.tables_checked ? ` (${rls.tables_checked} tablo denendi)` : ''}: sitenin herkese açık anahtarıyla — üye girişi yapılmış olsa bile — veritabanı doğrudan okunamıyor ve veritabanına doğrudan yazılamıyor. Bütün işlemler, sahiplik ve yetki denetimi yapan sunucudan geçiyor.
            </p>
            <p className="mt-2 rounded-xl bg-mint-soft p-3 text-[0.82rem] font-semibold leading-relaxed text-mint-ink">
              Bu sitenin veritabanı için herhangi bir yere kod yapıştırmanız gerekmiyor. Daha önce kopyaladığınız güvenlik kodunu kullanmayın; başka bir veritabanında çalıştırıldığında “does not exist” hatası verir ve hiçbir şeyi değiştirmez.
            </p>
          </>
        ) : (
          <>
            <p className="mt-3 text-sm leading-relaxed text-ink-soft">
              {rls.open_tables && rls.open_tables.length > 0 && <><strong className="text-coral-ink">Dışarıdan okunabilen tablolar: {rls.open_tables.join(', ')}.</strong><br /><br /></>}
              Canlı denetimin sonucu: tablolarda satır güvenliği (RLS) <strong>açık</strong>, ancak her tabloda “herkese izin ver” türünde bir erişim kuralı da tanımlı ve bu kural diğer bütün kısıtlamaları geçersiz kılıyor. Daha önce verilen “enable row level security” komutları bu yüzden hiçbir şeyi değiştirmedi. Bu kural durdukça sitenin herkese açık anahtarını bilen biri sunucuyu atlayıp ilan, profil ve sohbet kayıtlarını okuyabilir, değiştirebilir veya silebilir; sahte ilan ekleyebilir.
              <br /><br />
              <strong>Bu durumda bile korunanlar:</strong> yönetici yetkisi (yalnızca sizin hesabınız; veritabanından değiştirilemez), site ayarları, ücretler, reklam kodları, reklam alanları ve bannerlar (sunucu imzalı; dışarıdan değiştirilirse uygulanmaz), mesaj içerikleri, telefon numaraları, şikâyet açıklamaları ve PayTR bilgileri (şifreli), fotoğraf depolama alanı.
              <br /><br />
              <strong>Çözüm:</strong> aşağıdaki tek kod, tabloları dış erişime tamamen kapatır. Site bundan etkilenmez; bütün işlemler zaten sunucu üzerinden yapılır. İlan, üye ve mesaj verisi silinmez. Kod çalışana kadar ücretli ilan, öne çıkarma ve vitrin satışını açmayın.
            </p>
            {data.server_key_ok === false ? (
              <p role="alert" className="mt-3 rounded-xl bg-coral-soft p-3 text-sm font-bold leading-relaxed text-coral-ink">
                Sunucunun veritabanı anahtarı yetkili (service role) anahtar olarak doğrulanamadı. Bu durumda veritabanını kapatan kodu ÇALIŞTIRMAYIN; site çalışmaz hale gelebilir. Önce Vercel’deki SUPABASE_SERVICE_ROLE_KEY değerinin doğru olduğundan emin olun.
              </p>
            ) : (
              <>
                <ol className="mt-4 list-decimal space-y-1.5 pl-5 text-sm leading-relaxed text-ink-soft">
                  <li><strong>Kodu kopyala</strong> düğmesine basın.</li>
                  <li><strong>Supabase SQL Editor’ı aç</strong> düğmesine basın ve Supabase hesabınızla giriş yapın.</li>
                  <li>Düzenleyicide eski kod varsa tamamen silin; boş alana yapıştırın ve <strong>Run / Çalıştır</strong> düğmesine basın.</li>
                  <li>Sonuç satırında <strong>“TAMAM: veritabanı dış erişime kapatıldı”</strong> yazmalı.</li>
                  <li>Bu sayfaya dönüp <strong>Yeniden denetle</strong> düğmesine basın; iki satır da “engelli” olmalı.</li>
                </ol>
                <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:flex-wrap">
                  {copyBtn('lockdown', 'Kodu kopyala')}
                  <a className="btn btn-outline" href={SQL_EDITOR_URL} target="_blank" rel="noopener noreferrer">Supabase SQL Editor’ı aç</a>
                  <button type="button" className="btn btn-ghost" onClick={reload}>Yeniden denetle</button>
                </div>
                {sql.error && <p role="alert" className="mt-2 text-sm font-semibold text-coral-ink">Kod yüklenemedi: {sql.error} <button type="button" className="underline" onClick={sql.reload}>Tekrar dene</button></p>}
                <div className="mt-3 rounded-xl border border-sun/70 bg-sun-soft/70 p-3 text-[0.82rem] leading-relaxed text-ink">
                  <p><strong>Kod yenilendi (3. sürüm):</strong> artık hiçbir şeyi silmiyor, değiştirmiyor ve yetki geri almıyor; her tabloya yalnızca “dışarıdan erişim kapalı” kuralı <strong>ekliyor</strong>. İçinde DROP, DELETE, TRUNCATE, ALTER ya da REVOKE komutu yok. Düzenleyicideki eski kodu tamamen silip buradan yeniden kopyalayın.</p>
                  <p className="mt-1.5"><strong>“Tehlikeli sorgu” uyarısı yine çıkarsa</strong> düzenleyici bu kodu da riskli sayıyor demektir; <strong>“Yine de çalıştır”</strong> düğmesine basmanız güvenlidir, hiçbir ilan, üye ya da mesaj silinmez.</p>
                  <p className="mt-1.5">Kırmızı hata <strong>“already exists”</strong> ise kural daha önce eklenmiştir (sorun yok, “Yeniden denetle”ye basın). <strong>“does not exist”</strong> ise açtığınız veritabanı bu sitenin veritabanı değildir; hiçbir şey değişmemiştir.</p>
                </div>
                <ul className="mt-3 list-disc space-y-1 rounded-xl bg-surface p-3 pl-7 text-[0.82rem] leading-relaxed text-ink-soft">
                  <li>Kodda adınız, e-postanız, şifreniz, anahtarınız ya da hesap kimliğiniz <strong>yoktur</strong>. Kod kimseye giriş ya da erişim hakkı vermez; yalnızca açık kapıları kapatır ve var olan hiçbir kaydı ya da kuralı değiştirmez.</li>
                  <li>Kodu yalnızca Supabase hesabınıza giriş yapmış biri çalıştırabilir. Başkasının bu kodu görmesi ona hiçbir şey kazandırmaz.</li>
                  <li>Çalıştıktan sonra, sitenin herkese açık anahtarını bilen biri — üye girişi yapmış olsa bile — veritabanına doğrudan bağlanıp üyeleri, mesajları ya da ilanları okuyamaz, değiştiremez, silemez.</li>
                  <li>Üyelik ve giriş, uygulamanın çalışması için açık kalır. Doğrudan giriş yapan biri yalnızca sıradan bir üye olur; yönetici yetkisi yalnızca sizin hesabınıza bağlıdır ve veritabanından değiştirilemez.</li>
                </ul>
                <p className="mt-3 flex items-center gap-2 text-[0.82rem] font-semibold text-ink-soft"><StatusDot ok={data.server_key_ok === true} warn /> Sunucu anahtarı denetimi: {data.server_key_ok ? 'yetkili — kod çalıştırıldıktan sonra site çalışmaya devam eder' : 'denetlenemedi'}</p>
                <details className="mt-3">
                  <summary className="text-sm font-bold text-brand-700">Kodu göster</summary>
                  <pre className="mt-2 max-h-60 overflow-auto whitespace-pre-wrap break-words rounded-xl bg-ink p-3 text-[0.7rem] leading-relaxed text-brand-100">{sql.data?.lockdown || 'Yükleniyor…'}</pre>
                </details>
                <p className="mt-3 text-[0.8rem] leading-relaxed text-muted">
                  Kod yalnızca Supabase SQL Editor’da çalışır; sohbete ya da başka bir yere yazmak onu çalıştırmaz. Kırmızı bir hata çıkarsa hata metnini aynen iletin. Supabase “projeye erişiminiz yok” ya da “proje bulunamadı” derse bu veritabanı sizin Supabase hesabınıza bağlı değildir; kodu sitenin kurulduğu platformun destek ekibine iletin ya da aşağıdaki kodlarla kendi Supabase projenizi kurun.
                </p>
              </>
            )}
          </>
        )}
      </section>

      <section className="card p-5 sm:p-6">
        <h2 className="flex items-center gap-2 text-lg font-bold text-ink"><Database size={20} className="text-brand-600" /> Kendi Supabase projeniz için kurulum kodları</h2>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          Siteyi kendi Supabase hesabınızdaki <strong className="text-ink">yeni ve boş</strong> bir projeye kurmak isterseniz bu iki kodu, projenizin SQL Editor’ına <strong className="text-ink">sırayla</strong> yapıştırıp çalıştırın. Tablolar baştan dış erişime kapalı kurulur.
        </p>
        <ol className="mt-3 flex flex-col gap-3">
          <li className="rounded-2xl border border-line p-4">
            <p className="text-sm font-bold text-ink">1. kod — tablolar, fotoğraf depolama ve güvenlik</p>
            <p className="mt-0.5 text-[0.82rem] text-muted">Yapıştırın → Run. “Success” yazmalı.</p>
            <div className="mt-2.5">{copyBtn('tables', '1. kodu kopyala', 'btn-outline')}</div>
          </li>
          <li className="rounded-2xl border border-line p-4">
            <p className="text-sm font-bold text-ink">2. kod — 20 kategori, alt kategoriler, 81 il ve ilçeler</p>
            <p className="mt-0.5 text-[0.82rem] text-muted">1. koddan sonra, yeni bir sorguya yapıştırın → Run. Uzun bir koddur; yapıştırması birkaç saniye sürebilir.</p>
            <div className="mt-2.5">{copyBtn('seed', '2. kodu kopyala', 'btn-outline')}</div>
          </li>
        </ol>
        <a className="btn btn-ghost btn-sm mt-3" href="https://supabase.com/dashboard/projects" target="_blank" rel="noopener noreferrer">Supabase projelerimi aç</a>
        <p className="mt-2 text-[0.8rem] leading-relaxed text-muted">
          Bu sitenin şu an kullandığı veritabanı sizin Supabase hesabınızda değildir; bu yüzden kendi projenizde yalnızca bu iki kod çalışır. Bu iki kod yeni tablolar oluşturduğu için Supabase “tehlikeli sorgu” uyarısı gösterebilir; yeni ve boş bir projede onaylamak güvenlidir. Bu iki kod, bu sitenin şu an kullandığı veritabanını değiştirmez. Sitenin yeni veritabanınızı kullanması için kodun kendi Vercel hesabınızda yayınlanması ve Supabase anahtarlarınızın Vercel’e girilmesi gerekir; adımlar aşağıdaki kaynak kodu paketindeki README dosyasındadır.
        </p>
      </section>

      <section className="card p-5 sm:p-6">
        <h2 className="flex items-center gap-2 text-lg font-bold text-ink"><CreditCard size={20} className="text-brand-600" /> PayTR ödeme entegrasyonu</h2>
        <p className="mt-2 flex items-center gap-2 text-sm font-bold text-ink"><StatusDot ok={p.configured} warn /> {p.configured ? `Mağaza bilgileri tanımlı (No: ${p.merchant_id_masked}) · ${p.test_mode ? 'Test modu' : 'Canlı mod'}${p.source === 'env' ? ' · ortam değişkeninden' : ''}` : 'Kurulum bekliyor — mağaza bilgileri girilmedi'}</p>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          Sunucu tarafı hazır: ödeme başlatma, PayTR bildiriminin imza (hash) ve tutar doğrulaması, ödeme doğrulanmadan ilanın etkinleşmemesi. Gerçek tahsilat için PayTR ile mağaza sözleşmesi yapıp aşağıdaki üç bilgiyi girmeniz gerekir. Bu entegrasyon gerçek PayTR hesabıyla henüz uçtan uca denenmedi; ilk işlemi test modunda yapın.
        </p>
        <div className="mt-3 rounded-xl bg-surface p-3">
          <p className="text-xs font-extrabold uppercase tracking-wider text-muted">PayTR Mağaza Paneli → Ayarlar → Bildirim URL</p>
          <div className="mt-1 flex flex-wrap items-center gap-2">
            <code className="min-w-0 flex-1 break-all text-sm font-semibold text-ink">{p.callback_url}</code>
            <button className="btn btn-outline btn-sm" onClick={() => copy(p.callback_url, 'Bildirim URL kopyalandı.')}><Copy size={14} /> Kopyala</button>
          </div>
        </div>
        {p.source === 'env' ? (
          <p className="mt-3 text-sm text-muted">Bilgiler sunucu ortam değişkenlerinden okunuyor; buradan değiştirilemez.</p>
        ) : (
          <form onSubmit={savePaytr} noValidate className="mt-4 grid gap-4 sm:grid-cols-3">
            <Field label="Mağaza No (merchant_id)" htmlFor="pt-id"><input id="pt-id" className="input font-mono" value={mid} onChange={(e) => setMid(e.target.value.replace(/\D/g, ''))} autoComplete="off" /></Field>
            <Field label="Mağaza Parola (merchant_key)" htmlFor="pt-key"><input id="pt-key" type="password" className="input font-mono" value={key} onChange={(e) => setKey(e.target.value)} autoComplete="new-password" /></Field>
            <Field label="Mağaza Gizli Anahtar (merchant_salt)" htmlFor="pt-salt"><input id="pt-salt" type="password" className="input font-mono" value={salt} onChange={(e) => setSalt(e.target.value)} autoComplete="new-password" /></Field>
            <div className="sm:col-span-3"><Toggle checked={test} onChange={setTest} label="Test modu" description="Açıkken PayTR gerçek tahsilat yapmaz. Canlıya geçerken kapatıp bilgileri yeniden kaydedin." /></div>
            {err && <p role="alert" className="text-sm font-semibold text-coral-ink sm:col-span-3">{err}</p>}
            <div className="flex flex-wrap gap-2 sm:col-span-3">
              <button className="btn btn-primary" disabled={busy || !mid || !key || !salt}>{busy && <Spinner size={16} />} {p.configured ? 'Bilgileri güncelle' : 'Bilgileri kaydet'}</button>
              {p.configured && <button type="button" className="btn btn-danger" onClick={() => setAsk({ title: 'PayTR bilgilerini sil', text: 'Mağaza bilgileri silinir ve tüm ücretli seçenekler kapatılır.', kind: 'none', confirm: 'Sil', danger: true, onOk: async () => { await api('admin?action=paytr', { method: 'DELETE' }); toast('PayTR bilgileri silindi.'); await reload(); reloadApp(true); } })}>Bilgileri sil</button>}
            </div>
            <p className="text-[0.8rem] text-muted sm:col-span-3">Bilgiler sunucuda şifrelenerek saklanır, tarayıcıya ve bu panele geri gönderilmez.</p>
          </form>
        )}
      </section>

      <section className="card p-5 sm:p-6">
        <h2 className="text-lg font-bold text-ink">Ülkeler</h2>
        <p className="mt-1 text-sm text-muted">Açık ülkeler ilan verirken ve aramada seçilebilir. Yeni ülkeler aynı yapıya (ülke → bölge → şehir) veri eklenerek açılır.</p>
        <ul className="mt-3 flex flex-col gap-2">
          {data.countries.map((c) => (
            <li key={c.code} className="flex items-center justify-between gap-3 rounded-xl bg-surface p-3">
              <span className="text-sm font-bold text-ink">{c.name} <span className="font-medium text-muted">· {c.currency}</span></span>
              {c.code === 'TR' ? <span className="chip bg-mint-soft text-mint-ink">Her zaman açık</span> : <Toggle checked={!!c.is_active} onChange={() => toggleCountry(c)} label={c.is_active ? 'Açık' : 'Kapalı'} />}
            </li>
          ))}
        </ul>
      </section>

      {data.source_zip && (
        <section className="card p-5 sm:p-6">
          <h2 className="flex items-center gap-2 text-lg font-bold text-ink"><Download size={20} className="text-brand-600" /> Kaynak kodu (kendi GitHub, Vercel ve Supabase hesabınız için)</h2>
          <p className="mt-2 text-sm leading-relaxed text-muted">
            Sitenin bütün kodunu tek bir zip dosyası olarak indirin. İçindeki <strong className="text-ink">README.md</strong> dosyası, kodu kendi GitHub deponuza yüklemeyi, Vercel’de yayınlamayı ve kendi Supabase veritabanınızı kurmayı adım adım anlatır. Bu işlem için bir bilgisayar gerekir.
          </p>
          <ul className="mt-3 list-disc space-y-1 pl-5 text-sm leading-relaxed text-ink-soft">
            <li><code>supabase/1-tablolar.sql</code> ve <code>supabase/2-veriler.sql</code>: yeni Supabase projenizde SQL Editor’da sırayla çalıştırılır; tablolar güvenli (dış erişime kapalı) olarak kurulur.</li>
            <li><code>.env.example</code>: Vercel’e girilecek ortam değişkenlerinin listesi.</li>
            <li>Zip dosyasında hiçbir şifre ya da gizli anahtar yoktur. Yeni kurulum boş başlar; buradaki ilanlar ve üyeler taşınmaz.</li>
          </ul>
          <a href={data.source_zip} download className="btn btn-primary mt-4"><Download size={17} /> Kaynak kodunu indir (.zip)</a>
          <p className="mt-2 text-[0.8rem] text-muted">Bu bağlantı yalnızca size gösterilir. Depoyu GitHub’da “Private” (gizli) olarak açmanızı öneririz.</p>
        </section>
      )}

      <section className="card p-5 sm:p-6">
        <h2 className="text-lg font-bold text-ink">Sizin hesabınızı gerektiren adımlar</h2>
        <ul className="mt-3 flex flex-col gap-2.5 text-sm leading-relaxed text-ink-soft">
          <li className="flex gap-2.5"><StatusDot ok={false} warn /><span><strong>E-posta gönderimi (SMTP):</strong> şifre sıfırlama e-postaları Supabase’in deneme amaçlı e-posta servisine bağlıdır ve saatlik gönderim sınırı çok düşüktür. Yayına geçmeden önce Supabase → Authentication → SMTP ayarlarına kendi e-posta sağlayıcınızı ekleyin.</span></li>
          <li className="flex gap-2.5"><StatusDot ok={false} warn /><span><strong>GitHub ve otomatik yayın:</strong> kaynak kodunun kendi GitHub deponuza aktarılması ve Vercel’in bu depoya bağlanması sizin hesap yetkinizi gerektirir.</span></li>
          <li className="flex gap-2.5"><StatusDot ok={false} warn /><span><strong>Alan adı:</strong> kendi alan adınızı Vercel projesine eklediğinizde PayTR Bildirim URL’sini ve AdSense site adresini yeni adrese göre güncelleyin.</span></li>
          <li className="flex gap-2.5"><StatusDot ok={false} warn /><span><strong>Hukuki metinler:</strong> KVKK, gizlilik ve kullanım koşulları sayfaları genel şablondur; “Ayarlar” sekmesinden işletme bilgilerinizi ekleyin ve metinleri bir hukukçuya inceletin.</span></li>
        </ul>
      </section>
    </div>
  );
}

export default function Admin() {
  useTitle('Yönetim paneli');
  const { profile, loading } = useAuth();
  const [sp, setSp] = useSearchParams();
  const [ask, setAsk] = useState<Ask | null>(null);
  const tab = (sp.get('sekme') as TabKey) || 'ozet';
  const go = (t: TabKey) => setSp(t === 'ozet' ? {} : { sekme: t });

  if (loading) return <PageLoader />;
  // Arayüz denetimi yalnızca kolaylık içindir; her yönetici isteği sunucuda ayrıca doğrulanır.
  // Yönetici olmayanlara panelin varlığı gösterilmez.
  if (!profile?.is_admin) return <NotFound />;

  const tabs: { k: TabKey; l: string; icon: React.ReactNode }[] = [
    { k: 'ozet', l: 'Özet', icon: <BarChart3 size={16} /> },
    { k: 'ilanlar', l: 'İlanlar', icon: <LayoutList size={16} /> },
    { k: 'kullanicilar', l: 'Kullanıcılar', icon: <Users size={16} /> },
    { k: 'sikayetler', l: 'Şikâyetler', icon: <Flag size={16} /> },
    { k: 'odemeler', l: 'Ödemeler', icon: <CreditCard size={16} /> },
    { k: 'ayarlar', l: 'Ayarlar', icon: <SettingsIcon size={16} /> },
    { k: 'reklam', l: 'Reklam', icon: <Megaphone size={16} /> },
    { k: 'bannerlar', l: 'Bannerlar', icon: <ImageIcon size={16} /> },
    { k: 'play', l: 'Google Play', icon: <Smartphone size={16} /> },
    { k: 'kurulum', l: 'Kurulum ve güvenlik', icon: <Wrench size={16} /> },
  ];
  return (
    <div className="wrap pb-10 pt-5 sm:pt-8">
      <div className="flex items-center gap-3">
        <span className="grid h-11 w-11 place-items-center rounded-2xl bg-ink text-sun"><ShieldCheck size={22} /></span>
        <div>
          <h1 className="text-2xl font-extrabold text-ink sm:text-3xl">Yönetim paneli</h1>
          <p className="text-sm text-muted">{profile.email}</p>
        </div>
      </div>
      <nav aria-label="Yönetim bölümleri" className="no-scrollbar -mx-4 mt-5 flex gap-1 overflow-x-auto px-4 sm:mx-0 sm:flex-wrap sm:rounded-2xl sm:bg-[#e9eef8] sm:p-1">
        {tabs.map((t) => (
          <button key={t.k} onClick={() => go(t.k)} aria-current={tab === t.k ? 'page' : undefined} className={`flex shrink-0 items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-bold transition-colors ${tab === t.k ? 'bg-brand-600 text-white' : 'text-ink-soft hover:bg-white hover:text-brand-700'}`}>
            {t.icon} {t.l}
          </button>
        ))}
      </nav>
      <div className="mt-6">
        {tab === 'ozet' && <Overview go={go} />}
        {tab === 'ilanlar' && <ListingsTab setAsk={setAsk} />}
        {tab === 'kullanicilar' && <UsersTab setAsk={setAsk} />}
        {tab === 'sikayetler' && <ReportsTab setAsk={setAsk} />}
        {tab === 'odemeler' && <PaymentsTab />}
        {tab === 'ayarlar' && <SettingsTab />}
        {tab === 'reklam' && <AdsTab />}
        {tab === 'bannerlar' && <BannersTab setAsk={setAsk} />}
        {tab === 'play' && <PlayTab />}
        {tab === 'kurulum' && <SetupTab setAsk={setAsk} />}
      </div>
      <AskModal ask={ask} onClose={() => setAsk(null)} />
    </div>
  );
}
