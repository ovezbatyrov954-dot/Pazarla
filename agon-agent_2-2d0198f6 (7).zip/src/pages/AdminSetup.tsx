import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { KeyRound, ShieldCheck } from 'lucide-react';
import { api, errMsg } from '../lib/api';
import { useAuth } from '../contexts/AuthContext';
import { useApp } from '../contexts/AppContext';
import NotFound from './NotFound';
import { Field, PageLoader, Spinner, useTitle } from '../components/ui';

export default function AdminSetup() {
  useTitle('Yönetici kurulumu');
  const { user, refresh } = useAuth();
  const { toast } = useApp();
  const nav = useNavigate();
  const [state, setState] = useState<{ available: boolean; is_admin: boolean } | null>(null);
  const [code, setCode] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api<{ available: boolean; is_admin: boolean }>('user?action=admin-setup')
      .then(setState)
      .catch((e) => setError(errMsg(e)));
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (code.trim().length < 12) return setError('Kurulum kodunu eksiksiz girin.');
    setBusy(true);
    setError(null);
    try {
      await api('user?action=claim-admin', { method: 'POST', body: { code: code.trim() } });
      await refresh();
      toast('Yönetici yetkisi hesabınıza tanımlandı.');
      nav('/yonetim', { replace: true });
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  if (!state && !error) return <PageLoader />;
  if (state && !state.is_admin && !state.available) return <NotFound />;
  return (
    <div className="wrap max-w-lg pt-8 sm:pt-14">
      <div className="card p-6 sm:p-8">
        <span className="grid h-14 w-14 place-items-center rounded-2xl bg-brand-600 text-white"><ShieldCheck size={28} /></span>
        <h1 className="mt-4 text-2xl font-extrabold text-ink">Yönetici kurulumu</h1>
        {state?.is_admin ? (
          <>
            <p className="mt-2 text-sm leading-relaxed text-muted">Bu hesap zaten yönetici yetkisine sahip.</p>
            <Link to="/yonetim" className="btn btn-primary mt-5">Yönetim paneline git</Link>
          </>
        ) : state && !state.available ? (
          <p className="mt-2 text-sm leading-relaxed text-muted">Yönetici hesabı daha önce belirlenmiş. Kurulum kodu şu anda kullanılamaz.</p>
        ) : (
          <>
            <p className="mt-2 text-sm leading-relaxed text-muted">
              Yönetici yetkisi, size teslim edilen tek kullanımlık kurulum koduyla şu anda giriş yapmış olduğunuz hesaba (<strong className="text-ink">{user?.email}</strong>) tanımlanır. Doğru hesapla giriş yaptığınızdan emin olun.
            </p>
            <form onSubmit={submit} noValidate className="mt-5 flex flex-col gap-4">
              <Field label="Kurulum kodu" htmlFor="setup-code" error={error}>
                <input id="setup-code" className={`input font-mono tracking-wider ${error ? 'input-error' : ''}`} value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="PZR-XXXXX-XXXXX-XXXXX-XXXXX" autoComplete="off" autoCapitalize="characters" spellCheck={false} maxLength={40} />
              </Field>
              <button className="btn btn-primary btn-lg" disabled={busy}>{busy ? <Spinner size={18} /> : <KeyRound size={18} />} Yönetici yetkisini tanımla</button>
            </form>
          </>
        )}
        {error && !state && <p role="alert" className="mt-3 text-sm font-semibold text-coral-ink">{error}</p>}
      </div>
    </div>
  );
}
