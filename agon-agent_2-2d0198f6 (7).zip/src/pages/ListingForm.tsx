import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { BadgeCheck, CreditCard, FolderSearch, Info, ShieldCheck } from 'lucide-react';
import { api, ApiError, errMsg } from '../lib/api';
import type { ListingDetail } from '../lib/types';
import { useApp } from '../contexts/AppContext';
import { useAuth } from '../contexts/AuthContext';
import CategoryIcon from '../components/CategoryIcon';
import LocationSelect from '../components/LocationSelect';
import type { Loc } from '../components/LocationSelect';
import PhotoUploader from '../components/PhotoUploader';
import { ErrorBox, Field, PageLoader, Spinner, useTitle } from '../components/ui';
import { formatPrice } from '../lib/format';

type Errors = Record<string, string | null>;

export default function ListingForm() {
  const { id } = useParams();
  const editing = !!id;
  useTitle(editing ? 'İlanı düzenle' : 'İlan ver');
  const nav = useNavigate();
  const { topCats, subsOf, catById, settings, country, countryOf, toast } = useApp();
  const { profile, quota, refresh } = useAuth();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [condition, setCondition] = useState<'new' | 'used' | ''>('');
  const [catId, setCatId] = useState<number | null>(null);
  const [subId, setSubId] = useState<number | null>(null);
  const [attrs, setAttrs] = useState<Record<string, string>>({});
  const [loc, setLoc] = useState<Loc>({ country_code: country, city_id: null, district_id: null });
  const [images, setImages] = useState<string[]>([]);
  const [photoBusy, setPhotoBusy] = useState(false);
  const [errors, setErrors] = useState<Errors>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(editing);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [catWarn, setCatWarn] = useState<{ id: number; name: string } | null>(null);

  useEffect(() => {
    if (!editing) return;
    let on = true;
    api<{ listing: ListingDetail; is_owner: boolean }>(`listings?id=${id}`)
      .then((d) => {
        if (!on) return;
        if (!d.is_owner) throw new ApiError('Bu ilanı düzenleme yetkiniz yok.', 403);
        const l = d.listing;
        setTitle(l.title);
        setDescription(l.description);
        setPrice(String(l.price));
        setCondition(l.condition);
        setCatId(l.category_id);
        setSubId(l.subcategory_id);
        setAttrs(Object.fromEntries(Object.entries(l.attributes || {}).map(([k, v]) => [k, String(v)])));
        setLoc({ country_code: l.country_code, city_id: l.city_id, district_id: l.district_id });
        setImages(l.images);
        setStatus(l.status);
      })
      .catch((e) => on && setLoadError(errMsg(e)))
      .finally(() => on && setLoading(false));
    return () => { on = false; };
  }, [editing, id]);

  const cat = catById(catId);
  const subs = catId ? subsOf(catId) : [];
  const defs = useMemo(() => (cat?.filters || []).filter((d) => !d.only || (subId !== null && d.only.includes(subId))), [cat, subId]);
  const ctry = countryOf(loc.country_code);
  const maxPhotos = settings?.max_photos || 12;
  const clear = (k: string) => setErrors((e) => (e[k] ? { ...e, [k]: null } : e));

  const validate = (): Errors => {
    const e: Errors = {};
    const t = title.trim();
    if (t.length < 5) e.title = 'Başlık en az 5 karakter olmalı.';
    else if (t.length > 100) e.title = 'Başlık en fazla 100 karakter olabilir.';
    if (!catId) e.category = 'Bir kategori seçin.';
    else if (!subId) e.category = 'Bir alt kategori seçin.';
    const d = description.trim();
    if (d.length < 20) e.description = 'Açıklama en az 20 karakter olmalı.';
    else if (d.length > 5000) e.description = 'Açıklama en fazla 5000 karakter olabilir.';
    const p = Number(price);
    if (!price || !Number.isFinite(p) || p <= 0) e.price = 'Geçerli bir fiyat girin.';
    if (!condition) e.condition = 'Ürünün durumunu seçin.';
    if (!loc.city_id) e.city = `${ctry?.region_label || 'Şehir'} seçin.`;
    if (!loc.district_id) e.district = `${ctry?.district_label || 'İlçe'} seçin.`;
    if (images.length < 1) e.images = 'En az 1 fotoğraf yükleyin.';
    for (const def of defs) {
      const v = attrs[def.key];
      if (def.type === 'number' && v) {
        const n = Number(v);
        if (!Number.isFinite(n) || n < (def.min ?? 0) || n > (def.max ?? 1e9)) e[`a_${def.key}`] = `${def.min ?? 0} ile ${def.max ?? ''} arasında bir değer girin.`;
      }
    }
    return e;
  };

  const submit = async (ev?: React.FormEvent, confirmCategory = false) => {
    ev?.preventDefault();
    setFormError(null);
    setCatWarn(null);
    if (photoBusy) return setFormError('Fotoğrafların yüklenmesi bitene kadar bekleyin.');
    const e = validate();
    setErrors(e);
    const first = Object.keys(e).find((k) => e[k]);
    if (first) {
      setFormError('Lütfen işaretli alanları düzeltin.');
      document.querySelector('[data-error="true"]')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    setBusy(true);
    try {
      const payload = {
        id: editing ? Number(id) : undefined,
        confirm_category: confirmCategory || undefined,
        title: title.trim(),
        description: description.trim(),
        price: Number(price),
        condition,
        category_id: catId,
        subcategory_id: subId,
        country_code: loc.country_code,
        city_id: loc.city_id,
        district_id: loc.district_id,
        images,
        attributes: Object.fromEntries(defs.filter((d) => attrs[d.key]).map((d) => [d.key, d.type === 'number' ? Number(attrs[d.key]) : attrs[d.key]])),
      };
      const r = await api<{ id: number; status: string; requires_payment?: boolean }>('listings', { method: editing ? 'PUT' : 'POST', body: payload });
      await refresh();
      if (r.status === 'pending_payment') {
        toast('İlanınız kaydedildi. Yayına alınması için ödemeyi tamamlayın.', 'info');
        nav(`/odeme/listing_fee/${r.id}`);
      } else {
        toast(r.status === 'active' ? 'İlanınız yayında!' : 'İlanınız alındı. Onaylandıktan sonra yayına girecek.');
        nav(`/ilan/${r.id}`);
      }
    } catch (err) {
      // Başlık seçilen kategoriye uymuyor: hata yerine doğru kategori önerilir.
      if (err instanceof ApiError && err.code === 'CATEGORY_MISMATCH' && err.data) {
        const sid = Number(err.data.suggested_category_id);
        setCatWarn({ id: sid, name: catById(sid)?.name || String(err.data.suggested_category_name || '') });
        window.setTimeout(() => document.getElementById('cat-warn')?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 50);
        return;
      }
      const msg = errMsg(err);
      setFormError(msg);
      if (err instanceof ApiError && err.code && ['title', 'description', 'price', 'condition', 'category', 'city', 'district', 'images'].includes(err.code)) {
        setErrors((x) => ({ ...x, [err.code as string]: msg }));
      }
    } finally {
      setBusy(false);
    }
  };

  if (loading) return <PageLoader />;
  if (loadError) return <div className="wrap py-16"><ErrorBox message={loadError} /></div>;

  const section = 'card p-5 sm:p-6';
  const h2 = 'mb-4 flex items-center gap-2.5 text-lg font-bold text-ink';
  const step = (n: number) => <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-brand-600 font-display text-sm font-bold text-white">{n}</span>;

  return (
    <div className="wrap max-w-3xl pt-5 sm:pt-8">
      <h1 className="text-3xl font-extrabold text-ink">{editing ? 'İlanı düzenle' : 'İlan ver'}</h1>
      <p className="mt-1 text-muted">{editing ? 'Değişiklikleriniz kaydedildikten sonra ilanınız yeniden onaya gönderilebilir.' : 'Birkaç adımda ilanınızı oluşturun. * işaretli alanlar zorunludur.'}</p>

      {!editing && quota && (
        <div className={`mt-5 flex items-start gap-3 rounded-2xl border p-4 ${quota.next_requires_payment ? 'border-sun/70 bg-sun-soft/70' : 'border-[#b5ecd3] bg-mint-soft'}`}>
          {quota.next_requires_payment ? <CreditCard size={20} className="mt-0.5 shrink-0 text-sun-ink" /> : <BadgeCheck size={20} className="mt-0.5 shrink-0 text-mint-ink" />}
          <p className="text-sm font-semibold leading-relaxed text-ink">
            {quota.next_requires_payment
              ? `Ücretsiz ${quota.free_total} ilan hakkınızı kullandınız. Bu ilan için ${formatPrice(quota.listing_fee)} ilan ücreti ödenir; ödeme doğrulandıktan sonra ilanınız işleme alınır.`
              : quota.free_left > 0
                ? `Bu ilan ücretsiz. Kalan ücretsiz ilan hakkınız: ${quota.free_left} / ${quota.free_total}.`
                : 'İlan vermek şu anda ücretsiz.'}
          </p>
        </div>
      )}
      {editing && status === 'rejected' && (
        <div className="mt-5 flex items-start gap-3 rounded-2xl border border-[#ffc9bd] bg-coral-soft p-4 text-sm font-semibold text-coral-ink"><Info size={18} className="mt-0.5 shrink-0" /> Bu ilan reddedilmişti. Düzenleyip kaydettiğinizde yeniden onaya gönderilir.</div>
      )}
      {profile && !profile.full_name && (
        <div className="mt-5 flex items-start gap-3 rounded-2xl border border-sun/70 bg-sun-soft/70 p-4 text-sm font-semibold text-ink">
          <Info size={18} className="mt-0.5 shrink-0 text-sun-ink" />
          <span>İlan verebilmek için önce <Link to="/hesabim/profil" className="text-brand-700 underline">profilinize adınızı ve soyadınızı ekleyin</Link>.</span>
        </div>
      )}

      <form onSubmit={submit} noValidate className="mt-6 flex flex-col gap-5">
        <section className={section} data-error={!!errors.category}>
          <h2 className={h2}>{step(1)} Kategori</h2>
          {!cat ? (
            <>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3" role="group" aria-label="Kategori seçin">
                {topCats.map((c) => (
                  <button key={c.id} type="button" onClick={() => { setCatId(c.id); setSubId(null); setAttrs({}); clear('category'); setCatWarn(null); }} className="flex items-center gap-2.5 rounded-xl border-[1.5px] border-line bg-white p-2.5 text-left text-[0.84rem] font-bold leading-tight text-ink transition-colors hover:border-brand-400 hover:bg-brand-50">
                    <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg text-white" style={{ background: c.color || '#1447E6' }}><CategoryIcon name={c.icon} size={18} /></span>
                    {c.name}
                  </button>
                ))}
              </div>
            </>
          ) : (
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-3 rounded-xl bg-brand-50 p-3">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg text-white" style={{ background: cat.color || '#1447E6' }}><CategoryIcon name={cat.icon} size={20} /></span>
                <span className="min-w-0 flex-1 font-bold text-ink">{cat.name}</span>
                <button type="button" className="btn btn-outline btn-sm" onClick={() => { setCatId(null); setSubId(null); setAttrs({}); setCatWarn(null); }}>Değiştir</button>
              </div>
              <div>
                <label className="label" htmlFor="f-sub">Alt kategori<span className="ml-0.5 text-coral-ink" aria-hidden="true">*</span></label>
                <select id="f-sub" className={`input ${errors.category ? 'input-error' : ''}`} value={subId ?? ''} onChange={(e) => { setSubId(e.target.value ? Number(e.target.value) : null); clear('category'); }}>
                  <option value="">Seçin</option>
                  {subs.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
            </div>
          )}
          {errors.category && <p role="alert" className="mt-2 text-[0.82rem] font-semibold text-coral-ink">{errors.category}</p>}
        </section>

        <section className={section}>
          <h2 className={h2}>{step(2)} İlan bilgileri</h2>
          <div className="flex flex-col gap-4">
            <div data-error={!!errors.title}>
              <Field label="İlan başlığı" htmlFor="f-title" required error={errors.title} hint={`Ürünün adını, markasını ve modelini yazın. ${title.length}/100`}>
                <input id="f-title" className={`input ${errors.title ? 'input-error' : ''}`} maxLength={100} value={title} onChange={(e) => { setTitle(e.target.value); clear('title'); setCatWarn(null); }} placeholder="Örn. Az kullanılmış 3 kişilik kanepe" />
              </Field>
            </div>
            <div data-error={!!errors.description}>
              <Field label="Açıklama" htmlFor="f-desc" required error={errors.description} hint={`Ürünün durumunu, kusurlarını ve teslim koşullarını açıkça yazın. ${description.length}/5000`}>
                <textarea id="f-desc" className={`input !min-h-40 ${errors.description ? 'input-error' : ''}`} maxLength={5000} value={description} onChange={(e) => { setDescription(e.target.value); clear('description'); }} />
              </Field>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div data-error={!!errors.price}>
                <Field label={`Fiyat (${ctry?.currency === 'TRY' ? 'TL' : ctry?.currency || ''})`} htmlFor="f-price" required error={errors.price}>
                  <input id="f-price" inputMode="decimal" className={`input ${errors.price ? 'input-error' : ''}`} value={price} onChange={(e) => { setPrice(e.target.value.replace(',', '.').replace(/[^\d.]/g, '').replace(/(\..*)\./g, '$1').slice(0, 14)); clear('price'); }} placeholder="0" />
                </Field>
                {Number(price) > 0 && <p className="mt-1 text-[0.82rem] font-bold text-brand-700">{formatPrice(Number(price), ctry?.currency)}</p>}
              </div>
              <fieldset data-error={!!errors.condition}>
                <legend className="label">Durum<span className="ml-0.5 text-coral-ink" aria-hidden="true">*</span></legend>
                <div className={`grid grid-cols-2 gap-2 rounded-[0.9rem] ${errors.condition ? 'ring-2 ring-coral-ink/50' : ''}`}>
                  {[{ v: 'new', l: 'Sıfır' }, { v: 'used', l: 'İkinci el' }].map((o) => (
                    <label key={o.v} className={`flex min-h-[2.9rem] cursor-pointer items-center justify-center rounded-[0.8rem] border-[1.5px] text-sm font-bold transition-colors has-[:focus-visible]:ring-4 has-[:focus-visible]:ring-brand-200 ${condition === o.v ? 'border-brand-600 bg-brand-50 text-brand-700' : 'border-line bg-white text-ink-soft hover:border-brand-300'}`}>
                      <input type="radio" name="condition" value={o.v} checked={condition === o.v} onChange={() => { setCondition(o.v as 'new' | 'used'); clear('condition'); }} className="sr-only" />
                      {o.l}
                    </label>
                  ))}
                </div>
                {errors.condition && <p role="alert" className="mt-1.5 text-[0.82rem] font-semibold text-coral-ink">{errors.condition}</p>}
              </fieldset>
            </div>
          </div>
        </section>

        {defs.length > 0 && (
          <section className={section}>
            <h2 className={h2}>{step(3)} {cat?.name} özellikleri <span className="text-sm font-medium text-muted">(isteğe bağlı)</span></h2>
            <div className="grid gap-4 sm:grid-cols-2">
              {defs.map((d) => (
                <div key={d.key} data-error={!!errors[`a_${d.key}`]}>
                  <Field label={`${d.label}${d.unit ? ` (${d.unit})` : ''}`} htmlFor={`f-a-${d.key}`} error={errors[`a_${d.key}`]}>
                    {d.type === 'select' ? (
                      <select id={`f-a-${d.key}`} className="input" value={attrs[d.key] || ''} onChange={(e) => setAttrs((a) => ({ ...a, [d.key]: e.target.value }))}>
                        <option value="">Belirtilmedi</option>
                        {(d.options || []).map((o) => <option key={o} value={o}>{o}</option>)}
                      </select>
                    ) : d.type === 'number' ? (
                      <input id={`f-a-${d.key}`} inputMode="numeric" className={`input ${errors[`a_${d.key}`] ? 'input-error' : ''}`} value={attrs[d.key] || ''} onChange={(e) => { setAttrs((a) => ({ ...a, [d.key]: e.target.value.replace(/[^\d]/g, '').slice(0, 9) })); clear(`a_${d.key}`); }} />
                    ) : (
                      <input id={`f-a-${d.key}`} className="input" maxLength={80} value={attrs[d.key] || ''} onChange={(e) => setAttrs((a) => ({ ...a, [d.key]: e.target.value }))} />
                    )}
                  </Field>
                </div>
              ))}
            </div>
          </section>
        )}

        <section className={section} data-error={!!(errors.city || errors.district)}>
          <h2 className={h2}>{step(defs.length ? 4 : 3)} Konum</h2>
          <LocationSelect value={loc} required onChange={(v) => { setLoc(v); clear('city'); clear('district'); }} errors={{ city: errors.city, district: errors.district }} idPrefix="f-loc" />
        </section>

        <section className={section} data-error={!!errors.images}>
          <h2 className={h2}>{step(defs.length ? 5 : 4)} Fotoğraflar</h2>
          <PhotoUploader value={images} onChange={(u) => { setImages(u); if (u.length) clear('images'); }} onBusy={setPhotoBusy} max={maxPhotos} error={errors.images} />
        </section>

        <div className="flex items-start gap-2.5 rounded-2xl bg-white p-4 text-[0.84rem] leading-relaxed text-muted">
          <ShieldCheck size={18} className="mt-0.5 shrink-0 text-brand-600" />
          <span>
            İlanı göndererek <Link to="/kullanim-kosullari" className="font-bold text-brand-700 underline">kullanım koşullarını ve ilan kurallarını</Link> kabul etmiş olursunuz.
            {settings?.moderation_enabled ? ' İlanlar yayınlanmadan önce incelenir.' : ''} Telefon numaranız ilan metninde değil, profil ayarlarınızdaki tercihe göre gösterilir.
          </span>
        </div>

        {catWarn && (
          <div id="cat-warn" role="alert" className="rounded-2xl border border-sun bg-sun-soft p-4 sm:p-5">
            <p className="flex items-start gap-2.5 font-bold text-ink">
              <FolderSearch size={20} className="mt-0.5 shrink-0 text-sun-ink" />
              <span>Bu ilan “{catWarn.name}” kategorisine daha uygun görünüyor.</span>
            </p>
            <p className="mt-1.5 text-sm leading-relaxed text-ink-soft">
              Seçtiğiniz kategori: <strong>{cat?.name}</strong>. İlanların doğru yerde görünmesi için kategoriyi değiştirmenizi öneririz. Yanlış kategorideki ilanlar yönetici tarafından taşınabilir ya da kaldırılabilir.
            </p>
            <div className="mt-3 flex flex-col gap-2 sm:flex-row">
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => {
                  setCatId(catWarn.id);
                  setSubId(null);
                  setAttrs({});
                  setCatWarn(null);
                  setErrors((x) => ({ ...x, category: 'Yeni kategori için bir alt kategori seçin.' }));
                  window.setTimeout(() => document.getElementById('f-sub')?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 50);
                }}
              >
                Kategoriyi “{catWarn.name}” yap
              </button>
              <button type="button" className="btn btn-outline" disabled={busy} onClick={() => submit(undefined, true)}>
                {busy && <Spinner size={16} />} Bu kategoride kalsın, onaya gönder
              </button>
            </div>
            <p className="mt-2 text-[0.8rem] text-muted">“Onaya gönder” seçeneğinde ilanınız hemen yayına girmez; yönetici inceledikten sonra yayınlanır.</p>
          </div>
        )}

        {formError && <p role="alert" className="rounded-xl bg-coral-soft px-4 py-3 text-sm font-bold text-coral-ink">{formError}</p>}

        <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
          <button type="button" className="btn btn-ghost" onClick={() => nav(-1)}>Vazgeç</button>
          <button type="submit" className="btn btn-sun btn-lg" disabled={busy || photoBusy || !!profile?.is_blocked}>
            {(busy || photoBusy) && <Spinner size={18} />}
            {photoBusy ? 'Fotoğraflar yükleniyor…' : editing ? 'Değişiklikleri kaydet' : quota?.next_requires_payment ? 'Kaydet ve ödemeye geç' : 'İlanı yayınla'}
          </button>
        </div>
      </form>
    </div>
  );
}
