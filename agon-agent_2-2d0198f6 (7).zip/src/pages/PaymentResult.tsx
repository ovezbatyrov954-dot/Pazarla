import { useEffect, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { CheckCircle2, Clock, XCircle } from 'lucide-react';
import { api } from '../lib/api';
import type { PaymentRow } from '../lib/types';
import { Spinner, useTitle } from '../components/ui';
import { formatPrice, PAYMENT_TYPE } from '../lib/format';

export default function PaymentResult() {
  useTitle('Ödeme sonucu');
  const [sp] = useSearchParams();
  const oid = sp.get('oid') || '';
  const [pay, setPay] = useState<PaymentRow | null>(null);
  const [error, setError] = useState(false);
  const [tries, setTries] = useState(0);
  const timer = useRef<number | undefined>(undefined);

  // Ödeme durumu yalnızca sunucudaki kayıttan okunur; PayTR bildirimi doğrulanana kadar "doğrulanıyor" gösterilir.
  useEffect(() => {
    let on = true;
    const check = async (n: number) => {
      try {
        const p = await api<PaymentRow>(`payments?action=status&oid=${encodeURIComponent(oid)}`);
        if (!on) return;
        setPay(p);
        setTries(n);
        if (p.status === 'pending' && n < 20) timer.current = window.setTimeout(() => check(n + 1), 3000);
      } catch {
        if (on) setError(true);
      }
    };
    if (oid) check(0);
    else setError(true);
    return () => {
      on = false;
      window.clearTimeout(timer.current);
    };
  }, [oid]);

  const box = 'card mx-auto mt-10 flex max-w-lg flex-col items-center gap-3 px-6 py-10 text-center';
  return (
    <div className="wrap">
      {error ? (
        <div className={box}>
          <XCircle size={44} className="text-coral-ink" />
          <h1 className="text-2xl font-extrabold text-ink">Ödeme kaydı bulunamadı</h1>
          <p className="text-sm text-muted">Bu ödeme size ait değil ya da bağlantı hatalı.</p>
          <Link to="/hesabim/odemeler" className="btn btn-primary mt-2">Ödemelerime git</Link>
        </div>
      ) : !pay ? (
        <div className={box} role="status"><Spinner size={32} className="text-brand-600" /><p className="font-semibold text-muted">Ödeme durumu kontrol ediliyor…</p></div>
      ) : pay.status === 'paid' ? (
        <div className={box}>
          <CheckCircle2 size={48} className="text-mint-ink" />
          <h1 className="text-2xl font-extrabold text-ink">Ödemeniz alındı</h1>
          <p className="text-sm leading-relaxed text-muted">{PAYMENT_TYPE[pay.type]} · {formatPrice(pay.amount)}{pay.test_mode ? ' (test modu)' : ''}. İşleminiz ilanınıza uygulandı.</p>
          <div className="mt-2 flex flex-wrap justify-center gap-2">
            {pay.listing_id && <Link to={`/ilan/${pay.listing_id}`} className="btn btn-primary">İlana git</Link>}
            <Link to="/hesabim/odemeler" className="btn btn-outline">Ödemelerim</Link>
          </div>
        </div>
      ) : pay.status === 'failed' ? (
        <div className={box}>
          <XCircle size={48} className="text-coral-ink" />
          <h1 className="text-2xl font-extrabold text-ink">Ödeme tamamlanamadı</h1>
          <p className="text-sm leading-relaxed text-muted">{pay.failed_reason || 'Ödeme işlemi başarısız oldu.'} Kartınızdan tahsilat yapılmadı.</p>
          <div className="mt-2 flex flex-wrap justify-center gap-2">
            {pay.listing_id && <Link to={`/odeme/${pay.type}/${pay.listing_id}`} className="btn btn-primary">Tekrar dene</Link>}
            <Link to="/hesabim" className="btn btn-outline">İlanlarım</Link>
          </div>
        </div>
      ) : (
        <div className={box} role="status">
          {tries < 20 ? <Spinner size={36} className="text-brand-600" /> : <Clock size={44} className="text-sun-ink" />}
          <h1 className="text-2xl font-extrabold text-ink">Ödemeniz doğrulanıyor</h1>
          <p className="text-sm leading-relaxed text-muted">
            {tries < 20
              ? 'Ödeme kuruluşundan onay bekleniyor. Bu sayfa kendiliğinden güncellenecek.'
              : 'Onay beklenenden uzun sürdü. Ödemeniz doğrulandığında hizmet otomatik olarak etkinleşir; durumu Ödemelerim sayfasından izleyebilirsiniz.'}
          </p>
          <Link to="/hesabim/odemeler" className="btn btn-outline mt-2">Ödemelerim</Link>
        </div>
      )}
    </div>
  );
}
