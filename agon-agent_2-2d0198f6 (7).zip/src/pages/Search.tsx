import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { ChevronLeft, SearchX, SlidersHorizontal, X, Zap } from 'lucide-react';
import { api, errMsg } from '../lib/api';
import type { Card, Category, FilterDef } from '../lib/types';
import { useApp } from '../contexts/AppContext';
import ListingCard, { CardGrid, CardSkeleton } from '../components/ListingCard';
import CategoryIcon from '../components/CategoryIcon';
import AdSlot from '../components/AdSlot';
import { Crumbs, EmptyState, ErrorBox, Modal, Pagination, useTitle } from '../components/ui';
import { useCities, useDistricts } from '../components/LocationSelect';
import { formatNumber } from '../lib/format';

interface Result { items: Card[]; total: number; page: number; per: number; featured: Card[] }

const SORTS = [
  { v: 'yeni', api: 'new', label: 'En yeni' },
  { v: 'ucuz', api: 'cheap', label: 'En ucuz' },
  { v: 'pahali', api: 'expensive', label: 'En pahalı' },
  { v: 'populer', api: 'views', label: 'En çok görüntülenen' },
];

function Range({ label, unit, lo, hi, onApply, idBase }: { label: string; unit?: string; lo: string; hi: string; onApply: (lo: string, hi: string) => void; idBase: string }) {
  const [a, setA] = useState(lo);
  const [b, setB] = useState(hi);
  useEffect(() => { setA(lo); setB(hi); }, [lo, hi]);
  const dirty = a !== lo || b !== hi;
  return (
    <form onSubmit={(e) => { e.preventDefault(); onApply(a.trim(), b.trim()); }}>
      <p className="label">{label}{unit ? ` (${unit})` : ''}</p>
      <div className="flex items-center gap-2">
        <label className="sr-only" htmlFor={`${idBase}-min`}>{label} en az</label>
        <input id={`${idBase}-min`} inputMode="numeric" className="input input-sm" placeholder="En az" value={a} onChange={(e) => setA(e.target.value.replace(/[^\d]/g, ''))} />
        <span className="text-muted">–</span>
        <label className="sr-only" htmlFor={`${idBase}-max`}>{label} en çok</label>
        <input id={`${idBase}-max`} inputMode="numeric" className="input input-sm" placeholder="En çok" value={b} onChange={(e) => setB(e.target.value.replace(/[^\d]/g, ''))} />
        <button type="submit" disabled={!dirty} className="btn btn-primary btn-sm shrink-0 !px-2.5" aria-label={`${label} filtresini uygula`}>Uygula</button>
      </div>
    </form>
  );
}

export default function SearchPage() {
  const { slug, sub: subSlug } = useParams();
  const [sp, setSp] = useSearchParams();
  const nav = useNavigate();
  const { topCats, subsOf, catBySlug, country, countryOf, countries, setCountry } = useApp();
  const cat: Category | undefined = slug ? catBySlug(slug) : undefined;
  const subs = cat ? subsOf(cat.id) : [];
  const sub = subSlug ? subs.find((s) => s.slug === subSlug) : undefined;
  const [data, setData] = useState<Result | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [sheet, setSheet] = useState(false);
  const [tick, setTick] = useState(0);

  const q = sp.get('q') || '';
  const cityId = Number(sp.get('sehir')) || null;
  const districtId = Number(sp.get('ilce')) || null;
  const sort = SORTS.find((s) => s.v === sp.get('sirala')) || SORTS[0];
  const page = Math.max(1, Number(sp.get('sayfa')) || 1);
  const durum = sp.get('durum') || '';
  const { cities } = useCities(country);
  const { districts } = useDistricts(cityId);
  const ctry = countryOf(country);

  const defs: FilterDef[] = useMemo(
    () => (cat?.filters || []).filter((d) => d.type !== 'text' && (!sub || !d.only || d.only.includes(sub.id))),
    [cat, sub],
  );

  const title = sub ? sub.name : cat ? cat.name : q ? `“${q}” için sonuçlar` : 'Tüm ilanlar';
  useTitle(title);

  const query = useMemo(() => {
    const p = new URLSearchParams({ action: 'search', country, sort: sort.api, page: String(page) });
    if (cat) p.set('category', String(cat.id));
    if (sub) p.set('sub', String(sub.id));
    if (q) p.set('q', q);
    if (cityId) p.set('city', String(cityId));
    if (districtId) p.set('district', String(districtId));
    if (sp.get('min')) p.set('min', sp.get('min') as string);
    if (sp.get('max')) p.set('max', sp.get('max') as string);
    if (durum === 'sifir') p.set('condition', 'new');
    if (durum === 'ikinci-el') p.set('condition', 'used');
    sp.forEach((v, k) => { if (k.startsWith('a_') && v) p.set(k, v); });
    return p.toString();
  }, [sp, cat, sub, country, q, cityId, districtId, sort.api, page, durum]);

  useEffect(() => {
    if (slug && !cat) return;
    const ctl = new AbortController();
    setLoading(true);
    setError(null);
    api<Result>(`listings?${query}`, { anon: true, signal: ctl.signal })
      .then((d) => { setData(d); setLoading(false); })
      .catch((e) => {
        if (e?.name === 'AbortError') return;
        setError(errMsg(e));
        setLoading(false);
      });
    return () => ctl.abort();
  }, [query, tick, slug, cat]);

  const set = (patch: Record<string, string | null>) => {
    const next = new URLSearchParams(sp);
    for (const [k, v] of Object.entries(patch)) {
      if (v) next.set(k, v);
      else next.delete(k);
    }
    if (!('sayfa' in patch)) next.delete('sayfa');
    setSp(next);
  };

  const goCat = (c?: Category, s?: Category) => {
    const keep = new URLSearchParams();
    for (const k of ['q', 'sehir', 'ilce', 'min', 'max', 'durum', 'sirala']) if (sp.get(k)) keep.set(k, sp.get(k) as string);
    const qs = keep.toString();
    nav(`${c ? `/kategori/${c.slug}${s ? `/${s.slug}` : ''}` : '/ilanlar'}${qs ? `?${qs}` : ''}`);
  };

  const chips: { label: string; clear: () => void }[] = [];
  if (q) chips.push({ label: `Arama: ${q}`, clear: () => set({ q: null }) });
  if (cityId) chips.push({ label: cities.find((c) => c.id === cityId)?.name || 'Şehir', clear: () => set({ sehir: null, ilce: null }) });
  if (districtId) chips.push({ label: districts.find((d) => d.id === districtId)?.name || 'İlçe', clear: () => set({ ilce: null }) });
  if (sp.get('min') || sp.get('max')) chips.push({ label: `Fiyat: ${sp.get('min') ? formatNumber(Number(sp.get('min'))) : '0'} – ${sp.get('max') ? formatNumber(Number(sp.get('max'))) : '∞'}`, clear: () => set({ min: null, max: null }) });
  if (durum) chips.push({ label: durum === 'sifir' ? 'Sıfır' : 'İkinci el', clear: () => set({ durum: null }) });
  for (const d of defs) {
    if (d.type === 'select' && sp.get(`a_${d.key}`)) chips.push({ label: `${d.label}: ${sp.get(`a_${d.key}`)}`, clear: () => set({ [`a_${d.key}`]: null }) });
    if (d.type === 'number' && (sp.get(`a_${d.key}_min`) || sp.get(`a_${d.key}_max`))) {
      chips.push({ label: `${d.label}: ${sp.get(`a_${d.key}_min`) || '0'} – ${sp.get(`a_${d.key}_max`) || '∞'}`, clear: () => set({ [`a_${d.key}_min`]: null, [`a_${d.key}_max`]: null }) });
    }
  }

  const clearAll = () => {
    const next = new URLSearchParams();
    if (sp.get('sirala')) next.set('sirala', sp.get('sirala') as string);
    setSp(next);
  };

  const filters = (idp: string) => (
    <div className="flex flex-col gap-5">
      <div>
        <p className="label">Kategori</p>
        {cat ? (
          <div className="flex flex-col gap-0.5">
            <button onClick={() => goCat()} className="flex items-center gap-1 rounded-lg px-2 py-1.5 text-left text-sm font-semibold text-muted hover:bg-surface hover:text-ink">
              <ChevronLeft size={15} /> Tüm kategoriler
            </button>
            <button onClick={() => goCat(cat)} className={`flex items-center gap-2 rounded-lg px-2 py-1.5 text-left text-sm font-bold ${!sub ? 'bg-brand-50 text-brand-700' : 'text-ink hover:bg-surface'}`}>
              <CategoryIcon name={cat.icon} size={16} /> {cat.name}
            </button>
            <ul className="ml-3 mt-0.5 flex max-h-64 flex-col gap-0.5 overflow-y-auto border-l border-line pl-2">
              {subs.map((s) => (
                <li key={s.id}>
                  <button onClick={() => goCat(cat, s)} aria-current={sub?.id === s.id ? 'true' : undefined} className={`w-full rounded-lg px-2 py-1.5 text-left text-[0.86rem] ${sub?.id === s.id ? 'bg-brand-50 font-bold text-brand-700' : 'font-medium text-ink-soft hover:bg-surface'}`}>
                    {s.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        ) : (
          <ul className="flex max-h-72 flex-col gap-0.5 overflow-y-auto pr-1">
            {topCats.map((c) => (
              <li key={c.id}>
                <button onClick={() => goCat(c)} className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-[0.86rem] font-medium text-ink-soft hover:bg-surface hover:text-ink">
                  <CategoryIcon name={c.icon} size={15} className="shrink-0 text-muted" /> {c.name}
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="flex flex-col gap-2">
        <p className="label !mb-0">Konum</p>
        {countries.length > 1 && (
          <>
            <label className="sr-only" htmlFor={`${idp}-country`}>Ülke</label>
            <select id={`${idp}-country`} className="input input-sm" value={country} onChange={(e) => { setCountry(e.target.value); set({ sehir: null, ilce: null }); }}>
              {countries.map((c) => <option key={c.code} value={c.code}>{c.name}</option>)}
            </select>
          </>
        )}
        <label className="sr-only" htmlFor={`${idp}-city`}>{ctry?.region_label || 'Şehir'}</label>
        <select id={`${idp}-city`} className="input input-sm" value={cityId ?? ''} onChange={(e) => set({ sehir: e.target.value || null, ilce: null })}>
          <option value="">Tüm {(ctry?.region_label || 'şehir').toLocaleLowerCase('tr-TR')}ler</option>
          {cities.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        {cityId && (
          <>
            <label className="sr-only" htmlFor={`${idp}-district`}>{ctry?.district_label || 'İlçe'}</label>
            <select id={`${idp}-district`} className="input input-sm" value={districtId ?? ''} onChange={(e) => set({ ilce: e.target.value || null })}>
              <option value="">Tümü ({ctry?.district_label || 'İlçe'})</option>
              {districts.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </>
        )}
      </div>

      <Range idBase={`${idp}-price`} label="Fiyat" unit={ctry?.currency === 'TRY' ? 'TL' : ctry?.currency_symbol} lo={sp.get('min') || ''} hi={sp.get('max') || ''} onApply={(lo, hi) => set({ min: lo || null, max: hi || null })} />

      <fieldset>
        <legend className="label">Durum</legend>
        <div className="grid grid-cols-3 gap-1 rounded-xl bg-surface p-1">
          {[{ v: '', l: 'Tümü' }, { v: 'sifir', l: 'Sıfır' }, { v: 'ikinci-el', l: 'İkinci el' }].map((o) => (
            <button key={o.v} type="button" aria-pressed={durum === o.v} onClick={() => set({ durum: o.v || null })} className={`rounded-lg px-2 py-1.5 text-[0.82rem] font-bold transition-colors ${durum === o.v ? 'bg-white text-brand-700 shadow-sm' : 'text-muted hover:text-ink'}`}>
              {o.l}
            </button>
          ))}
        </div>
      </fieldset>

      {defs.length > 0 && (
        <div className="flex flex-col gap-4 border-t border-line pt-4">
          <p className="text-xs font-extrabold uppercase tracking-wider text-brand-700">{cat?.name} filtreleri</p>
          {defs.map((d) =>
            d.type === 'select' ? (
              <div key={d.key}>
                <label className="label" htmlFor={`${idp}-a-${d.key}`}>{d.label}</label>
                <select id={`${idp}-a-${d.key}`} className="input input-sm" value={sp.get(`a_${d.key}`) || ''} onChange={(e) => set({ [`a_${d.key}`]: e.target.value || null })}>
                  <option value="">Tümü</option>
                  {(d.options || []).map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
            ) : (
              <Range key={d.key} idBase={`${idp}-a-${d.key}`} label={d.label} unit={d.unit} lo={sp.get(`a_${d.key}_min`) || ''} hi={sp.get(`a_${d.key}_max`) || ''} onApply={(lo, hi) => set({ [`a_${d.key}_min`]: lo || null, [`a_${d.key}_max`]: hi || null })} />
            ),
          )}
        </div>
      )}
      {chips.length > 0 && <button onClick={clearAll} className="btn btn-outline btn-sm">Filtreleri temizle</button>}
    </div>
  );

  if (slug && !cat) {
    return (
      <div className="wrap py-16">
        <EmptyState icon={<SearchX size={26} />} title="Kategori bulunamadı" text="Bu adreste bir kategori yok." action={<Link to="/ilanlar" className="btn btn-primary">Tüm ilanlara git</Link>} />
      </div>
    );
  }

  const crumbs = [{ label: 'Ana sayfa', to: '/' }, { label: 'İlanlar', to: cat ? '/ilanlar' : undefined }];
  if (cat) crumbs.push({ label: cat.name, to: sub ? `/kategori/${cat.slug}` : undefined });
  if (sub) crumbs.push({ label: sub.name, to: undefined });

  return (
    <div className="wrap pt-4 sm:pt-6">
      <Crumbs items={crumbs} />
      <div className="mt-4 grid gap-6 lg:grid-cols-[272px_1fr]">
        <aside className="hidden lg:block" aria-label="Filtreler">
          <div className="card sticky top-[7.5rem] max-h-[calc(100dvh-8.5rem)] overflow-y-auto p-4">{filters('f')}</div>
        </aside>
        <div className="min-w-0">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div className="min-w-0">
              <h1 className="text-2xl font-extrabold text-ink sm:text-3xl">{title}</h1>
              <p className="mt-1 text-sm font-medium text-muted" aria-live="polite">
                {loading ? 'Aranıyor…' : error ? '' : `${formatNumber(data?.total || 0)} ilan bulundu`}
              </p>
            </div>
            <div className="flex w-full items-center gap-2 sm:w-auto">
              <button onClick={() => setSheet(true)} className="btn btn-outline btn-sm flex-1 lg:!hidden">
                <SlidersHorizontal size={16} /> Filtrele{chips.length > 0 && <span className="grid h-5 min-w-5 place-items-center rounded-full bg-brand-600 px-1 text-[11px] text-white">{chips.length}</span>}
              </button>
              <label className="sr-only" htmlFor="sort">Sıralama</label>
              <select id="sort" className="input input-sm flex-1 font-semibold sm:!w-52 sm:flex-none" value={sort.v} onChange={(e) => set({ sirala: e.target.value === 'yeni' ? null : e.target.value })}>
                {SORTS.map((s) => <option key={s.v} value={s.v}>{s.label}</option>)}
              </select>
            </div>
          </div>

          {chips.length > 0 && (
            <ul className="mt-3 flex flex-wrap gap-1.5" aria-label="Etkin filtreler">
              {chips.map((c) => (
                <li key={c.label}>
                  <button onClick={c.clear} className="chip border border-brand-200 bg-brand-50 py-1 pl-2.5 pr-1.5 text-brand-800 hover:bg-brand-100" aria-label={`${c.label} filtresini kaldır`}>
                    {c.label} <X size={13} />
                  </button>
                </li>
              ))}
            </ul>
          )}

          <div className="mt-5">
            {error ? (
              <ErrorBox message={error} onRetry={() => setTick((t) => t + 1)} />
            ) : loading ? (
              <CardGrid dense>{Array.from({ length: 12 }).map((_, i) => <CardSkeleton key={i} />)}</CardGrid>
            ) : data && data.items.length ? (
              <>
                {data.featured.length > 0 && (
                  <section className="mb-6 rounded-3xl border border-sun/60 bg-sun-soft/60 p-3 sm:p-4" aria-label="Öne çıkan ilanlar">
                    <h2 className="mb-3 flex items-center gap-1.5 text-sm font-extrabold uppercase tracking-wide text-sun-ink"><Zap size={15} fill="currentColor" /> Öne çıkan ilanlar</h2>
                    <CardGrid dense>{data.featured.map((it) => <ListingCard key={`f${it.id}`} item={it} />)}</CardGrid>
                  </section>
                )}
                <CardGrid dense>{data.items.slice(0, 8).map((it) => <ListingCard key={it.id} item={it} />)}</CardGrid>
                <AdSlot placement="category" className="my-5" />
                {data.items.length > 8 && <CardGrid dense>{data.items.slice(8).map((it) => <ListingCard key={it.id} item={it} />)}</CardGrid>}
                <Pagination page={data.page} total={data.total} per={data.per} onChange={(p) => { set({ sayfa: p > 1 ? String(p) : null }); window.scrollTo({ top: 0 }); }} />
              </>
            ) : (
              <EmptyState
                icon={<SearchX size={26} />}
                title="Bu kriterlere uygun ilan bulunamadı"
                text={chips.length ? 'Filtreleri azaltmayı veya farklı bir arama yapmayı deneyin.' : 'Bu kategoride henüz yayında ilan yok. İlk ilanı siz verebilirsiniz.'}
                action={
                  <div className="mt-1 flex flex-wrap justify-center gap-2">
                    {chips.length > 0 && <button onClick={clearAll} className="btn btn-outline">Filtreleri temizle</button>}
                    <Link to="/ilan-ver" className="btn btn-sun">İlan ver</Link>
                  </div>
                }
              />
            )}
          </div>
        </div>
      </div>

      <Modal open={sheet} onClose={() => setSheet(false)} title="Filtrele">
        {filters('m')}
        <button className="btn btn-primary mt-5 w-full" onClick={() => setSheet(false)}>
          {loading ? 'Sonuçları göster' : `${formatNumber(data?.total || 0)} ilanı göster`}
        </button>
      </Modal>
    </div>
  );
}
