import { Link } from 'react-router-dom';
import { useApp } from '../contexts/AppContext';
import { useTitle } from '../components/ui';

type Doc = 'kvkk' | 'gizlilik' | 'kosullar' | 'guvenlik' | 'hesap';

const TITLES: Record<Doc, string> = {
  kvkk: 'KVKK Aydınlatma Metni',
  gizlilik: 'Gizlilik ve Çerez Politikası',
  kosullar: 'Kullanım Koşulları ve İlan Kuralları',
  guvenlik: 'Güvenli Alışveriş Rehberi',
  hesap: 'Hesap ve Veri Silme',
};

export default function Legal({ doc }: { doc: Doc }) {
  useTitle(TITLES[doc]);
  const { settings } = useApp();
  const company = settings?.company_name || 'PAZARLA';
  const address = settings?.company_address;
  const email = settings?.contact_email;
  const contact = (
    <>
      {email ? <>Taleplerinizi <a href={`mailto:${email}`}>{email}</a> adresine iletebilirsiniz.</> : <>Başvuru için iletişim adresi, platform işletmecisi tarafından bu sayfada yayımlanacaktır.</>}
      {address ? <> Posta adresi: {address}.</> : null}
    </>
  );
  const tabs: Doc[] = ['kosullar', 'gizlilik', 'kvkk', 'guvenlik', 'hesap'];
  const path: Record<Doc, string> = { kvkk: '/kvkk', gizlilik: '/gizlilik', kosullar: '/kullanim-kosullari', guvenlik: '/guvenli-alisveris', hesap: '/hesap-silme' };

  return (
    <div className="wrap max-w-4xl pt-5 sm:pt-8">
      <nav aria-label="Bilgilendirme sayfaları" className="no-scrollbar -mx-4 flex gap-1.5 overflow-x-auto px-4 sm:mx-0 sm:px-0">
        {tabs.map((t) => (
          <Link key={t} to={path[t]} aria-current={t === doc ? 'page' : undefined} className={`shrink-0 rounded-xl px-3 py-2 text-sm font-bold ${t === doc ? 'bg-brand-600 text-white' : 'bg-white text-ink-soft hover:text-brand-700'}`}>
            {TITLES[t]}
          </Link>
        ))}
      </nav>
      <article className="card prose-legal mt-4 p-6 sm:p-10">
        <h1 className="text-3xl font-extrabold text-ink">{TITLES[doc]}</h1>
        <p className="!mt-2 !text-sm !text-muted">Son güncelleme: Kasım 2026</p>

        {doc === 'kvkk' && (
          <>
            <p>Bu metin, 6698 sayılı Kişisel Verilerin Korunması Kanunu (“KVKK”) m. 10 uyarınca, PAZARLA platformunu kullanan kişilerin kişisel verilerinin nasıl işlendiği hakkında bilgi vermek amacıyla hazırlanmıştır.</p>
            <h2>1. Veri sorumlusu</h2>
            <p>Veri sorumlusu, platformu işleten <strong>{company}</strong>’dır. {contact}</p>
            <h2>2. İşlenen kişisel veriler</h2>
            <ul>
              <li><strong>Kimlik ve iletişim:</strong> ad soyad, e-posta adresi, (paylaşmanız hâlinde) telefon numarası, şehir.</li>
              <li><strong>Hesap ve işlem güvenliği:</strong> şifrenizin geri döndürülemez özeti, oturum kayıtları, IP adresi, işlem zamanları.</li>
              <li><strong>İlan içerikleri:</strong> ilan metinleri, fotoğraflar, fiyat, konum (il/ilçe) ve ilan özellikleri.</li>
              <li><strong>İletişim içerikleri:</strong> platform üzerinden diğer üyelerle yaptığınız yazışmalar, şikâyet bildirimleri.</li>
              <li><strong>Ödeme kayıtları:</strong> ücretli hizmet satın alırsanız işlem tutarı, tarihi, durumu ve fatura bilgileriniz. Kart bilgileriniz PAZARLA tarafından görülmez ve saklanmaz; ödeme kuruluşu tarafından işlenir.</li>
            </ul>
            <h2>3. İşleme amaçları ve hukuki sebepler</h2>
            <ul>
              <li>Üyeliğin oluşturulması, ilan yayınlama ve mesajlaşma hizmetinin sunulması — <em>sözleşmenin kurulması ve ifası</em> (KVKK m. 5/2-c).</li>
              <li>Sahte ilan, dolandırıcılık ve kötüye kullanımın önlenmesi, şikâyetlerin incelenmesi — <em>meşru menfaat</em> (m. 5/2-f).</li>
              <li>Yer sağlayıcı olarak trafik kayıtlarının ve mali kayıtların saklanması — <em>hukuki yükümlülük</em> (m. 5/2-ç; 5651 sayılı Kanun, Vergi Usul Kanunu).</li>
              <li>Reklam çerezleri ve kişiselleştirilmiş reklamlar — yalnızca <em>açık rızanız</em> ile (m. 5/1).</li>
            </ul>
            <h2>4. Verilerin aktarılması</h2>
            <p>Verileriniz; barındırma ve veritabanı hizmeti aldığımız altyapı sağlayıcılara (Supabase, Vercel), ücretli hizmetlerde ödeme kuruluşuna (PayTR), rıza vermeniz hâlinde reklam hizmeti sağlayıcısına (Google) ve kanunen yetkili kamu kurumlarına, belirtilen amaçlarla sınırlı olarak aktarılabilir. Altyapı sağlayıcıların sunucuları yurt dışında bulunabilir; bu aktarımlar KVKK m. 9’a uygun şekilde yürütülür.</p>
            <p>İlanınızda yer alan bilgiler ile satıcı profilinizdeki adınız herkese açıktır. Telefon numaranız yalnızca siz izin verirseniz ve yalnızca giriş yapmış üyelere gösterilir.</p>
            <h2>5. Saklama süresi</h2>
            <p>Hesabınızı sildiğinizde profiliniz, ilanlarınız, fotoğraflarınız, favorileriniz ve mesajlarınız silinir. Mevzuat gereği saklanması zorunlu olan ödeme ve trafik kayıtları, ilgili yasal süre boyunca kimliğinizle ilişkisi en aza indirilerek saklanır ve süre sonunda silinir.</p>
            <h2>6. Haklarınız</h2>
            <p>KVKK m. 11 uyarınca; verilerinizin işlenip işlenmediğini öğrenme, bilgi talep etme, düzeltilmesini veya silinmesini isteme, aktarıldığı üçüncü kişileri öğrenme, işlemeye itiraz etme ve zararınızın giderilmesini talep etme haklarına sahipsiniz. Profil bilgilerinizi <Link to="/hesabim/profil">Profil ve ayarlar</Link> sayfasından düzeltebilir, hesabınızı aynı sayfadan kalıcı olarak silebilirsiniz. {contact} Başvurular en geç 30 gün içinde yanıtlanır.</p>
          </>
        )}

        {doc === 'gizlilik' && (
          <>
            <p>PAZARLA olarak yalnızca hizmeti sunmak için gerekli olan verileri toplar, bu verileri satmayız. Kişisel verilerin işlenmesine ilişkin ayrıntılar için <Link to="/kvkk">KVKK Aydınlatma Metni</Link>’ne bakabilirsiniz.</p>
            <h2>Topladığımız bilgiler</h2>
            <ul>
              <li>Üye olurken verdiğiniz ad soyad ve e-posta adresi; isteğe bağlı olarak telefon, şehir, profil fotoğrafı ve tanıtım yazısı.</li>
              <li>Yayınladığınız ilanlar, yüklediğiniz fotoğraflar, gönderdiğiniz mesajlar ve şikâyetler.</li>
              <li>Kötüye kullanımı önlemek için IP adresi ve işlem zamanları gibi teknik kayıtlar.</li>
            </ul>
            <h2>Bilgilerinizi nasıl koruyoruz</h2>
            <ul>
              <li>Şifreler düz metin olarak saklanmaz; kimlik doğrulama Supabase Auth altyapısıyla yapılır.</li>
              <li>Mesaj içerikleri ve telefon numaraları veritabanında şifrelenmiş olarak tutulur.</li>
              <li>Yüklediğiniz fotoğraflar cihazınızda yeniden oluşturulur; böylece fotoğrafın içindeki konum (EXIF) bilgisi sunucuya gönderilmez.</li>
              <li>E-posta adresiniz ilanlarda gösterilmez. Telefon numaranızı yalnızca siz açarsanız ve yalnızca giriş yapmış üyeler görebilir.</li>
              <li>Kart bilgileriniz PAZARLA sunucularına hiçbir zaman ulaşmaz; ödeme, ödeme kuruluşunun güvenli sayfasında yapılır.</li>
            </ul>
            <h2>Çerezler ve yerel depolama</h2>
            <ul>
              <li><strong>Zorunlu:</strong> oturumunuzu açık tutan kimlik belirteci, ülke tercihi ve çerez tercihiniz tarayıcınızın yerel depolama alanında saklanır. Bunlar olmadan site çalışmaz.</li>
              <li><strong>Reklam (isteğe bağlı):</strong> sitede Google AdSense reklamları etkinleştirilirse Google, reklam göstermek ve ölçmek için çerez kullanabilir. Bu çerezler yalnızca çerez bildiriminde “Tümünü kabul et” seçeneğini işaretlerseniz yüklenir.</li>
            </ul>
            <p>Tercihinizi değiştirmek için tarayıcınızın site verilerini temizleyebilirsiniz; bildirim yeniden gösterilir.</p>
            <h2>Üçüncü taraf hizmetler</h2>
            <p>Barındırma için Vercel, veritabanı, kimlik doğrulama ve dosya depolama için Supabase, ödeme için PayTR ve (etkinleştirilirse) reklam için Google AdSense kullanılır. Bu sağlayıcılar verileri yalnızca hizmetin sunulması amacıyla işler.</p>
            <h2>İletişim</h2>
            <p>{contact}</p>
          </>
        )}

        {doc === 'kosullar' && (
          <>
            <p>PAZARLA’yı kullanarak aşağıdaki koşulları kabul etmiş olursunuz.</p>
            <h2>1. Hizmetin niteliği</h2>
            <p>PAZARLA, kullanıcıların ilan yayınladığı ve birbirleriyle iletişim kurduğu bir ilan platformudur. PAZARLA satışın tarafı değildir; ürünlerin satıcısı, alıcısı veya aracısı olarak hareket etmez. Alıcı ile satıcı arasındaki ödeme, teslimat ve kargo işlemlerine aracılık etmez, para transferi yapmaz ve ürünlere ilişkin garanti vermez.</p>
            <h2>2. Üyelik</h2>
            <ul>
              <li>Üye olabilmek için 18 yaşını doldurmuş olmanız ve doğru bilgi vermeniz gerekir.</li>
              <li>Hesabınızın güvenliğinden ve hesabınızla yapılan işlemlerden siz sorumlusunuz.</li>
              <li>Hesabınızı dilediğiniz zaman <Link to="/hesabim/profil">Profil ve ayarlar</Link> sayfasından silebilirsiniz.</li>
            </ul>
            <h2>3. İlan kuralları</h2>
            <ul>
              <li>İlan; gerçek, elinizde bulunan ve satmaya yetkili olduğunuz bir ürüne ait olmalı; başlık, açıklama, fiyat ve fotoğraflar ürünü doğru yansıtmalıdır.</li>
              <li>Aynı ürün için birden fazla ilan açılamaz. İlan doğru kategoride yayınlanmalıdır.</li>
              <li>İlan metnine telefon, bağlantı (link) veya başka sitelere yönlendirme yazılmamalıdır; iletişim için profil ayarlarınızdaki telefon tercihi ve mesajlaşma kullanılır.</li>
              <li>İlanlar yayınlanmadan önce incelenebilir; kurallara uymayan ilanlar reddedilebilir veya kaldırılabilir.</li>
            </ul>
            <h2>4. Satışı yasak ürünler</h2>
            <p>Aşağıdakiler başta olmak üzere mevzuata aykırı ürün ve hizmetlerin ilanı verilemez: ateşli silahlar ve mühimmat, uyuşturucu ve uyarıcı maddeler, reçeteli ilaçlar, tütün ve alkollü içecekler, sahte veya taklit ürünler, çalıntı mallar, resmî kimlik ve belgeler, canlı hayvan, insan organı, kumar ve bahis hizmetleri, müstehcen içerikler ile başkalarının fikrî haklarını ihlal eden ürünler.</p>
            <h2>5. Ücretler</h2>
            <p>Her üyeye belirli sayıda ücretsiz ilan hakkı tanınır{settings ? ` (şu anda ${settings.free_listing_count} ilan)` : ''}. Ücretsiz hak dışındaki ilanlar ile öne çıkarma ve vitrin gibi ek hizmetler ücretli olabilir; güncel ücret, ödeme adımından önce açıkça gösterilir. Ücretli hizmetler, ödeme ödeme kuruluşu tarafından doğrulandıktan sonra etkinleşir. PAZARLA satışlardan komisyon almaz.</p>
            <h2>6. Şikâyet ve yaptırımlar</h2>
            <p>Her ilanda bulunan “Şikâyet et” düğmesiyle kurallara aykırı ilanları bildirebilirsiniz. Kuralları ihlal eden, sahte ilan veren veya diğer kullanıcıları dolandırmaya çalışan hesaplar uyarı yapılmaksızın engellenebilir, ilanları kaldırılabilir ve gerektiğinde yetkili makamlara bildirilebilir.</p>
            <h2>7. Sorumluluk</h2>
            <p>İlan içeriklerinin doğruluğundan ve hukuka uygunluğundan ilanı veren kullanıcı sorumludur. PAZARLA, 5651 sayılı Kanun kapsamında yer sağlayıcı olarak hareket eder; kullanıcılar arasındaki alışverişten doğan uyuşmazlıkların tarafı değildir. Alışveriş öncesinde <Link to="/guvenli-alisveris">Güvenli Alışveriş Rehberi</Link>’ni okumanızı öneririz.</p>
            <h2>8. Değişiklikler</h2>
            <p>Bu koşullar güncellenebilir. Önemli değişiklikler sitede duyurulur; siteyi kullanmaya devam etmeniz güncel koşulları kabul ettiğiniz anlamına gelir.</p>
          </>
        )}

        {doc === 'hesap' && (
          <>
            <p>PAZARLA hesabınızı ve hesabınıza bağlı verileri dilediğiniz zaman, uygulamanın ya da sitenin içinden kendiniz kalıcı olarak silebilirsiniz.</p>
            <h2>Hesabımı nasıl silerim?</h2>
            <ul>
              <li>PAZARLA uygulamasında ya da sitesinde hesabınıza giriş yapın.</li>
              <li><Link to="/hesabim/profil">Hesabım → Profil ve ayarlar</Link> sayfasını açın.</li>
              <li>Sayfanın altındaki <strong>Hesabımı sil</strong> düğmesine dokunun, onay kutusuna <strong>SİL</strong> yazın ve onaylayın.</li>
            </ul>
            <p>Silme işlemi anında gerçekleşir ve geri alınamaz.</p>
            <h2>Hangi veriler silinir?</h2>
            <ul>
              <li>Profiliniz: ad soyad, telefon numarası, şehir, tanıtım yazısı ve profil fotoğrafı.</li>
              <li>Giriş bilgileriniz: e-posta adresi ve şifre kaydı.</li>
              <li>Bütün ilanlarınız ve ilan fotoğraflarınız.</li>
              <li>Mesajlarınız ve sohbetleriniz, favorileriniz, bildirimleriniz ve yaptığınız şikâyetler.</li>
            </ul>
            <h2>Hangi veriler saklanır?</h2>
            <ul>
              <li>Ücretli bir hizmet satın aldıysanız, ödeme kayıtları (tutar, tarih, işlem numarası) vergi ve ticaret mevzuatındaki saklama süresi boyunca, adınız ve e-posta adresiniz olmadan saklanır ve süre sonunda silinir.</li>
              <li>Başka kullanıcıların sizin ilanlarınız hakkında yaptığı şikâyet kayıtları, kötüye kullanımın önlenmesi amacıyla ilan içeriği olmadan saklanabilir.</li>
            </ul>
            <h2>Giriş yapamıyorsanız</h2>
            <p>Şifrenizi <Link to="/sifremi-unuttum">Şifremi unuttum</Link> sayfasından yenileyip yukarıdaki adımları izleyebilirsiniz. Hesabınıza hiç ulaşamıyorsanız silme talebinizi, hesabınıza kayıtlı e-posta adresinden gönderin. {contact}</p>
            <p>Hesabınızı silmeden yalnızca bir ilanı kaldırmak isterseniz <Link to="/hesabim">İlanlarım</Link> sayfasındaki <strong>Sil</strong> düğmesini kullanabilirsiniz.</p>
          </>
        )}

        {doc === 'guvenlik' && (
          <>
            <p>PAZARLA alıcı ile satıcıyı buluşturur; ödeme ve teslimat taraflar arasında gerçekleşir. Aşağıdaki kurallar sizi en sık karşılaşılan dolandırıcılık yöntemlerinden korur.</p>
            <h2>Alıcıysanız</h2>
            <ul>
              <li><strong>Ürünü görmeden ödeme yapmayın.</strong> Kapora, ön ödeme, “kargo ücreti” veya “rezervasyon bedeli” isteyen satıcılardan uzak durun.</li>
              <li>Piyasa değerinin çok altındaki fiyatlara ve acele ettiren satıcılara şüpheyle yaklaşın.</li>
              <li>Gündüz, kalabalık ve güvenli bir yerde buluşun; mümkünse yanınızda biri olsun.</li>
              <li>Ürünü teslim alırken deneyin; elektronik ürünlerde seri/IMEI numarasını, araç ve emlakta resmî belgeleri kontrol edin.</li>
              <li>Araç ve taşınmaz alımlarında ödemeyi yalnızca noter veya tapu işlemi sırasında, resmî kanallardan yapın.</li>
            </ul>
            <h2>Satıcıysanız</h2>
            <ul>
              <li>Ödemeyi kesin olarak almadan ürünü teslim etmeyin; sahte dekont ve “yanlışlıkla fazla gönderdim, iade edin” taleplerine dikkat edin.</li>
              <li>Size gönderilen bağlantılara tıklayıp kart, internet bankacılığı veya SMS doğrulama kodu girmeyin.</li>
              <li>Kimlik fotoğrafınızı, kart bilgilerinizi veya doğrulama kodlarını kimseyle paylaşmayın.</li>
            </ul>
            <h2>PAZARLA sizden asla şunları istemez</h2>
            <ul>
              <li>Mesaj, telefon veya e-posta yoluyla şifrenizi, kart bilgilerinizi ya da SMS kodunuzu.</li>
              <li>Alıcı ya da satıcı adına “güvenli ödeme”, “emanet hesap” veya “kargo” ödemesi. PAZARLA’da böyle bir hizmet yoktur; bu adı kullanan bağlantılar sahtedir.</li>
            </ul>
            <h2>Şüpheli bir durumla karşılaşırsanız</h2>
            <ul>
              <li>İlan sayfasındaki <strong>Şikâyet et</strong> düğmesiyle ilanı bildirin; ekibimiz inceler ve gerekirse ilanı kaldırıp hesabı engeller.</li>
              <li>Yazışmayı platform içinde tutun; bu, inceleme sırasında sizi korur.</li>
              <li>Mağdur olduğunuzu düşünüyorsanız vakit kaybetmeden bankanızı arayın ve en yakın kolluk birimine veya Cumhuriyet Başsavcılığı’na başvurun.</li>
            </ul>
          </>
        )}
      </article>
    </div>
  );
}
