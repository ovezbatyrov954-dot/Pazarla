import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import {
  CalendarDays, Camera, ChevronLeft, ChevronRight, Eye, EyeOff, Flag, Hash, Heart, MapPin, MessageCircle, Pencil, Phone,
  Rocket, Share2, ShieldCheck, Star, Trash2, X, Zap,
} from 'lucide-react';
import { api, ApiError, errMsg } from '../lib/api';
import type { Card, ListingDetail, SellerPublic } from '../lib/types';
import { useApp } from '../contexts/AppContext';
import { useAuth } from '../contexts/AuthContext';
import ListingCard from '../components/ListingCard';
import AdSlot from '../components/AdSlot';
import ReportDialog from '../components/ReportDialog';
import { Avatar, Crumbs, ErrorBox, Modal, PageLoader, Spinner, useTitle } from '../components/ui';
import { FLAG_LABEL, formatFullDate, formatNumber, formatPrice, memberSince, STATUS } from '../lib/format';

interface Data { listing: ListingDetail; seller: SellerPublic | null; similar: Card[]; is_favorite: boolean; is_owner: boolean }

const QUICK = ['Merhaba, ilan hâlâ güncel mi?', 'Merhaba, son fiyatınız nedir?', 'Merhaba, ürünü ne zaman görebilirim?'];

function Gallery({ images, title }: { images: string[]; title: string }) {
  const [i, setI] = useState(0);
  const [full, setFull] = useState(false);
  const touch = useRef<number | null>(null);
  const n = images.length;
  const go = useCallback((d: number) => setI((x) => (x + d + n) % n), [n]);

  useEffect(() => {
    if (!full) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setFull(false);
      if (e.key === 'ArrowRight') go(1);
      if (e.key === 'ArrowLeft') go(-1);
    };
    document.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
  }, [full, go]);

  const swipe = {
    onTouchStart: (e: React.TouchEvent) => { touch.current = e.touches[0].clientX; },
    onTouchEnd: (e: React.TouchEvent) => {
      if (touch.current === null) return;
      const dx = e.changedTouches[0].clientX - touch.current;
      if (Math.abs(dx) > 45) go(dx < 0 ? 1 : -1);
      touch.current = null;
    },
  };

  if (!n) {
    return <div className="grid aspect-[4/3] place-items-center rounded-3xl bg-white text-brand-200"><Camera size={48} /></div>;
  }
  const arrow = 'absolute top-1/2 grid h-10 w-10 -translate-y-1/2 place-items-center rounded-full bg-white/90 text-ink shadow-md hover:bg-white';
  return (
    <div>
      <div className="relative overflow-hidden rounded-3xl bg-ink" {...swipe}>
        <button onClick={() => setFull(true)} className="block w-full cursor-zoom-in" aria-label="Fotoğrafı büyüt">
          <img src={images[i]} alt={`${title} — fotoğraf ${i + 1}`} className="aspect-[4/3] w-full object-contain" />
        </button>
        {n > 1 && (
          <>
            <button onClick={() => go(-1)} className={`${arrow} left-3`} aria-label="Önceki fotoğraf"><ChevronLeft size={20} /></button>
            <button onClick={() => go(1)} className={`${arrow} right-3`} aria-label="Sonraki fotoğraf"><ChevronRight size={20} /></button>
          </>
        )}
        <span className="chip absolute bottom-3 right-3 bg-ink/75 px-2.5 py-1 text-white backdrop-blur"><Camera size={12} /> {i + 1} / {n}</span>
      </div>
      {n > 1 && (
        <div className="no-scrollbar mt-2.5 flex gap-2 overflow-x-auto pb-1">
          {images.map((u, k) => (
            <button key={u} onClick={() => setI(k)} aria-label={`Fotoğraf ${k + 1}`} aria-current={k === i ? 'true' : undefined} className={`h-16 w-20 shrink-0 overflow-hidden rounded-xl border-2 transition-all sm:h-[72px] sm:w-24 ${k === i ? 'border-brand-600' : 'border-transparent opacity-70 hover:opacity-100'}`}>
              <img src={u.replace(/\.jpg$/, '_t.jpg')} alt="" loading="lazy" className="h-full w-full object-cover" />
            </button>
          ))}
        </div>
      )}
      {full && (
        <div className="fixed inset-0 z-[95] flex flex-col bg-brand-950/97" role="dialog" aria-modal="true" aria-label="Fotoğraf görüntüleyici" {...swipe}>
          <div className="flex items-center justify-between px-4 py-3 text-white">
            <span className="text-sm font-bold">{i + 1} / {n}</span>
            <button onClick={() => setFull(false)} aria-label="Kapat" className="grid h-10 w-10 place-items-center rounded-full bg-white/10 hover:bg-white/20"><X size={22} /></button>
          </div>
          <div className="relative flex min-h-0 flex-1 items-center justify-center px-2 pb-6">
            <img src={images[i]} alt={`${title} — fotoğraf ${i + 1}`} className="max-h-full max-w-full object-contain" />
            {n > 1 && (
              <>
                <button onClick={() => go(-1)} className={`${arrow} left-3`} aria-label="Önceki fotoğraf"><ChevronLeft size={20} /></button>
                <button onClick={() => go(1)} className={`${arrow} right-3`} aria-label="Sonraki fotoğraf"><ChevronRight size={20} /></button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default function ListingDetailPage() {
  const { id } = useParams();
  const nav = useNavigate();
  const loc = useLocation();
  const { catById, settings, toast } = useApp();
  const { user, favIds, toggleFavorite, profile } = useAuth();
  const [data, setData] = useState<Data | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<{ msg: string; notFound: boolean } | null>(null);
  const [phone, setPhone] = useState<{ phone: string; whatsapp: boolean } | null>(null);
  const [phoneBusy, setPhoneBusy] = useState(false);
  const [msgOpen, setMsgOpen] = useState(false);
  const [msg, setMsg] = useState(QUICK[0]);
  const [msgBusy, setMsgBusy] = useState(false);
  const [msgErr, setMsgErr] = useState<string | null>(null);
  const [reportOpen, setReportOpen] = useState(false);
  const [delOpen, setDelOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const uid = user?.id || null;

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const d = await api<Data>(`listings?id=${id}`);
      setData(d);
      setPhone(null);
      if (d.listing.status === 'active' && !d.is_owner && !sessionStorage.getItem(`pzv${d.listing.id}`)) {
        sessionStorage.setItem(`pzv${d.listing.id}`, '1');
        api('listings?action=view', { method: 'POST', body: { id: d.listing.id } }).catch(() => undefined);
      }
    } catch (e) {
      setError({ msg: errMsg(e), notFound: e instanceof ApiError && e.status === 404 });
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => { load(); }, [load, uid]);

  const l = data?.listing;
  useTitle(l ? l.title : 'İlan');

  const needLogin = () => {
    toast('Bu işlem için giriş yapmalısınız.', 'info');
    nav(`/giris?next=${encodeURIComponent(loc.pathname)}`);
  };

  const revealPhone = async () => {
    if (!user) return needLogin();
    if (!l) return;
    setPhoneBusy(true);
    try {
      setPhone(await api<{ phone: string; whatsapp: boolean }>(`listings?action=phone&id=${l.id}`));
    } catch (e) {
      toast(errMsg(e), 'error');
    } finally {
      setPhoneBusy(false);
    }
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!l) return;
    if (msg.trim().length < 2) return setMsgErr('Lütfen bir mesaj yazın.');
    setMsgBusy(true);
    setMsgErr(null);
    try {
      const r = await api<{ conversation_id: string }>('messages?action=start', { method: 'POST', body: { listing_id: l.id, body: msg.trim() } });
      setMsgOpen(false);
      toast('Mesajınız gönderildi.');
      nav(`/mesajlar/${r.conversation_id}`);
    } catch (err) {
      setMsgErr(errMsg(err));
    } finally {
      setMsgBusy(false);
    }
  };

  const share = async () => {
    if (!l) return;
    const url = window.location.href;
    if (navigator.share) {
      try { await navigator.share({ title: l.title, text: `${l.title} — ${formatPrice(l.price, l.currency)}`, url }); } catch { /* vazgeçildi */ }
      return;
    }
    try {
      await navigator.clipboard.writeText(url);
      toast('İlan bağlantısı kopyalandı.');
    } catch {
      toast('Bağlantı kopyalanamadı. Adres çubuğundan kopyalayabilirsiniz.', 'error');
    }
  };

  const toggleStatus = async () => {
    if (!l) return;
    setBusy(true);
    try {
      await api('listings?action=status', { method: 'PUT', body: { id: l.id, status: l.status === 'passive' ? 'active' : 'passive' } });
      toast(l.status === 'passive' ? 'İlan yeniden yayına alındı.' : 'İlan yayından kaldırıldı.');
      await load();
    } catch (e) {
      toast(errMsg(e), 'error');
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!l) return;
    setBusy(true);
    try {
      await api('listings', { method: 'DELETE', body: { id: l.id } });
      toast('İlan silindi.');
      nav('/hesabim');
    } catch (e) {
      toast(errMsg(e), 'error');
      setBusy(false);
    }
  };

  if (loading && !data) return <PageLoader label="İlan yükleniyor…" />;
  if (error || !data || !l) {
    return (
      <div className="wrap py-16">
        <ErrorBox message={error?.msg || 'İlan bulunamadı.'} onRetry={error?.notFound ? undefined : load} />
        <div className="mt-4 text-center"><Link to="/ilanlar" className="btn btn-primary">Diğer ilanlara göz at</Link></div>
      </div>
    );
  }

  const cat = catById(l.category_id);
  const sub = catById(l.subcategory_id);
  const seller = data.seller;
  const fav = favIds.has(l.id);
  const st = STATUS[l.status];
  const attrs = (cat?.filters || []).filter((d) => l.attributes[d.key] !== undefined && l.attributes[d.key] !== '');
  const place = [l.district_name, l.city_name].filter(Boolean).join(', ');
  const waText = encodeURIComponent(`Merhaba, PAZARLA'daki "${l.title}" ilanınız için yazıyorum: ${window.location.href}`);
  const digits = phone?.phone.replace(/\D/g, '') || '';

  const contact = (compact = false) =>
    data.is_owner ? null : (
      <div className={`flex ${compact ? 'gap-2' : 'flex-col gap-2.5'}`}>
        <button onClick={() => (user ? setMsgOpen(true) : needLogin())} disabled={l.status !== 'active' || !!profile?.is_blocked} className={`btn btn-primary ${compact ? 'flex-1' : 'btn-lg w-full'}`}>
          <MessageCircle size={19} /> Mesaj gönder
        </button>
        {seller?.has_phone &&
          (phone ? (
            <a href={`tel:${phone.phone}`} className={`btn btn-mint ${compact ? 'flex-1' : 'btn-lg w-full'}`}>
              <Phone size={19} /> {compact ? 'Ara' : phone.phone}
            </a>
          ) : (
            <button onClick={revealPhone} disabled={phoneBusy || l.status !== 'active'} className={`btn btn-outline ${compact ? 'flex-1' : 'btn-lg w-full'}`}>
              {phoneBusy ? <Spinner size={18} /> : <Phone size={19} />} {compact ? 'Telefon' : 'Telefonu göster'}
            </button>
          ))}
        {!compact && phone?.whatsapp && (
          <a href={`https://wa.me/${digits}?text=${waText}`} target="_blank" rel="noopener noreferrer" className="btn btn-outline w-full">
            WhatsApp ile yaz
          </a>
        )}
      </div>
    );

  return (
    <div className="wrap pt-4 sm:pt-6">
      <Crumbs items={[{ label: 'Ana sayfa', to: '/' }, ...(cat ? [{ label: cat.name, to: `/kategori/${cat.slug}` }] : []), ...(cat && sub ? [{ label: sub.name, to: `/kategori/${cat.slug}/${sub.slug}` }] : []), { label: `İlan #${l.id}` }]} />

      {(data.is_owner || l.status !== 'active') && (
        <section className="card mt-4 p-4 sm:p-5" aria-label="İlan yönetimi">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
            <span className={`chip px-3 py-1 text-[0.8rem] ${st.cls}`}>{st.label}</span>
            <p className="min-w-0 flex-1 text-sm font-medium text-ink-soft">{data.is_owner ? st.hint : 'Bu ilan şu anda yayında değil; yalnızca yönetici olarak görüntülüyorsunuz.'}</p>
          </div>
          {l.status === 'rejected' && l.reject_reason && <p className="mt-2 rounded-xl bg-coral-soft px-3 py-2 text-sm font-semibold text-coral-ink">Ret nedeni: {l.reject_reason}</p>}
          {l.flags && l.flags.length > 0 && (
            <p className="mt-2 flex flex-wrap items-center gap-1.5 text-xs font-semibold text-muted">Otomatik işaretler: {l.flags.map((f) => <span key={f} className="chip bg-sun-soft text-sun-ink">{FLAG_LABEL[f] || f}</span>)}</p>
          )}
          {data.is_owner && (
            <div className="mt-3 flex flex-wrap gap-2">
              {l.status === 'pending_payment' && <Link to={`/odeme/listing_fee/${l.id}`} className="btn btn-sun btn-sm">Ödemeyi tamamla</Link>}
              {!['under_review', 'suspended'].includes(l.status) && <Link to={`/ilan-duzenle/${l.id}`} className="btn btn-outline btn-sm"><Pencil size={15} /> Düzenle</Link>}
              {(l.status === 'active' || l.status === 'pending' || l.status === 'passive') && (
                <button onClick={toggleStatus} disabled={busy} className="btn btn-outline btn-sm">
                  {l.status === 'passive' ? <><Eye size={15} /> Yeniden yayına al</> : <><EyeOff size={15} /> Yayından kaldır</>}
                </button>
              )}
              {l.status === 'active' && settings?.featured_sales_enabled && <Link to={`/odeme/featured/${l.id}`} className="btn btn-outline btn-sm"><Rocket size={15} /> Öne çıkar ({formatPrice(settings.featured_fee)})</Link>}
              {l.status === 'active' && settings?.showcase_sales_enabled && <Link to={`/odeme/showcase/${l.id}`} className="btn btn-outline btn-sm"><Star size={15} /> Vitrine al ({formatPrice(settings.showcase_fee)})</Link>}
              <button onClick={() => setDelOpen(true)} className="btn btn-danger btn-sm"><Trash2 size={15} /> Sil</button>
            </div>
          )}
        </section>
      )}

      <div className="mt-4 grid gap-6 lg:grid-cols-[minmax(0,1fr)_368px]">
        <div className="min-w-0">
          <Gallery images={l.images} title={l.title} />

          <div className="mt-5 lg:hidden">
            <Summary l={l} place={place} />
          </div>

          {attrs.length > 0 && (
            <section className="card mt-5 p-5" aria-labelledby="attrs-h">
              <h2 id="attrs-h" className="text-lg font-bold text-ink">İlan özellikleri</h2>
              <dl className="mt-3 grid grid-cols-1 gap-x-8 sm:grid-cols-2">
                <div className="flex justify-between gap-4 border-b border-line py-2.5 text-sm"><dt className="text-muted">Durum</dt><dd className="font-bold text-ink">{l.condition === 'new' ? 'Sıfır' : 'İkinci el'}</dd></div>
                {attrs.map((d) => (
                  <div key={d.key} className="flex justify-between gap-4 border-b border-line py-2.5 text-sm">
                    <dt className="text-muted">{d.label}</dt>
                    <dd className="text-right font-bold text-ink">
                      {typeof l.attributes[d.key] === 'number' && d.key !== 'yil' ? formatNumber(l.attributes[d.key] as number) : String(l.attributes[d.key])}{d.unit ? ` ${d.unit}` : ''}
                    </dd>
                  </div>
                ))}
              </dl>
            </section>
          )}

          <section className="card mt-5 p-5" aria-labelledby="desc-h">
            <h2 id="desc-h" className="text-lg font-bold text-ink">Açıklama</h2>
            <p className="mt-3 whitespace-pre-line break-words text-[0.98rem] leading-relaxed text-ink-soft">{l.description}</p>
          </section>

          <AdSlot placement="detail" className="mt-5" />
        </div>

        <aside className="flex flex-col gap-4 lg:sticky lg:top-[7.5rem] lg:self-start">
          <div className="hidden lg:block"><Summary l={l} place={place} /></div>

          <div className="card p-5">
            {seller ? (
              <>
                <Link to={`/satici/${seller.id}`} className="group flex items-center gap-3">
                  <Avatar name={seller.full_name} url={seller.avatar_url} size={52} />
                  <div className="min-w-0">
                    <p className="truncate font-bold text-ink group-hover:text-brand-700">{seller.full_name}</p>
                    <p className="text-[0.8rem] text-muted">{memberSince(seller.created_at)} tarihinden beri üye</p>
                  </div>
                </Link>
                <Link to={`/satici/${seller.id}`} className="mt-3 block text-sm font-bold text-brand-700 hover:underline">
                  Satıcının tüm ilanları ({seller.active_count ?? 0}) →
                </Link>
              </>
            ) : (
              <p className="text-sm text-muted">Satıcı bilgisi bulunamadı.</p>
            )}
            <div className="mt-4 hidden md:block">{contact()}</div>
            {!data.is_owner && phone?.whatsapp && (
              <a href={`https://wa.me/${digits}?text=${waText}`} target="_blank" rel="noopener noreferrer" className="btn btn-outline mt-3 w-full md:hidden">WhatsApp ile yaz</a>
            )}
            {!data.is_owner && phone && <p className="mt-3 text-center text-sm font-bold text-ink md:hidden">{phone.phone}</p>}
          </div>

          <div className="flex gap-2">
            <button onClick={() => toggleFavorite(l.id)} aria-pressed={fav} className={`btn btn-sm flex-1 ${fav ? 'border-coral bg-coral-soft text-coral-ink' : 'btn-outline'}`}>
              <Heart size={16} fill={fav ? 'currentColor' : 'none'} /> {fav ? 'Favorilerde' : 'Favorile'}
            </button>
            <button onClick={share} className="btn btn-outline btn-sm flex-1"><Share2 size={16} /> Paylaş</button>
            {!data.is_owner && (
              <button onClick={() => (user ? setReportOpen(true) : needLogin())} className="btn btn-outline btn-sm flex-1"><Flag size={16} /> Şikâyet et</button>
            )}
          </div>

          <div className="rounded-2xl border border-sun/70 bg-sun-soft/70 p-4">
            <h2 className="flex items-center gap-2 text-sm font-extrabold text-sun-ink"><ShieldCheck size={17} /> Güvenlik uyarısı</h2>
            <ul className="mt-2 list-disc space-y-1 pl-4 text-[0.82rem] leading-snug text-ink-soft">
              <li>Ürünü görmeden kapora ya da ön ödeme göndermeyin.</li>
              <li>Kalabalık ve güvenli bir yerde buluşun.</li>
              <li>PAZARLA ödeme veya kargo aracılığı yapmaz; sizden ödeme istemez.</li>
            </ul>
            <Link to="/guvenli-alisveris" className="mt-2 inline-block text-[0.82rem] font-bold text-brand-700 hover:underline">Güvenli alışveriş rehberi →</Link>
          </div>
        </aside>
      </div>

      {data.similar.length > 0 && (
        <section className="mt-12" aria-labelledby="similar-h">
          <h2 id="similar-h" className="mb-4 text-2xl font-extrabold text-ink">Benzer ilanlar</h2>
          <div className="grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3 lg:grid-cols-4">
            {data.similar.map((it) => <ListingCard key={it.id} item={it} />)}
          </div>
        </section>
      )}

      {!data.is_owner && (
        <div className="pb-safe fixed inset-x-0 bottom-0 z-40 border-t border-line bg-white/97 backdrop-blur-md md:hidden">
          <div className="flex items-center gap-3 px-4 py-2.5">
            <div className="min-w-0 shrink">
              <p className="truncate font-display text-lg font-extrabold leading-tight text-brand-700">{formatPrice(l.price, l.currency)}</p>
            </div>
            <div className="min-w-0 flex-1">{contact(true)}</div>
          </div>
        </div>
      )}

      <Modal open={msgOpen} onClose={() => setMsgOpen(false)} title="Satıcıya mesaj gönder">
        <form onSubmit={sendMessage} noValidate>
          <div className="mb-3 flex flex-wrap gap-1.5">
            {QUICK.map((t) => (
              <button key={t} type="button" onClick={() => setMsg(t)} className={`chip border py-1.5 ${msg === t ? 'border-brand-500 bg-brand-50 text-brand-800' : 'border-line bg-white text-ink-soft hover:border-brand-300'}`}>{t}</button>
            ))}
          </div>
          <label className="label" htmlFor="msg-body">Mesajınız</label>
          <textarea id="msg-body" className="input" maxLength={2000} value={msg} onChange={(e) => setMsg(e.target.value)} autoFocus />
          {msgErr && <p role="alert" className="mt-2 text-sm font-semibold text-coral-ink">{msgErr}</p>}
          <p className="mt-2 text-[0.8rem] text-muted">Kişisel bilgilerinizi ve ödeme bilgilerinizi mesajla paylaşmayın.</p>
          <button className="btn btn-primary mt-4 w-full" disabled={msgBusy}>{msgBusy && <Spinner size={16} />} Gönder</button>
        </form>
      </Modal>

      <Modal open={delOpen} onClose={() => setDelOpen(false)} title="İlanı sil">
        <p className="text-sm leading-relaxed text-ink-soft">“{l.title}” ilanı ve fotoğrafları kalıcı olarak silinecek. Bu işlem geri alınamaz.</p>
        <div className="mt-5 flex justify-end gap-2">
          <button className="btn btn-ghost" onClick={() => setDelOpen(false)}>Vazgeç</button>
          <button className="btn btn-danger-solid" onClick={remove} disabled={busy}>{busy && <Spinner size={16} />} Evet, sil</button>
        </div>
      </Modal>

      <ReportDialog listingId={l.id} open={reportOpen} onClose={() => setReportOpen(false)} />
    </div>
  );
}

function Summary({ l, place }: { l: ListingDetail; place: string }) {
  return (
    <div className="card p-5">
      <div className="flex flex-wrap gap-1.5">
        {l.is_showcase && <span className="chip bg-ink text-sun"><Star size={11} fill="currentColor" /> Vitrin</span>}
        {l.is_featured && <span className="chip bg-sun text-ink"><Zap size={11} fill="currentColor" /> Öne çıkan</span>}
        <span className={`chip ${l.condition === 'new' ? 'bg-mint-soft text-mint-ink' : 'bg-surface text-ink-soft'}`}>{l.condition === 'new' ? 'Sıfır' : 'İkinci el'}</span>
      </div>
      <h1 className="mt-2.5 break-words text-[1.45rem] font-extrabold leading-tight text-ink sm:text-[1.65rem]">{l.title}</h1>
      <p className="mt-2 font-display text-[2rem] font-extrabold leading-none text-brand-700">{formatPrice(l.price, l.currency)}</p>
      <ul className="mt-4 grid grid-cols-2 gap-x-3 gap-y-2 text-[0.84rem] font-medium text-ink-soft">
        <li className="col-span-2 flex items-center gap-1.5"><MapPin size={15} className="shrink-0 text-brand-600" /> {place || 'Konum belirtilmemiş'}</li>
        <li className="flex items-center gap-1.5"><CalendarDays size={15} className="shrink-0 text-brand-600" /> {formatFullDate(l.date)}</li>
        <li className="flex items-center gap-1.5"><Eye size={15} className="shrink-0 text-brand-600" /> {formatNumber(l.view_count)} görüntülenme</li>
        <li className="flex items-center gap-1.5"><Hash size={15} className="shrink-0 text-brand-600" /> İlan no: {l.id}</li>
      </ul>
    </div>
  );
}
