import { useRef, useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { BadgeCheck, Camera, CreditCard, Download, Eye, EyeOff, Heart, LayoutList, PackageOpen, Pencil, Plus, Rocket, ShieldCheck, Star, Trash2, User as UserIcon } from 'lucide-react';
import supabase from '../lib/supabase';
import { api, errMsg } from '../lib/api';
import { useLoad } from '../lib/useLoad';
import type { Card, MyListing, PaymentRow, Quota } from '../lib/types';
import { useApp } from '../contexts/AppContext';
import { useAuth } from '../contexts/AuthContext';
import ListingCard, { CardGrid } from '../components/ListingCard';
import { useCities } from '../components/LocationSelect';
import { Avatar, EmptyState, ErrorBox, Field, Modal, PageLoader, Spinner, Toggle, useTitle } from '../components/ui';
import { PasswordInput, PasswordRules, trError } from './Auth';
import { prepareImage } from '../lib/image';
import { formatDate, formatDateTime, formatNumber, formatPrice, memberSince, passwordIssues, PAYMENT_TYPE, STATUS } from '../lib/format';

type Tab = 'ilanlar' | 'favoriler' | 'profil' | 'odemeler';

function MyListings() {
  const { settings, toast } = useApp();
  const { refresh } = useAuth();
  const { data, loading, error, reload } = useLoad<{ items: MyListing[]; quota: Quota }>('listings?action=mine');
  const [busyId, setBusyId] = useState<number | null>(null);
  const [del, setDel] = useState<MyListing | null>(null);

  const act = async (l: MyListing, fn: () => Promise<unknown>, ok: string) => {
    setBusyId(l.id);
    try {
      await fn();
      toast(ok);
      await reload();
      refresh();
    } catch (e) {
      toast(errMsg(e), 'error');
    } finally {
      setBusyId(null);
      setDel(null);
    }
  };

  if (loading && !data) return <PageLoader />;
  if (error || !data) return <ErrorBox message={error || 'İlanlar yüklenemedi.'} onRetry={reload} />;
  const q = data.quota;
  return (
    <div>
      <div className={`mb-5 flex flex-wrap items-center gap-3 rounded-2xl border p-4 ${q.next_requires_payment ? 'border-sun/70 bg-sun-soft/70' : 'border-[#b5ecd3] bg-mint-soft'}`}>
        {q.next_requires_payment ? <CreditCard size={20} className="shrink-0 text-sun-ink" /> : <BadgeCheck size={20} className="shrink-0 text-mint-ink" />}
        <p className="min-w-0 flex-1 text-sm font-semibold text-ink">
          {q.next_requires_payment
            ? `Ücretsiz ${q.free_total} ilan hakkınızı kullandınız. Sonraki ilanlar için ilan ücreti ${formatPrice(q.listing_fee)}.`
            : q.free_left > 0
              ? `Ücretsiz ilan hakkınız: ${q.free_left} / ${q.free_total}`
              : 'İlan vermek şu anda ücretsiz.'}
        </p>
        <Link to="/ilan-ver" className="btn btn-sun btn-sm"><Plus size={16} strokeWidth={2.8} /> Yeni ilan</Link>
      </div>

      {data.items.length === 0 ? (
        <EmptyState icon={<PackageOpen size={26} />} title="Henüz ilanınız yok" text="Kullanmadığınız eşyaları birkaç dakikada ilana çevirin." action={<Link to="/ilan-ver" className="btn btn-sun">İlk ilanını ver</Link>} />
      ) : (
        <ul className="flex flex-col gap-3">
          {data.items.map((l) => {
            const st = STATUS[l.status];
            const busy = busyId === l.id;
            return (
              <li key={l.id} className="card flex flex-col gap-3 p-3 sm:flex-row sm:items-center sm:p-4">
                <Link to={`/ilan/${l.id}`} className="flex min-w-0 flex-1 items-center gap-3">
                  <div className="h-20 w-24 shrink-0 overflow-hidden rounded-xl bg-surface">
                    {l.cover ? <img src={l.cover} alt="" loading="lazy" className="h-full w-full object-cover" /> : <div className="grid h-full place-items-center text-brand-200"><Camera size={22} /></div>}
                  </div>
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className={`chip ${st.cls}`}>{st.label}</span>
                      {l.is_showcase && <span className="chip bg-ink text-sun"><Star size={10} fill="currentColor" /> Vitrin</span>}
                      {l.is_featured && <span className="chip bg-sun text-ink">Öne çıkan</span>}
                    </div>
                    <p className="mt-1 line-clamp-1 font-bold text-ink">{l.title}</p>
                    <p className="font-display font-extrabold text-brand-700">{formatPrice(l.price, l.currency)}</p>
                    <p className="mt-0.5 flex flex-wrap gap-x-3 text-[0.78rem] font-medium text-muted">
                      <span>{formatDate(l.created_at)}</span>
                      <span className="flex items-center gap-1"><Eye size={12} /> {formatNumber(l.view_count)}</span>
                      <span>İlan no: {l.id}</span>
                    </p>
                    {l.status === 'rejected' && l.reject_reason && <p className="mt-1 text-[0.8rem] font-semibold text-coral-ink">Ret nedeni: {l.reject_reason}</p>}
                  </div>
                </Link>
                <div className="flex flex-wrap gap-1.5 sm:max-w-[250px] sm:justify-end">
                  {l.status === 'pending_payment' && <Link to={`/odeme/listing_fee/${l.id}`} className="btn btn-sun btn-sm">Ödemeyi tamamla</Link>}
                  {l.status === 'active' && settings?.featured_sales_enabled && <Link to={`/odeme/featured/${l.id}`} className="btn btn-outline btn-sm"><Rocket size={14} /> Öne çıkar</Link>}
                  {l.status === 'active' && settings?.showcase_sales_enabled && <Link to={`/odeme/showcase/${l.id}`} className="btn btn-outline btn-sm"><Star size={14} /> Vitrin</Link>}
                  {!['under_review', 'suspended'].includes(l.status) && <Link to={`/ilan-duzenle/${l.id}`} className="btn btn-outline btn-sm"><Pencil size={14} /> Düzenle</Link>}
                  {(l.status === 'active' || l.status === 'pending') && (
                    <button disabled={busy} className="btn btn-outline btn-sm" onClick={() => act(l, () => api('listings?action=status', { method: 'PUT', body: { id: l.id, status: 'passive' } }), 'İlan yayından kaldırıldı.')}>
                      <EyeOff size={14} /> Yayından kaldır
                    </button>
                  )}
                  {l.status === 'passive' && (
                    <button disabled={busy} className="btn btn-outline btn-sm" onClick={() => act(l, () => api('listings?action=status', { method: 'PUT', body: { id: l.id, status: 'active' } }), 'İlan yeniden yayına alındı.')}>
                      <Eye size={14} /> Yayına al
                    </button>
                  )}
                  <button disabled={busy} className="btn btn-danger btn-sm" onClick={() => setDel(l)} aria-label={`${l.title} ilanını sil`}><Trash2 size={14} /> Sil</button>
                </div>
              </li>
            );
          })}
        </ul>
      )}

      <Modal open={!!del} onClose={() => setDel(null)} title="İlanı sil">
        <p className="text-sm leading-relaxed text-ink-soft">“{del?.title}” ilanı ve fotoğrafları kalıcı olarak silinecek. Bu işlem geri alınamaz.</p>
        <div className="mt-5 flex justify-end gap-2">
          <button className="btn btn-ghost" onClick={() => setDel(null)}>Vazgeç</button>
          <button className="btn btn-danger-solid" disabled={busyId !== null} onClick={() => del && act(del, () => api('listings', { method: 'DELETE', body: { id: del.id } }), 'İlan silindi.')}>
            {busyId !== null && <Spinner size={16} />} Evet, sil
          </button>
        </div>
      </Modal>
    </div>
  );
}

function Favorites() {
  const { favIds } = useAuth();
  const { data, loading, error, reload } = useLoad<{ items: Card[] }>('user?action=favorites');
  if (loading && !data) return <PageLoader />;
  if (error || !data) return <ErrorBox message={error || 'Favoriler yüklenemedi.'} onRetry={reload} />;
  const items = data.items.filter((i) => favIds.has(i.id));
  if (!items.length) {
    return <EmptyState icon={<Heart size={26} />} title="Favori ilanınız yok" text="Beğendiğiniz ilanlardaki kalp simgesine dokunarak buraya ekleyebilirsiniz." action={<Link to="/ilanlar" className="btn btn-primary">İlanlara göz at</Link>} />;
  }
  return (
    <CardGrid>
      {items.map((it) => (
        <div key={it.id} className={it.status !== 'active' ? 'opacity-60' : ''}>
          <ListingCard item={it} />
          {it.status !== 'active' && <p className="mt-1 text-center text-xs font-bold text-muted">Yayında değil</p>}
        </div>
      ))}
    </CardGrid>
  );
}

function Payments() {
  const { settings } = useApp();
  const { data, loading, error, reload } = useLoad<{ items: PaymentRow[] }>('payments');
  if (loading && !data) return <PageLoader />;
  if (error || !data) return <ErrorBox message={error || 'Ödemeler yüklenemedi.'} onRetry={reload} />;
  const cls: Record<string, string> = { paid: 'bg-mint-soft text-mint-ink', pending: 'bg-sun-soft text-sun-ink', failed: 'bg-coral-soft text-coral-ink' };
  const lbl: Record<string, string> = { paid: 'Ödendi', pending: 'Bekliyor', failed: 'Başarısız' };
  return (
    <div>
      {!settings?.paytr_ready && (
        <p className="mb-4 rounded-2xl border border-line bg-white p-4 text-sm leading-relaxed text-muted">
          Online ödeme altyapısı henüz etkin değil. Şu anda tüm ilanlar ücretsizdir ve sizden herhangi bir ödeme alınmaz.
        </p>
      )}
      {data.items.length === 0 ? (
        <EmptyState icon={<CreditCard size={26} />} title="Ödeme kaydınız yok" text="İlan ücreti, öne çıkarma veya vitrin için yaptığınız ödemeler burada listelenir." />
      ) : (
        <ul className="flex flex-col gap-2.5">
          {data.items.map((p) => (
            <li key={p.id} className="card flex flex-wrap items-center justify-between gap-3 p-4">
              <div className="min-w-0">
                <p className="font-bold text-ink">{PAYMENT_TYPE[p.type] || p.type}{p.days ? ` · ${p.days} gün` : ''}</p>
                <p className="truncate text-sm text-muted">{p.listing_title || 'Silinmiş ilan'} · {formatDateTime(p.created_at)}</p>
                {p.status === 'failed' && p.failed_reason && <p className="text-[0.8rem] font-semibold text-coral-ink">{p.failed_reason}</p>}
                <p className="mt-0.5 font-mono text-[0.7rem] text-muted">{p.merchant_oid}</p>
              </div>
              <div className="flex items-center gap-3">
                {p.test_mode && <span className="chip bg-surface text-muted">Test</span>}
                <span className={`chip ${cls[p.status]}`}>{lbl[p.status]}</span>
                <span className="font-display text-lg font-extrabold text-ink">{formatPrice(p.amount)}</span>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function ProfileTab() {
  const { profile, user, refresh, signOut } = useAuth();
  const { toast, country } = useApp();
  const nav = useNavigate();
  const fileRef = useRef<HTMLInputElement>(null);
  const [name, setName] = useState(profile?.full_name || '');
  const [phone, setPhone] = useState(profile?.phone || '');
  const [showPhone, setShowPhone] = useState(profile?.show_phone ?? true);
  const [whatsapp, setWhatsapp] = useState(profile?.whatsapp ?? false);
  const [cityId, setCityId] = useState<number | null>(profile?.city_id ?? null);
  const [bio, setBio] = useState(profile?.bio || '');
  const [errors, setErrors] = useState<Record<string, string | null>>({});
  const [busy, setBusy] = useState(false);
  const [avatarBusy, setAvatarBusy] = useState(false);
  const [pw, setPw] = useState('');
  const [pw2, setPw2] = useState('');
  const [pwErr, setPwErr] = useState<string | null>(null);
  const [pwBusy, setPwBusy] = useState(false);
  const [delOpen, setDelOpen] = useState(false);
  const [confirm, setConfirm] = useState('');
  const [delErr, setDelErr] = useState<string | null>(null);
  const [delBusy, setDelBusy] = useState(false);
  const { cities } = useCities(profile?.country_code || country);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    const er: Record<string, string | null> = {};
    if (name.trim().length < 2) er.name = 'Adınızı ve soyadınızı girin.';
    const digits = phone.replace(/\D/g, '');
    if (phone.trim() && (digits.length < 10 || digits.length > 15)) er.phone = 'Geçerli bir telefon numarası girin (örn. 0532 123 45 67).';
    setErrors(er);
    if (Object.values(er).some(Boolean)) return;
    setBusy(true);
    try {
      await api('user?action=profile', { method: 'PUT', body: { full_name: name.trim(), phone: phone.trim(), show_phone: showPhone, whatsapp, city_id: cityId, bio } });
      await refresh();
      toast('Profiliniz güncellendi.');
    } catch (err) {
      toast(errMsg(err), 'error');
    } finally {
      setBusy(false);
    }
  };

  const onAvatar = async (file: File) => {
    setAvatarBusy(true);
    try {
      const p = await prepareImage(file, { maxSide: 480, square: true });
      await api('upload', { method: 'POST', body: { kind: 'avatar', main: p.main } });
      await refresh();
      toast('Profil fotoğrafınız güncellendi.');
    } catch (err) {
      toast(errMsg(err), 'error');
    } finally {
      setAvatarBusy(false);
    }
  };

  const changePw = async (e: React.FormEvent) => {
    e.preventDefault();
    const issues = passwordIssues(pw);
    if (issues.length) return setPwErr(`Şifrenizde şunlar eksik: ${issues.join(', ')}.`);
    if (pw !== pw2) return setPwErr('Şifreler birbiriyle aynı değil.');
    setPwBusy(true);
    setPwErr(null);
    const { error } = await supabase.auth.updateUser({ password: pw });
    setPwBusy(false);
    if (error) return setPwErr(trError(error.message));
    setPw('');
    setPw2('');
    toast('Şifreniz güncellendi.');
  };

  const remove = async (e: React.FormEvent) => {
    e.preventDefault();
    if (confirm.trim().toLocaleUpperCase('tr-TR') !== 'SİL') return setDelErr('Onaylamak için kutuya SİL yazın.');
    setDelBusy(true);
    setDelErr(null);
    try {
      await api('user?action=account', { method: 'DELETE', body: { confirm: 'SİL' } });
      await supabase.auth.signOut();
      toast('Hesabınız ve tüm verileriniz silindi.');
      nav('/', { replace: true });
    } catch (err) {
      setDelErr(errMsg(err));
      setDelBusy(false);
    }
  };

  return (
    <div className="grid gap-5 lg:grid-cols-[1.25fr_0.75fr]">
      <form onSubmit={save} noValidate className="card flex flex-col gap-4 p-5 sm:p-6">
        <h2 className="text-lg font-bold text-ink">Profil bilgileri</h2>
        <div className="flex items-center gap-4">
          <div className="relative">
            <Avatar name={profile?.full_name || user?.email} url={profile?.avatar_url} size={76} />
            {avatarBusy && <span className="absolute inset-0 grid place-items-center rounded-full bg-white/70"><Spinner className="text-brand-600" /></span>}
          </div>
          <div>
            <button type="button" className="btn btn-outline btn-sm" onClick={() => fileRef.current?.click()} disabled={avatarBusy}><Camera size={15} /> Fotoğrafı değiştir</button>
            <input ref={fileRef} type="file" accept="image/*" className="sr-only" aria-label="Profil fotoğrafı seç" onChange={(e) => { const f = e.target.files?.[0]; if (f) onAvatar(f); e.target.value = ''; }} />
            <p className="mt-1.5 text-[0.8rem] text-muted">Kare bir fotoğraf en iyi sonucu verir.</p>
          </div>
        </div>
        <Field label="Ad soyad" htmlFor="pr-name" error={errors.name} required>
          <input id="pr-name" className={`input ${errors.name ? 'input-error' : ''}`} value={name} onChange={(e) => setName(e.target.value)} maxLength={60} autoComplete="name" />
        </Field>
        <Field label="E-posta" htmlFor="pr-email" hint="E-posta adresiniz ilanlarda gösterilmez.">
          <input id="pr-email" className="input" value={user?.email || ''} disabled />
        </Field>
        <Field label="Telefon" htmlFor="pr-phone" error={errors.phone} hint="Alıcıların sizi arayabilmesi için ekleyin. Yalnızca giriş yapmış üyeler görebilir.">
          <input id="pr-phone" type="tel" inputMode="tel" className={`input ${errors.phone ? 'input-error' : ''}`} value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="05xx xxx xx xx" maxLength={20} autoComplete="tel" />
        </Field>
        <Toggle checked={showPhone} onChange={setShowPhone} label="Telefonumu ilanlarımda göster" description="Kapatırsanız alıcılar size yalnızca mesajla ulaşabilir." />
        <Toggle checked={whatsapp} onChange={setWhatsapp} disabled={!phone.trim() || !showPhone} label="WhatsApp ile yazılabilsin" description="İlanlarınızda “WhatsApp ile yaz” düğmesi gösterilir." />
        <Field label="Şehir" htmlFor="pr-city">
          <select id="pr-city" className="input" value={cityId ?? ''} onChange={(e) => setCityId(e.target.value ? Number(e.target.value) : null)}>
            <option value="">Belirtilmedi</option>
            {cities.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </Field>
        <Field label="Hakkımda" htmlFor="pr-bio" hint={`Satıcı profilinizde görünür. ${bio.length}/500`}>
          <textarea id="pr-bio" className="input !min-h-24" value={bio} onChange={(e) => setBio(e.target.value)} maxLength={500} />
        </Field>
        <div className="flex flex-wrap items-center justify-between gap-3">
          {profile && <Link to={`/satici/${profile.id}`} className="text-sm font-bold text-brand-700 hover:underline">Satıcı profilimi görüntüle →</Link>}
          <button className="btn btn-primary" disabled={busy}>{busy && <Spinner size={16} />} Değişiklikleri kaydet</button>
        </div>
      </form>

      <div className="flex flex-col gap-5">
        <form onSubmit={changePw} noValidate className="card flex flex-col gap-4 p-5 sm:p-6">
          <h2 className="text-lg font-bold text-ink">Şifre değiştir</h2>
          <div>
            <label className="label" htmlFor="pr-pw">Yeni şifre</label>
            <PasswordInput id="pr-pw" value={pw} onChange={setPw} autoComplete="new-password" />
            <PasswordRules pw={pw} />
          </div>
          <div>
            <label className="label" htmlFor="pr-pw2">Yeni şifre (tekrar)</label>
            <PasswordInput id="pr-pw2" value={pw2} onChange={setPw2} autoComplete="new-password" />
          </div>
          {pwErr && <p role="alert" className="text-sm font-semibold text-coral-ink">{pwErr}</p>}
          <button className="btn btn-outline" disabled={pwBusy || !pw}>{pwBusy && <Spinner size={16} />} Şifreyi güncelle</button>
        </form>

        <div className="card flex flex-col gap-3 p-5 sm:p-6">
          <h2 className="text-lg font-bold text-ink">Oturum</h2>
          <button className="btn btn-outline" onClick={signOut}>Çıkış yap</button>
        </div>

        <nav aria-label="Yasal bilgiler" className="card flex flex-col p-5 text-sm font-semibold sm:p-6">
          <h2 className="mb-2 text-lg font-bold text-ink">Yasal bilgiler</h2>
          <Link to="/gizlilik" className="border-b border-line py-2.5 text-brand-700 hover:underline">Gizlilik ve çerez politikası</Link>
          <Link to="/kvkk" className="border-b border-line py-2.5 text-brand-700 hover:underline">KVKK aydınlatma metni</Link>
          <Link to="/kullanim-kosullari" className="border-b border-line py-2.5 text-brand-700 hover:underline">Kullanım koşulları ve ilan kuralları</Link>
          <Link to="/guvenli-alisveris" className="border-b border-line py-2.5 text-brand-700 hover:underline">Güvenli alışveriş rehberi</Link>
          <Link to="/hesap-silme" className="py-2.5 text-brand-700 hover:underline">Hesap ve veri silme</Link>
        </nav>

        <div className="rounded-[1.15rem] border border-[#ffc9bd] bg-white p-5 sm:p-6">
          <h2 className="text-lg font-bold text-coral-ink">Hesabı sil</h2>
          <p className="mt-1.5 text-sm leading-relaxed text-muted">Hesabınız, ilanlarınız, fotoğraflarınız, favorileriniz ve mesajlarınız kalıcı olarak silinir. Bu işlem geri alınamaz.</p>
          <button className="btn btn-danger mt-3" onClick={() => { setDelOpen(true); setConfirm(''); setDelErr(null); }}><Trash2 size={16} /> Hesabımı sil</button>
        </div>
      </div>

      <Modal open={delOpen} onClose={() => setDelOpen(false)} title="Hesabı kalıcı olarak sil">
        <form onSubmit={remove} noValidate>
          <p className="text-sm leading-relaxed text-ink-soft">Tüm ilanlarınız, fotoğraflarınız, favorileriniz ve mesajlarınız silinecek. Yasal saklama yükümlülüğü bulunan ödeme kayıtları kimliğinizden arındırılarak saklanır.</p>
          <label className="label mt-4" htmlFor="del-confirm">Onaylamak için <strong className="text-coral-ink">SİL</strong> yazın</label>
          <input id="del-confirm" className={`input ${delErr ? 'input-error' : ''}`} value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="off" autoCapitalize="characters" />
          {delErr && <p role="alert" className="mt-2 text-sm font-semibold text-coral-ink">{delErr}</p>}
          <div className="mt-5 flex justify-end gap-2">
            <button type="button" className="btn btn-ghost" onClick={() => setDelOpen(false)}>Vazgeç</button>
            <button className="btn btn-danger-solid" disabled={delBusy}>{delBusy && <Spinner size={16} />} Hesabımı sil</button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

export default function Account({ tab }: { tab: Tab }) {
  const { profile, user } = useAuth();
  const titles: Record<Tab, string> = { ilanlar: 'İlanlarım', favoriler: 'Favorilerim', profil: 'Profil ve ayarlar', odemeler: 'Ödemelerim' };
  useTitle(titles[tab]);
  const link = ({ isActive }: { isActive: boolean }) =>
    `flex shrink-0 items-center gap-2 rounded-xl px-3.5 py-2.5 text-sm font-bold transition-colors ${isActive ? 'bg-brand-600 text-white' : 'text-ink-soft hover:bg-white hover:text-brand-700'}`;
  return (
    <div className="wrap pt-5 sm:pt-8">
      <div className="flex items-center gap-4">
        <Avatar name={profile?.full_name || user?.email} url={profile?.avatar_url} size={60} />
        <div className="min-w-0">
          <h1 className="truncate text-2xl font-extrabold text-ink sm:text-3xl">{profile?.full_name || 'Hesabım'}</h1>
          <p className="truncate text-sm text-muted">{user?.email}{profile ? ` · ${memberSince(profile.created_at)} tarihinden beri üye` : ''}</p>
        </div>
        {profile?.is_admin && <Link to="/yonetim" className="btn btn-outline btn-sm ml-auto !hidden sm:!inline-flex"><ShieldCheck size={15} /> Yönetim paneli</Link>}
      </div>
      {profile?.is_admin && (
        <Link to="/yonetim" className="mt-5 flex items-center gap-3 rounded-2xl bg-ink p-4 text-white sm:hidden">
          <ShieldCheck size={22} className="shrink-0 text-sun" />
          <span className="min-w-0 flex-1 text-sm font-bold">Yönetim paneli<span className="block text-[0.8rem] font-medium text-brand-100/85">İlan onayı, kullanıcılar, reklamlar, ayarlar</span></span>
          <span aria-hidden="true">→</span>
        </Link>
      )}
      {profile?.is_admin && (
        <Link to="/yonetim?sekme=play" className="mt-3 flex items-center gap-3 rounded-2xl border border-brand-200 bg-brand-50 p-4 text-ink sm:mt-5">
          <Download size={22} className="shrink-0 text-brand-700" />
          <span className="min-w-0 flex-1 text-sm font-bold">Google Play dosyaları<span className="block text-[0.8rem] font-medium text-muted">Uygulama paketi (AAB), mağaza görselleri, metinler ve rehber — indirmeye hazır</span></span>
          <span aria-hidden="true">→</span>
        </Link>
      )}
      {!profile?.is_admin && profile?.can_setup_admin && (
        <div className="mt-5 flex flex-wrap items-center gap-3 rounded-2xl border border-brand-200 bg-brand-50 p-4">
          <ShieldCheck size={22} className="shrink-0 text-brand-700" />
          <p className="min-w-[13rem] flex-1 text-sm font-semibold leading-relaxed text-ink">
            Site sahibi misiniz? Yönetim paneli henüz hiçbir hesaba tanımlanmadı. Kurulum kodunuzu girerek bu hesabı yönetici yapabilirsiniz.
          </p>
          <Link to="/yonetici-kurulum" className="btn btn-primary btn-sm">Yönetim panelini aç</Link>
        </div>
      )}
      <nav aria-label="Hesap bölümleri" className="no-scrollbar -mx-4 mt-5 flex gap-1 overflow-x-auto px-4 sm:mx-0 sm:rounded-2xl sm:bg-[#e9eef8] sm:p-1">
        <NavLink to="/hesabim" end className={link}><LayoutList size={16} /> İlanlarım</NavLink>
        <NavLink to="/hesabim/favoriler" className={link}><Heart size={16} /> Favorilerim</NavLink>
        <NavLink to="/hesabim/odemeler" className={link}><CreditCard size={16} /> Ödemelerim</NavLink>
        <NavLink to="/hesabim/profil" className={link}><UserIcon size={16} /> Profil ve ayarlar</NavLink>
        {profile?.is_admin && <NavLink to="/yonetim" className={`${link({ isActive: false })} sm:hidden`}><ShieldCheck size={16} /> Yönetim</NavLink>}
      </nav>
      <div className="mt-6">
        {tab === 'ilanlar' && <MyListings />}
        {tab === 'favoriler' && <Favorites />}
        {tab === 'odemeler' && <Payments />}
        {tab === 'profil' && <ProfileTab key={profile?.id || 'p'} />}
      </div>
    </div>
  );
}
