import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Camera, MessagesSquare, Send, ShieldCheck } from 'lucide-react';
import { api, errMsg } from '../lib/api';
import type { ChatMessage, ConversationItem } from '../lib/types';
import { useAuth } from '../contexts/AuthContext';
import { useApp } from '../contexts/AppContext';
import { Avatar, EmptyState, ErrorBox, PageLoader, Spinner, useTitle } from '../components/ui';
import { formatChatDay, formatDate, formatPrice, formatTime } from '../lib/format';

interface ThreadInfo {
  id: string;
  listing_id: number | null;
  listing_title: string | null;
  listing_image: string | null;
  listing_price: number | null;
  listing_currency: string | null;
  listing_active: boolean;
  other: { id: string; full_name: string; avatar_url: string | null; exists: boolean };
  role: 'buyer' | 'seller';
}

function Thread({ id, onActivity }: { id: string; onActivity: () => void }) {
  const { user, profile, refreshUnread } = useAuth();
  const { toast } = useApp();
  const nav = useNavigate();
  const [info, setInfo] = useState<ThreadInfo | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);
  const lastId = useRef(0);
  const stick = useRef(true);

  const merge = useCallback((incoming: ChatMessage[]) => {
    if (!incoming.length) return;
    setMessages((prev) => {
      const seen = new Set(prev.map((m) => m.id));
      const add = incoming.filter((m) => !seen.has(m.id));
      if (!add.length) return prev;
      const next = [...prev, ...add].sort((a, b) => a.id - b.id);
      lastId.current = next[next.length - 1].id;
      return next;
    });
  }, []);

  useEffect(() => {
    let on = true;
    setLoading(true);
    setError(null);
    setMessages([]);
    setInfo(null);
    lastId.current = 0;
    stick.current = true;
    api<{ conversation: ThreadInfo; messages: ChatMessage[] }>(`messages?action=thread&id=${id}`)
      .then((d) => {
        if (!on) return;
        setInfo(d.conversation);
        setMessages(d.messages);
        lastId.current = d.messages.length ? d.messages[d.messages.length - 1].id : 0;
        refreshUnread();
        onActivity();
      })
      .catch((e) => on && setError(errMsg(e)))
      .finally(() => on && setLoading(false));
    return () => { on = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const poll = useCallback(async () => {
    try {
      const d = await api<{ messages: ChatMessage[] }>(`messages?action=thread&id=${id}&after=${lastId.current}`);
      if (d.messages.length) {
        merge(d.messages);
        refreshUnread();
        onActivity();
      }
    } catch {
      /* bir sonraki denemede tekrar alınır */
    }
  }, [id, merge, refreshUnread, onActivity]);

  // Anlık sinyal geldiğinde hemen, ayrıca bağlantı kopmalarına karşı aralıklı olarak yeni mesajları al
  useEffect(() => {
    if (loading || error) return;
    const onSignal = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (!detail || detail.conversation_id === id) poll();
    };
    window.addEventListener('pz:msg', onSignal);
    const t = window.setInterval(() => { if (document.visibilityState === 'visible') poll(); }, 10000);
    return () => {
      window.removeEventListener('pz:msg', onSignal);
      window.clearInterval(t);
    };
  }, [id, loading, error, poll]);

  useLayoutEffect(() => {
    const el = scroller.current;
    if (el && stick.current) el.scrollTop = el.scrollHeight;
  }, [messages, loading]);

  const send = async (e?: React.FormEvent) => {
    e?.preventDefault();
    const body = text.trim();
    if (!body || sending) return;
    setSending(true);
    stick.current = true;
    try {
      const r = await api<{ message: ChatMessage }>('messages?action=send', { method: 'POST', body: { conversation_id: id, body } });
      setText('');
      merge([r.message]);
      onActivity();
    } catch (err) {
      toast(errMsg(err), 'error');
    } finally {
      setSending(false);
    }
  };

  if (loading) return <div className="grid flex-1 place-items-center"><Spinner size={28} className="text-brand-600" /></div>;
  if (error || !info) return <div className="grid flex-1 place-items-center p-6"><ErrorBox message={error || 'Sohbet yüklenemedi.'} /></div>;

  let lastDay = '';
  const canSend = info.other.exists && !profile?.is_blocked;
  return (
    <>
      <header className="flex items-center gap-3 border-b border-line bg-white px-3 py-2.5 sm:px-4">
        <button onClick={() => nav('/mesajlar')} aria-label="Sohbet listesine dön" className="grid h-10 w-10 shrink-0 place-items-center rounded-full text-ink hover:bg-surface md:hidden"><ArrowLeft size={21} /></button>
        <Avatar name={info.other.full_name} url={info.other.avatar_url} size={40} />
        <div className="min-w-0 flex-1">
          {info.other.exists ? (
            <Link to={`/satici/${info.other.id}`} className="block truncate font-bold text-ink hover:text-brand-700">{info.other.full_name}</Link>
          ) : (
            <p className="truncate font-bold text-muted">Silinmiş hesap</p>
          )}
          <p className="truncate text-xs text-muted">{info.role === 'buyer' ? 'Satıcı' : 'Alıcı'}</p>
        </div>
      </header>
      {info.listing_title && (
        <div className="flex items-center gap-3 border-b border-line bg-brand-50/60 px-3 py-2 sm:px-4">
          <div className="h-11 w-14 shrink-0 overflow-hidden rounded-lg bg-white">
            {info.listing_image ? <img src={info.listing_image} alt="" className="h-full w-full object-cover" /> : <div className="grid h-full place-items-center text-brand-200"><Camera size={16} /></div>}
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-bold text-ink">{info.listing_title}</p>
            <p className="text-xs font-semibold text-muted">
              {info.listing_price !== null ? formatPrice(info.listing_price, info.listing_currency || 'TRY') : ''}
              {!info.listing_active && <span className="text-coral-ink"> {info.listing_id ? '· Yayında değil' : '· İlan silinmiş'}</span>}
            </p>
          </div>
          {info.listing_id && info.listing_active && <Link to={`/ilan/${info.listing_id}`} className="btn btn-outline btn-sm shrink-0">İlana git</Link>}
        </div>
      )}
      <div
        ref={scroller}
        onScroll={(e) => { const el = e.currentTarget; stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80; }}
        className="flex-1 overflow-y-auto bg-surface px-3 py-4 sm:px-5"
        role="log"
        aria-live="polite"
        aria-label="Mesajlar"
      >
        <p className="mx-auto mb-4 flex max-w-sm items-start gap-2 rounded-xl bg-sun-soft px-3 py-2 text-[0.76rem] font-semibold leading-snug text-sun-ink">
          <ShieldCheck size={15} className="mt-0.5 shrink-0" /> Ürünü görmeden kapora göndermeyin; kart, IBAN ve kimlik bilgilerinizi paylaşmayın.
        </p>
        {messages.map((m) => {
          const mine = m.sender_id === user?.id;
          const day = formatChatDay(m.created_at);
          const showDay = day !== lastDay;
          lastDay = day;
          return (
            <div key={m.id}>
              {showDay && <p className="my-3 text-center text-[0.72rem] font-bold uppercase tracking-wider text-muted">{day}</p>}
              <div className={`mb-1.5 flex ${mine ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[82%] rounded-2xl px-3.5 py-2 text-[0.95rem] leading-snug shadow-sm sm:max-w-[70%] ${mine ? 'rounded-br-md bg-brand-600 text-white' : 'rounded-bl-md bg-white text-ink'}`}>
                  <p className="whitespace-pre-wrap break-words">{m.body}</p>
                  <p className={`mt-0.5 text-right text-[0.66rem] font-semibold ${mine ? 'text-brand-100' : 'text-muted'}`}>{formatTime(m.created_at)}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      <form onSubmit={send} className="pb-safe border-t border-line bg-white">
        {canSend ? (
          <div className="flex items-end gap-2 p-2.5 sm:p-3">
            <label htmlFor="chat-input" className="sr-only">Mesajınız</label>
            <textarea
              id="chat-input"
              rows={1}
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey && window.matchMedia('(min-width: 768px)').matches) { e.preventDefault(); send(); } }}
              placeholder="Mesaj yazın…"
              maxLength={2000}
              className="input !min-h-[2.9rem] max-h-32 flex-1 resize-none !rounded-2xl"
              style={{ fieldSizing: 'content' } as React.CSSProperties}
            />
            <button type="submit" disabled={!text.trim() || sending} aria-label="Gönder" className="grid h-[2.9rem] w-[2.9rem] shrink-0 place-items-center rounded-2xl bg-brand-600 text-white transition-colors hover:bg-brand-700 disabled:opacity-40">
              {sending ? <Spinner size={18} /> : <Send size={19} />}
            </button>
          </div>
        ) : (
          <p className="p-4 text-center text-sm font-semibold text-muted">{profile?.is_blocked ? 'Hesabınız engellendiği için mesaj gönderemezsiniz.' : 'Bu kullanıcının hesabı silindiği için mesaj gönderilemez.'}</p>
        )}
      </form>
    </>
  );
}

export default function Messages() {
  useTitle('Mesajlar');
  const { id } = useParams();
  const [list, setList] = useState<ConversationItem[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const loadList = useCallback(async () => {
    try {
      const d = await api<{ items: ConversationItem[] }>('messages?action=conversations');
      setList(d.items);
      setError(null);
    } catch (e) {
      setError(errMsg(e));
    }
  }, []);

  useEffect(() => {
    loadList();
    const on = () => loadList();
    window.addEventListener('pz:msg', on);
    const t = window.setInterval(() => { if (document.visibilityState === 'visible') loadList(); }, 30000);
    return () => {
      window.removeEventListener('pz:msg', on);
      window.clearInterval(t);
    };
  }, [loadList]);

  const listPane = (
    <div className="flex h-full flex-col">
      <h1 className="border-b border-line px-4 py-4 text-xl font-extrabold text-ink">Mesajlar</h1>
      {error && !list ? (
        <div className="p-4"><ErrorBox message={error} onRetry={loadList} /></div>
      ) : !list ? (
        <PageLoader />
      ) : list.length === 0 ? (
        <div className="p-4">
          <EmptyState icon={<MessagesSquare size={26} />} title="Henüz mesajınız yok" text="Bir ilandaki “Mesaj gönder” düğmesiyle satıcıyla yazışmaya başlayabilirsiniz." action={<Link to="/ilanlar" className="btn btn-primary">İlanlara göz at</Link>} />
        </div>
      ) : (
        <ul className="flex-1 overflow-y-auto">
          {list.map((c) => (
            <li key={c.id}>
              <Link to={`/mesajlar/${c.id}`} aria-current={c.id === id ? 'page' : undefined} className={`flex items-center gap-3 border-b border-line px-4 py-3 transition-colors ${c.id === id ? 'bg-brand-50' : 'hover:bg-surface'}`}>
                <div className="relative shrink-0">
                  <Avatar name={c.other.full_name} url={c.other.avatar_url} size={46} />
                  {c.listing_image && <img src={c.listing_image} alt="" className="absolute -bottom-1 -right-1 h-6 w-6 rounded-md border-2 border-white object-cover" />}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline justify-between gap-2">
                    <p className={`truncate text-[0.95rem] ${c.unread ? 'font-extrabold text-ink' : 'font-bold text-ink'}`}>{c.other.full_name}</p>
                    <time className="shrink-0 text-[0.7rem] font-semibold text-muted">{formatDate(c.last_message_at)}</time>
                  </div>
                  <p className="truncate text-xs font-semibold text-brand-700">{c.listing_title || 'Silinmiş ilan'}</p>
                  <div className="flex items-center justify-between gap-2">
                    <p className={`truncate text-[0.84rem] ${c.unread ? 'font-bold text-ink' : 'text-muted'}`}>{c.last_from_me ? 'Siz: ' : ''}{c.last_message}</p>
                    {c.unread > 0 && <span className="grid h-5 min-w-5 shrink-0 place-items-center rounded-full bg-coral px-1.5 text-[0.68rem] font-extrabold text-white">{c.unread}</span>}
                  </div>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );

  return (
    <div className="wrap md:py-6">
      <div className="md:card md:grid md:h-[calc(100dvh-12.5rem)] md:min-h-[480px] md:grid-cols-[340px_1fr] md:overflow-hidden">
        <div className={`-mx-4 bg-white sm:-mx-6 md:mx-0 md:block md:border-r md:border-line ${id ? 'hidden' : ''}`}>{listPane}</div>
        {id ? (
          <div className="fixed inset-0 z-[70] flex flex-col bg-white md:static md:z-auto">
            <Thread key={id} id={id} onActivity={loadList} />
          </div>
        ) : (
          <div className="hidden place-items-center bg-surface md:grid">
            <div className="text-center text-muted">
              <MessagesSquare size={40} className="mx-auto text-brand-300" />
              <p className="mt-3 font-semibold">Yazışmayı görmek için soldan bir sohbet seçin.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
