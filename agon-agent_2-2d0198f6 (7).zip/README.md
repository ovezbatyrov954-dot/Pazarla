# PAZARLA

Alım satım ilan pazaryeri. Arayüz: Vite + React + TypeScript + Tailwind. Sunucu: Vercel işlevleri (`api/` klasörü).
Veritabanı, üyelik, fotoğraf depolama ve anlık mesaj bildirimi: Supabase.

Bu klasör, siteyi **kendi GitHub, Vercel ve Supabase hesaplarınızda** yayınlamanız için hazırlanmıştır.
Kod yazmanız gerekmez; aşağıdaki adımlar bir bilgisayarda, tarayıcı üzerinden yapılır. Sıra önemlidir.

## 1. Supabase — veritabanını kurun

1. supabase.com → **New project**. Bir veritabanı şifresi belirleyin, bölge olarak size yakın olanı (ör. Frankfurt) seçin.
2. Sol menü → **SQL Editor** → **New query**. `supabase/1-tablolar.sql` dosyasının tamamını yapıştırın → **Run**. “Success” yazmalı.
3. Yeni bir sorgu açın, `supabase/2-veriler.sql` dosyasının tamamını yapıştırın → **Run**. (20 kategori ve alt kategorileri, 81 il ve ilçeleri yüklenir.)
4. **Project Settings → API** (ya da **API Keys**) sayfasından şu üç değeri bir kenara not edin:
   - **Project URL**
   - herkese açık anahtar: `anon` (ya da `publishable`)
   - gizli anahtar: `service_role` (ya da `secret`) — bunu kimseyle paylaşmayın.

Tablolar “dış erişime kapalı” kurulur: sitenin herkese açık anahtarı veritabanına doğrudan erişemez, bütün işlemler sunucudan geçer.

## 2. GitHub — kodu yükleyin

1. github.com → **New repository** → ad: `pazarla` → **Private** → **Create repository**.
2. Açılan sayfada **uploading an existing file** bağlantısına tıklayın.
3. Bu klasörün **içindeki her şeyi** (klasörün kendisini değil) tarayıcı penceresine sürükleyin → **Commit changes**.
   GitHub tek seferde en çok 100 dosya kabul eder; uyarı verirse önce `src` klasörünü, sonra kalanları yükleyin.

`node_modules` ve `dist` klasörleri yüklenmez (zaten bu pakette yoktur); Vercel bunları kendisi oluşturur.

## 3. Vercel — siteyi yayınlayın

1. vercel.com → **Add New → Project** → GitHub’daki `pazarla` deposunu seçin (**Import**). Framework olarak “Vite” algılanır; ayarlara dokunmayın.
2. **Environment Variables** bölümüne aşağıdakileri girin (liste `.env.example` dosyasında da var):

   | Ad | Değer |
   | --- | --- |
   | `NEXT_PUBLIC_SUPABASE_URL` | Supabase Project URL |
   | `VITE_SUPABASE_URL` | Supabase Project URL (aynısı) |
   | `NEXT_PUBLIC_SUPABASE_ANON_KEY` | herkese açık anahtar |
   | `VITE_SUPABASE_ANON_KEY` | herkese açık anahtar (aynısı) |
   | `SUPABASE_SERVICE_ROLE_KEY` | gizli anahtar |
   | `APP_ENCRYPTION_KEY` | kendi belirleyeceğiniz, en az 32 karakterlik rastgele bir metin |

   `APP_ENCRYPTION_KEY` değerini bir yere kaydedin ve **sonradan değiştirmeyin**: mesajlar ve telefon numaraları bununla şifrelenir.
3. **Deploy**. Birkaç dakika sonra siteniz `…vercel.app` adresinde açılır. Bundan sonra GitHub’daki her değişiklik siteyi kendiliğinden yeniden yayınlar.

## 4. Supabase — giriş ayarları

**Authentication → URL Configuration**:
- **Site URL**: sitenizin adresi (ör. `https://pazarla.vercel.app`)
- **Redirect URLs**: `https://SITE-ADRESINIZ/**` ekleyin (şifre sıfırlama bağlantıları için gerekli).

**Authentication → Sign In / Providers → Email**: Supabase varsayılan olarak yeni üyelere doğrulama e-postası gönderir ve
kendi deneme e-posta servisi saatte yalnızca birkaç e-posta yollar. Gerçek kullanıcı almadan önce
**Authentication → Emails → SMTP Settings** bölümüne kendi e-posta sağlayıcınızı ekleyin. Deneme aşamasında
“Confirm email” seçeneğini kapatabilirsiniz.

## 5. Yönetici hesabınızı tanımlayın

1. Yeni sitenizde e-postanızla **üye olun**.
2. Supabase → **Authentication → Users** → kendi satırınızdaki **User UID** değerini kopyalayın.
3. Vercel → Project → **Settings → Environment Variables** → `OWNER_USER_ID` adıyla bu değeri ekleyin.
4. Vercel → **Deployments** → en üstteki yayının yanındaki **⋯ → Redeploy**.

Artık “Yönetim paneli” yalnızca sizin hesabınızda görünür (Hesabım ekranı, sağ üst menü ve sayfanın en altı).
Başka hiçbir hesap yönetici olamaz. Panelde **Kurulum ve güvenlik** sekmesi veritabanı güvenliğini canlı denetler; iki satır da “engelli” olmalıdır.

`OWNER_USER_ID` tanımlanmazsa yönetici, giriş yaptıktan sonra `/yonetici-kurulum` sayfasında kurulum koduyla belirlenir.
Yönetici bildirimleri (yeni şikâyet, onay bekleyen ilan) yalnızca `OWNER_USER_ID` tanımlıyken gönderilir.

## 6. Sonraki adımlar (yönetim panelinden)

- **PayTR**: Kurulum ve güvenlik sekmesine mağaza bilgilerinizi girin; aynı sekmedeki Bildirim URL’sini PayTR paneline yapıştırın. İlk işlemi test modunda yapın.
- **Reklam**: Reklam sekmesinde kendi görsel reklamlarınızı ya da Google AdSense kodlarınızı ekleyin. `/ads.txt` kendiliğinden oluşur.
- **Alan adı**: Vercel → Settings → Domains. Alan adını değiştirince Supabase’deki Site URL / Redirect URLs değerlerini ve PayTR Bildirim URL’sini güncelleyin.
- **Hukuki metinler**: KVKK, gizlilik ve kullanım koşulları genel şablondur; Ayarlar sekmesinden işletme bilgilerinizi ekleyin ve metinleri bir hukukçuya inceletin.

## 7. Android uygulaması (Google Play)

`android/` klasörü, siteyi tam ekran açan Android uygulamasının (Trusted Web Activity) kaynağıdır; Google Play için **AAB** üretir.
Uygulama ayrı bir veritabanı kullanmaz, sitenizi ve onun veritabanını kullanır. Yayın adımları `android/GOOGLE-PLAY-REHBERI.md` dosyasındadır.

- Uygulamanın açacağı adres `android/gradle.properties` içindeki `twaHost` satırındadır. **Kendi site adresinizi yazıp paketi yeniden üretmeniz gerekir**; hazır verilen AAB önceki adresi açar.
- Paket aynı yükleme anahtarıyla (`pazarla-upload-key.jks`) imzalanmalıdır; anahtar bu depoda yoktur, Android paketiyle birlikte verilmiştir.
- Play Console’daki “Uygulama imzalama” SHA-256 parmak izini Yönetim paneli → Google Play sekmesine ekleyin. Site, `/.well-known/assetlinks.json` adresini buna göre kendiliğinden üretir.
- Farklı bir paket adı ya da anahtar kullanırsanız `api/_lib.js` içindeki `ANDROID_PACKAGE` ve `ANDROID_UPLOAD_FINGERPRINT` değerlerini güncelleyin.

## Bilmeniz gerekenler

- Yeni kurulum **boş** başlar; önceki sitedeki üyeler ve ilanlar taşınmaz.
- “Google ile devam et” düğmesi bu kurulumda görünmez; üyelik e-posta ve şifreyle yapılır.
- Vercel’in ücretsiz (Hobby) planı kullanım koşullarına göre ticari olmayan kullanım içindir; reklam ya da ücretli ilan geliri elde etmeye başladığınızda Pro plana geçmeniz gerekebilir. Supabase’in ücretsiz planı bir hafta hiç kullanılmayan projeleri duraklatır.
- Site telefonda “Ana ekrana ekle” ile uygulama gibi kurulabilir (PWA).

## Klasörler

- `src/` arayüz · `api/` sunucu işlevleri · `public/` simgeler, PWA dosyaları
- `supabase/1-tablolar.sql`, `supabase/2-veriler.sql` kurulum dosyaları · `supabase/enable-rls.sql` var olan bir veritabanını dış erişime kapatan onarım kodu
- Aynı kodlar Yönetim paneli → Kurulum ve güvenlik sekmesinde “kopyala” düğmeleriyle de verilir (`node scripts/make-setup-sql.mjs` ile yenilenir)
- `scripts/direct-access-check.mjs` ve `scripts/rls-check.mjs` veritabanının dışarıdan erişime kapalı olduğunu denetler (`.env` dosyası gerekir)
- `scripts/make-seed-sql.mjs` kategori/il listesini (`scripts/seed-data.mjs`) değiştirdikten sonra `2-veriler.sql` dosyasını yeniden üretir
