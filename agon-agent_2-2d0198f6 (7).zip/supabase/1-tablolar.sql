-- 1. ADIM: tablolar, depolama alanları ve güvenlik.
-- Bu kodda ad, e-posta, şifre, anahtar ya da hesap kimliği yoktur; kimseye giriş ya da erişim hakkı vermez.
-- Yeni (boş) bir Supabase projesinde SQL Editor'a yapıştırıp "Run" ile BİR KEZ çalıştırın.
-- Ardından 2-veriler.sql dosyasını çalıştırın. Bu dosya yeniden çalıştırılabilir; var olan veriyi silmez.
--
-- Güvenlik modeli: bütün tablolarda satır güvenliği (RLS) açıktır ve hiçbir erişim kuralı yoktur. Sitenin herkese
-- açık anahtarı tablolara doğrudan erişemez; bütün okuma/yazma işlemleri Vercel'deki sunucu (service role) üzerinden yapılır.

create table if not exists public.countries (
  code text primary key,
  name text not null,
  currency text not null,
  currency_symbol text,
  phone_prefix text,
  region_label text,
  district_label text,
  is_active boolean default true,
  sort_order integer default 0
);

create table if not exists public.categories (
  id integer primary key,
  parent_id integer,
  slug text not null,
  name text not null,
  icon text,
  color text,
  sort_order integer default 0,
  filters jsonb
);

create table if not exists public.cities (
  id integer primary key,
  country_code text not null references public.countries(code) on delete cascade,
  name text not null,
  sort_order integer default 0
);

create table if not exists public.districts (
  id integer primary key,
  city_id integer not null references public.cities(id) on delete cascade,
  name text not null
);

create table if not exists public.profiles (
  id uuid primary key,
  email text,
  full_name text,
  phone text,
  show_phone boolean default true,
  whatsapp boolean default false,
  avatar_url text,
  country_code text default 'TR',
  city_id integer,
  city_name text,
  bio text,
  is_admin boolean default false,
  is_blocked boolean default false,
  is_suspicious boolean default false,
  block_reason text,
  rt_key text,
  listings_created integer default 0,
  created_at timestamptz default now(),
  last_seen_at timestamptz
);

create table if not exists public.listings (
  id serial primary key,
  user_id uuid not null,
  title text not null,
  title_search text,
  description text,
  price numeric not null,
  currency text default 'TRY',
  category_id integer references public.categories(id) on delete restrict,
  subcategory_id integer references public.categories(id) on delete restrict,
  country_code text default 'TR',
  city_id integer,
  district_id integer,
  city_name text,
  district_name text,
  condition text,
  images jsonb default '[]'::jsonb,
  attributes jsonb default '{}'::jsonb,
  status text not null default 'pending',
  reject_reason text,
  flags jsonb default '[]'::jsonb,
  is_paid boolean default false,
  requires_payment boolean default false,
  view_count integer default 0,
  report_count integer default 0,
  featured_until timestamptz,
  showcase_until timestamptz,
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  published_at timestamptz
);

create table if not exists public.favorites (
  id serial primary key,
  user_id uuid not null,
  listing_id integer not null references public.listings(id) on delete cascade,
  created_at timestamptz default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  listing_id integer references public.listings(id) on delete set null,
  listing_title text,
  listing_image text,
  buyer_id uuid not null,
  seller_id uuid not null,
  last_message text,
  last_message_at timestamptz,
  last_sender_id uuid,
  buyer_unread integer default 0,
  seller_unread integer default 0,
  created_at timestamptz default now()
);

create table if not exists public.messages (
  id bigserial primary key,
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null,
  body text not null,
  created_at timestamptz default now()
);

create table if not exists public.reports (
  id serial primary key,
  listing_id integer references public.listings(id) on delete set null,
  listing_title text,
  seller_id uuid,
  reporter_id uuid not null,
  reason text not null,
  details text,
  status text default 'open',
  admin_note text,
  created_at timestamptz default now(),
  resolved_at timestamptz
);

create table if not exists public.payments (
  id serial primary key,
  merchant_oid text not null,
  user_id uuid not null,
  user_email text,
  listing_id integer references public.listings(id) on delete set null,
  listing_title text,
  type text not null,
  amount numeric not null,
  amount_kurus integer not null,
  currency text default 'TRY',
  days integer,
  status text not null default 'pending',
  provider text default 'paytr',
  failed_reason text,
  test_mode boolean default false,
  created_at timestamptz default now(),
  paid_at timestamptz
);

create table if not exists public.banners (
  id serial primary key,
  title text not null,
  subtitle text,
  image_url text,
  link_url text,
  cta_label text,
  is_active boolean default true,
  sort_order integer default 0,
  created_at timestamptz default now()
);

create table if not exists public.notifications (
  id bigserial primary key,
  user_id uuid not null,
  data text not null,
  is_read boolean default false,
  created_at timestamptz default now()
);

create table if not exists public.settings (
  key text primary key,
  value jsonb,
  updated_at timestamptz default now()
);

create table if not exists public.app_secrets (
  key text primary key,
  value text,
  updated_at timestamptz default now()
);

create table if not exists public.rate_limits (
  key text primary key,
  count integer default 0,
  reset_at timestamptz
);

-- Hız için dizinler
create index if not exists listings_status_published_idx on public.listings (status, published_at desc);
create index if not exists listings_user_idx on public.listings (user_id);
create index if not exists listings_category_idx on public.listings (category_id, subcategory_id);
create index if not exists listings_city_idx on public.listings (city_id);
create index if not exists cities_country_idx on public.cities (country_code);
create index if not exists districts_city_idx on public.districts (city_id);
create index if not exists favorites_user_idx on public.favorites (user_id);
create index if not exists conversations_buyer_idx on public.conversations (buyer_id);
create index if not exists conversations_seller_idx on public.conversations (seller_id);
create index if not exists messages_conversation_idx on public.messages (conversation_id, id);
create index if not exists reports_status_idx on public.reports (status);
create index if not exists payments_user_idx on public.payments (user_id);
create unique index if not exists payments_oid_idx on public.payments (merchant_oid);
create index if not exists notifications_user_idx on public.notifications (user_id, id desc);

-- Satır güvenliği: açık, kural yok → herkese açık anahtarla hiçbir tabloya erişilemez.
alter table public.countries enable row level security;
alter table public.categories enable row level security;
alter table public.cities enable row level security;
alter table public.districts enable row level security;
alter table public.profiles enable row level security;
alter table public.listings enable row level security;
alter table public.favorites enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.reports enable row level security;
alter table public.payments enable row level security;
alter table public.banners enable row level security;
alter table public.notifications enable row level security;
alter table public.settings enable row level security;
alter table public.app_secrets enable row level security;
alter table public.rate_limits enable row level security;

revoke all on table
  public.countries, public.categories, public.cities, public.districts, public.profiles, public.listings,
  public.favorites, public.conversations, public.messages, public.reports, public.payments, public.banners,
  public.notifications, public.settings, public.app_secrets, public.rate_limits
from anon, authenticated;

-- Sayaçlara (sequence) dış erişim de kapatılır; ileride eklenecek tablolar varsayılan olarak kapalı olur.
revoke all on all sequences in schema public from anon, authenticated;
do $$
begin
  execute 'alter default privileges in schema public revoke all on tables from anon, authenticated';
  execute 'alter default privileges in schema public revoke all on sequences from anon, authenticated';
exception when others then null;
end $$;

-- Fotoğraf depolama alanları: herkes görüntüleyebilir, yalnızca sunucu yükleyebilir (yalnızca JPEG).
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('listing-photos', 'listing-photos', true, 4194304, array['image/jpeg']),
  ('avatars', 'avatars', true, 2097152, array['image/jpeg']),
  ('banners', 'banners', true, 4194304, array['image/jpeg'])
on conflict (id) do nothing;
