-- Veritabanını dış erişime kapatan kod.
-- SQL düzenleyicisine yapıştırıp "Çalıştır" ile BİR KEZ çalıştırın.
--
-- Bu kod hiçbir şeyi silmez ve hiçbir veriyi değiştirmez. Her tabloya yalnızca tek bir kural EKLER:
-- "sitenin herkese açık anahtarıyla (giriş yapmış ya da yapmamış herkes) bu tabloya siteyi atlayarak erişilemez".
-- Kodda ad, e-posta, şifre, anahtar ya da hesap kimliği yoktur; kimseye giriş ya da erişim hakkı vermez.
-- Site etkilenmez: bütün işlemler sunucu üzerinden yapılır.
--
-- Çalışınca en alttaki satırda "TAMAM" yazmalıdır.
-- İkinci kez çalıştırılırsa "already exists" hatası verir: kural zaten eklenmiş demektir, zararsızdır.
-- "does not exist" hatası verirse yanlış veritabanı açılmıştır; hiçbir şey değişmez.

create policy dis_erisim_kapali on public.app_secrets as restrictive for all to anon, authenticated using (false) with check (false);
create policy dis_erisim_kapali on public.rate_limits as restrictive for all to anon, authenticated using (false) with check (false);
create policy dis_erisim_kapali on public.settings as restrictive for all to anon, authenticated using (false) with check (false);
create policy dis_erisim_kapali on public.profiles as restrictive for all to anon, authenticated using (false) with check (false);
create policy dis_erisim_kapali on public.listings as restrictive for all to anon, authenticated using (false) with check (false);
create policy dis_erisim_kapali on public.favorites as restrictive for all to anon, authenticated using (false) with check (false);
create policy dis_erisim_kapali on public.conversations as restrictive for all to anon, authenticated using (false) with check (false);
create policy dis_erisim_kapali on public.messages as restrictive for all to anon, authenticated using (false) with check (false);
create policy dis_erisim_kapali on public.reports as restrictive for all to anon, authenticated using (false) with check (false);
create policy dis_erisim_kapali on public.payments as restrictive for all to anon, authenticated using (false) with check (false);
create policy dis_erisim_kapali on public.banners as restrictive for all to anon, authenticated using (false) with check (false);
create policy dis_erisim_kapali on public.categories as restrictive for all to anon, authenticated using (false) with check (false);
create policy dis_erisim_kapali on public.countries as restrictive for all to anon, authenticated using (false) with check (false);
create policy dis_erisim_kapali on public.cities as restrictive for all to anon, authenticated using (false) with check (false);
create policy dis_erisim_kapali on public.districts as restrictive for all to anon, authenticated using (false) with check (false);
create policy dis_erisim_kapali on public.notifications as restrictive for all to anon, authenticated using (false) with check (false);

-- Sonuç
select case when count(*) filter (where acik) = 0
    then 'TAMAM: veritabanı dış erişime kapatıldı (' || count(*) || ' tablo). Yönetim panelinde "Yeniden denetle" düğmesine basın.'
    else 'DİKKAT: ' || count(*) filter (where acik) || ' tablo hâlâ dışarıdan erişilebilir: ' || string_agg(tablo, ', ') filter (where acik)
  end as sonuc
from (
  select c.relname as tablo,
    (not c.relrowsecurity or not exists (
      select 1 from pg_policies p
      where p.schemaname = 'public' and p.tablename = c.relname
        and p.policyname = 'dis_erisim_kapali' and p.permissive = 'RESTRICTIVE')) as acik
  from pg_class c join pg_namespace n on n.oid = c.relnamespace
  where n.nspname = 'public' and c.relkind = 'r'
) t;
