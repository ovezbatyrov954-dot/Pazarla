#!/usr/bin/env python3
"""Google Play teslim dosyalarını üretir:
  public/indir/pazarla-android-<rastgele>.zip          hepsi tek pakette
  public/indir/pazarla-android-<rastgele>/<dosya>      aynı dosyalar tek tek (telefondan indirmek için)
İçerik: imzalı .aab, yükleme anahtarı (.jks; şifresi dosyalara KONMAZ), mağaza görselleri, mağaza metinleri, rehber, Android proje kaynağı.
Kullanım: python3 scripts/make-android-zip.py"""
import json, os, re, secrets, shutil, zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
AND = os.path.join(ROOT, 'android')
KEYS = os.path.join(AND, 'keys')
STORE = os.path.join(KEYS, 'play-store')
LINK = os.path.join(ROOT, 'api', '_source-link.js')

props = dict(l.strip().split('=', 1) for l in open(os.path.join(AND, 'gradle.properties'), encoding='utf-8') if '=' in l and not l.startswith('#'))
version, code, host = props['appVersionName'], int(props['appVersionCode']), props['twaHost']
aab = f'pazarla-{version}.aab'
assert os.path.exists(os.path.join(KEYS, aab)), f'{aab} bulunamadı: önce uygulama paketini üretin'

current = open(LINK, encoding='utf-8').read() if os.path.exists(LINK) else ''
a = re.search(r"ANDROID_ZIP = '/indir/(pazarla-android-[0-9a-f]+)\.zip'", current)
s = re.search(r"SOURCE_ZIP = '([^']*)'", current)
token = a.group(1) if a else f'pazarla-android-{secrets.token_hex(16)}'
out_dir = os.path.join(ROOT, 'public', 'indir')
os.makedirs(out_dir, exist_ok=True)
for old in os.listdir(out_dir):
    if old.startswith('pazarla-android-'):
        path = os.path.join(out_dir, old)
        shutil.rmtree(path) if os.path.isdir(path) else os.remove(path)

# Tek tek indirilecek dosyalar: (tür, kaynak yol, dosya adı)
singles = [('aab', os.path.join(KEYS, aab), aab)]
for f in sorted(os.listdir(STORE)):
    kind = 'icon' if f.startswith('simge') else 'feature' if f.startswith('one-cikan') else 'shot'
    singles.append((kind, os.path.join(STORE, f), f))
singles += [('texts', os.path.join(AND, 'MAGAZA-METINLERI.txt'), 'MAGAZA-METINLERI.txt'),
            ('guide', os.path.join(AND, 'GOOGLE-PLAY-REHBERI.md'), 'GOOGLE-PLAY-REHBERI.md'),
            ('key', os.path.join(KEYS, 'pazarla-upload-key.jks'), 'pazarla-upload-key.jks')]

files_dir = os.path.join(out_dir, token)
os.makedirs(files_dir)
files = []
count = 0
with zipfile.ZipFile(os.path.join(out_dir, token + '.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for kind, src, name in singles:
        shutil.copyfile(src, os.path.join(files_dir, name))
        files.append({'kind': kind, 'name': name, 'url': f'/indir/{token}/{name}', 'size': os.path.getsize(src)})
        z.write(src, 'pazarla-android/' + ('play-store/' + name if kind in ('icon', 'feature', 'shot') else name))
        count += 1
    for base, dirs, fs in os.walk(AND):
        rel = os.path.relpath(base, AND)
        dirs[:] = sorted(d for d in dirs if not (rel == '.' and d in ('keys', '.gradle', 'build')) and not (rel == 'app' and d == 'build'))
        for f in sorted(fs):
            if f in ('local.properties', 'GOOGLE-PLAY-REHBERI.md', 'MAGAZA-METINLERI.txt'):
                continue
            z.write(os.path.join(base, f), 'pazarla-android/' + os.path.normpath(os.path.join('android-proje', rel, f)).replace(os.sep, '/'))
            count += 1
    assert not any('upload.properties' in n or 'fingerprint' in n for n in z.namelist())

pw = dict(l.strip().split('=', 1) for l in open(os.path.join(KEYS, 'upload.properties')) if '=' in l)['uploadStorePassword']
assert re.fullmatch(r'[A-Za-z0-9]{16,}', pw)
open(os.path.join(ROOT, 'api', '_android-key.js'), 'w', encoding='utf-8').write(
    "// Android yükleme anahtarının (.jks) şifresi. Yalnızca yöneticiye, sunucu üzerinden gösterilir; istemci koduna girmez.\n"
    f"export const ANDROID_KEY_PASSWORD = '{pw}';\n")

info = {'version': version, 'version_code': code, 'host': host}
open(LINK, 'w', encoding='utf-8').write(
    "// Yönetim panelindeki indirme bağlantıları. Yalnızca yöneticiye, sunucu üzerinden bildirilir.\n"
    f"export const ANDROID_ZIP = '/indir/{token}.zip';\n"
    f"export const ANDROID_INFO = {json.dumps(info)};\n"
    f"export const ANDROID_FILES = {json.dumps(files, ensure_ascii=False)};\n"
    f"export const SOURCE_ZIP = '{s.group(1) if s else ''}';\n")
print(f'{count} files in zip, {len(files)} single files -> public/indir/{token[:17]}… ({os.path.getsize(os.path.join(out_dir, token + ".zip")) // 1024} KB zip) | v{version} ({code}) -> {host}')
