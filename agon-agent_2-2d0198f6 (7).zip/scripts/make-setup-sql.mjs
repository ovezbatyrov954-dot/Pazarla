// api/_setup-sql.js dosyasını üretir: yönetim panelindeki "kodu kopyala" düğmelerinin verdiği SQL metinleri.
// Kaynak: supabase/enable-rls.sql, supabase/1-tablolar.sql, supabase/2-veriler.sql. Kullanım: node scripts/make-setup-sql.mjs
import fs from 'fs';

const read = (name) => fs.readFileSync(new URL(`../supabase/${name}`, import.meta.url), 'utf8').replace(/\r\n/g, '\n');
// Yapıştırılacak kodlarda uygulama adı, e-posta, hesap kimliği, proje adresi ya da anahtar bulunmamalıdır.
const FORBIDDEN = [/\bpazarla\b/i, /[\w.+-]+@[\w-]+\.[a-z]{2,}/i, /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i, /supabase\.co\b/i, /\bsb_(publishable|secret)_/i, /\beyJ[\w-]{10,}/, /service_role\s*key\s*[:=]/i, /password\s*[:=]/i];
for (const name of ['enable-rls.sql', '1-tablolar.sql', '2-veriler.sql']) {
  const hit = FORBIDDEN.find((re) => re.test(read(name)));
  if (hit) throw new Error(`${name}: kodda bulunmaması gereken bir ifade var (${hit})`);
}

// Güvenlik kodu yalnızca kural EKLER. SQL düzenleyicilerin "tehlikeli sorgu" saydığı sözcükler yorum satırlarında bile bulunmamalıdır.
const lockdown = read('enable-rls.sql');
const risky = lockdown.match(/drop|delet|truncat|alter|revok|grant|updat|insert|execut|merge|replace|renam|\bdo\b|\bset\b/i);
if (risky) throw new Error(`enable-rls.sql: "${risky[0]}" sözcüğü kullanılmamalı`);
// Sunucu, canlı veritabanındaki ek tablolar için satır eklerken bu işaret satırını kullanır; tek olmalıdır.
if (lockdown.split('\n\n-- Sonuç\n').length !== 2) throw new Error('enable-rls.sql: "-- Sonuç" işaret satırı tam bir kez bulunmalı');

const out = `// Bu dosya scripts/make-setup-sql.mjs ile üretilir; elle düzenlemeyin.
// Yönetim panelinde kopyalanıp Supabase SQL Editor'a yapıştırılan kodlar. Yalnızca yöneticiye, sunucu üzerinden verilir.
export const LOCKDOWN_SQL = ${JSON.stringify(read('enable-rls.sql'))};
export const TABLES_SQL = ${JSON.stringify(read('1-tablolar.sql'))};
export const SEED_SQL = ${JSON.stringify(read('2-veriler.sql'))};
`;
fs.writeFileSync(new URL('../api/_setup-sql.js', import.meta.url), out);
console.log(`api/_setup-sql.js written (${(out.length / 1024).toFixed(0)} KB)`);
