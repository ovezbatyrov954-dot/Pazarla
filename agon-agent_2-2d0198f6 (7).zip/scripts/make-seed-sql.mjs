// supabase/2-veriler.sql dosyasını üretir: kategoriler, ülkeler, 81 il + ilçeler, Çin bölgeleri.
// Kullanım: node scripts/make-seed-sql.mjs
import fs from 'fs';
import { categoryRows, COUNTRIES, CHINA } from './seed-data.mjs';

const q = (v) => (v === null || v === undefined ? 'null' : typeof v === 'number' || typeof v === 'boolean' ? String(v) : `'${String(v).replace(/'/g, "''")}'`);
const j = (v) => (v === null || v === undefined ? 'null' : `'${JSON.stringify(v).replace(/'/g, "''")}'::jsonb`);
const insert = (table, cols, rows, conflict, update) => {
  const out = [];
  for (let i = 0; i < rows.length; i += 200) {
    out.push(`insert into public.${table} (${cols.join(', ')}) values\n${rows.slice(i, i + 200).map((r) => `  (${r.join(', ')})`).join(',\n')}\non conflict (${conflict}) do update set ${update.map((c) => `${c} = excluded.${c}`).join(', ')};`);
  }
  return out.join('\n\n');
};

const tr = JSON.parse(fs.readFileSync(new URL('./tr-provinces.json', import.meta.url), 'utf8')).data;
const top = ['İstanbul', 'Ankara', 'İzmir'];
const sorted = [...tr].sort((a, b) => a.name.localeCompare(b.name, 'tr'));
const cities = tr.map((p) => ({ id: p.id, country_code: 'TR', name: p.name, sort_order: top.includes(p.name) ? top.indexOf(p.name) + 1 : 10 + sorted.findIndex((x) => x.id === p.id) }));
const districts = tr.flatMap((p) => p.districts.map((d) => ({ id: d.id, city_id: p.id, name: d.name })));
let cid = 1000;
let did = 100000;
for (const [name, list] of Object.entries(CHINA)) {
  cid += 1;
  cities.push({ id: cid, country_code: 'CN', name, sort_order: cid - 1000 });
  for (const d of list) districts.push({ id: ++did, city_id: cid, name: d });
}
const cats = categoryRows();

const sql = `-- 2. ADIM: başlangıç verileri (${cats.length} kategori, ${COUNTRIES.length} ülke, ${cities.length} il/bölge, ${districts.length} ilçe/şehir).
-- 1-tablolar.sql dosyasından SONRA, Supabase SQL Editor'a yapıştırıp "Run" ile çalıştırın.
-- Yeniden çalıştırılabilir: var olan kayıtları günceller; ilan ve kullanıcı verisine dokunmaz.
-- Bu dosya scripts/make-seed-sql.mjs ile üretilir; elle düzenlemeyin.

${insert('countries', ['code', 'name', 'currency', 'currency_symbol', 'phone_prefix', 'region_label', 'district_label', 'is_active', 'sort_order'],
    COUNTRIES.map((c) => [q(c.code), q(c.name), q(c.currency), q(c.currency_symbol), q(c.phone_prefix), q(c.region_label), q(c.district_label), q(c.is_active), q(c.sort_order)]), 'code',
    ['name', 'currency', 'currency_symbol', 'phone_prefix', 'region_label', 'district_label', 'sort_order'])}

${insert('categories', ['id', 'parent_id', 'slug', 'name', 'icon', 'color', 'sort_order', 'filters'],
    cats.map((c) => [q(c.id), q(c.parent_id), q(c.slug), q(c.name), q(c.icon), q(c.color), q(c.sort_order), j(c.filters)]), 'id',
    ['parent_id', 'slug', 'name', 'icon', 'color', 'sort_order', 'filters'])}

${insert('cities', ['id', 'country_code', 'name', 'sort_order'], cities.map((c) => [q(c.id), q(c.country_code), q(c.name), q(c.sort_order)]), 'id', ['country_code', 'name', 'sort_order'])}

${insert('districts', ['id', 'city_id', 'name'], districts.map((d) => [q(d.id), q(d.city_id), q(d.name)]), 'id', ['city_id', 'name'])}
`;
fs.writeFileSync(new URL('../supabase/2-veriler.sql', import.meta.url), sql);
console.log(`2-veriler.sql: ${cats.length} categories, ${COUNTRIES.length} countries, ${cities.length} cities, ${districts.length} districts, ${(sql.length / 1024).toFixed(0)} KB`);
