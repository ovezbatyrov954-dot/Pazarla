// Tek seferlik başvuru verisi yüklemesi. RLS politikaları eklenmeden ÖNCE çalıştırılır.
import { createClient } from '@supabase/supabase-js';
import fs from 'fs';
import { categoryRows, COUNTRIES, CHINA } from './seed-data.mjs';
const env = Object.fromEntries(fs.readFileSync('.env', 'utf8').split('\n').filter((l) => l.includes('=')).map((l) => [l.slice(0, l.indexOf('=')), l.slice(l.indexOf('=') + 1).replace(/^["']|["']$/g, '')]));
const db = createClient(env.VITE_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY || env.VITE_SUPABASE_ANON_KEY);
const put = async (table, rows, onConflict) => {
  for (let i = 0; i < rows.length; i += 400) {
    const { error } = await db.from(table).upsert(rows.slice(i, i + 400), { onConflict });
    if (error) throw new Error(`${table}: ${error.message}`);
  }
  console.log(table, rows.length);
};
const tr = JSON.parse(fs.readFileSync(new URL('./tr-provinces.json', import.meta.url), 'utf8')).data;
const top = ['İstanbul', 'Ankara', 'İzmir'];
const sorted = [...tr].sort((a, b) => a.name.localeCompare(b.name, 'tr'));
const cities = tr.map((p) => ({ id: p.id, country_code: 'TR', name: p.name, sort_order: top.includes(p.name) ? top.indexOf(p.name) + 1 : 10 + sorted.findIndex((x) => x.id === p.id) }));
const districts = tr.flatMap((p) => p.districts.map((d) => ({ id: d.id, city_id: p.id, name: d.name })));
let cid = 1000, did = 100000;
for (const [name, list] of Object.entries(CHINA)) {
  cid += 1;
  cities.push({ id: cid, country_code: 'CN', name, sort_order: cid - 1000 });
  for (const d of list) districts.push({ id: ++did, city_id: cid, name: d });
}
await db.from('rate_limits').delete().eq('key', 'anon-probe');
await put('countries', COUNTRIES, 'code');
await put('categories', categoryRows(), 'id');
await put('cities', cities, 'id');
await put('districts', districts, 'id');
// Ayarlar veritabanına yalnızca sunucu tarafından imzalanarak yazılır; varsayılanlar api/_lib.js içindedir.
