// Row Level Security denetimi (zararsız): anonim ve giriş yapmış istemcilerin veritabanına
// doğrudan yazamadığını ve özel tabloları okuyamadığını doğrular. Yalnızca "rlsprobe" işaretli satırlarla çalışır.
import { createClient } from '@supabase/supabase-js';
import fs from 'fs';
const env = Object.fromEntries(fs.readFileSync('.env', 'utf8').split('\n').filter((l) => l.includes('=')).map((l) => [l.slice(0, l.indexOf('=')), l.slice(l.indexOf('=') + 1).replace(/^["']|["']$/g, '')]));
const mk = () => createClient(env.VITE_SUPABASE_URL, env.VITE_SUPABASE_ANON_KEY, { auth: { persistSession: false } });
const uid = '00000000-0000-4000-8000-000000000001';
// [tablo, eklenecek satır, temizlik sütunu, temizlik değeri]
const INSERTS = [
  ['app_secrets', { key: 'rlsprobe', value: 'y' }, 'key', 'rlsprobe'],
  ['rate_limits', { key: 'rlsprobe', count: 1 }, 'key', 'rlsprobe'],
  ['settings', { key: 'rlsprobe', value: 1 }, 'key', 'rlsprobe'],
  ['profiles', { id: uid, email: 'rlsprobe', is_admin: true }, 'email', 'rlsprobe'],
  ['listings', { user_id: uid, title: 'rlsprobe', price: 1, status: 'pending' }, 'title', 'rlsprobe'],
  ['conversations', { buyer_id: uid, seller_id: uid, listing_title: 'rlsprobe' }, 'listing_title', 'rlsprobe'],
  ['reports', { reporter_id: uid, reason: 'rlsprobe' }, 'reason', 'rlsprobe'],
  ['payments', { merchant_oid: 'rlsprobe', user_id: uid, type: 'featured', amount: 1, amount_kurus: 100, status: 'failed' }, 'merchant_oid', 'rlsprobe'],
  ['banners', { title: 'rlsprobe', is_active: false }, 'title', 'rlsprobe'],
  ['categories', { id: 99999, slug: 'rlsprobe', name: 'rlsprobe', parent_id: 99998 }, 'slug', 'rlsprobe'],
  ['countries', { code: 'XX', name: 'rlsprobe', currency: 'X', is_active: false }, 'name', 'rlsprobe'],
  ['cities', { id: 99999, country_code: 'TR', name: 'rlsprobe' }, 'name', 'rlsprobe'],
  ['districts', { id: 9999999, city_id: 1, name: 'rlsprobe' }, 'name', 'rlsprobe'],
];
const PRIVATE = ['app_secrets', 'rate_limits', 'settings', 'profiles', 'favorites', 'conversations', 'messages', 'reports', 'payments'];
const OWN_OK = ['profiles', 'favorites', 'conversations', 'messages', 'reports', 'payments'];
let bad = 0;
const fail = (m) => { bad++; console.log('!!', m); };
async function run(label, db, ownId) {
  for (const [t, row, col, val] of INSERTS) {
    const r = await db.from(t).insert(ownId && 'user_id' in row ? { ...row, user_id: ownId } : row).select();
    if (!r.error) {
      fail(`${label}: INSERT allowed on ${t}`);
      const d = await db.from(t).delete().eq(col, val).select();
      if (d.data?.length) fail(`${label}: DELETE allowed on ${t}`);
    }
  }
  for (const t of PRIVATE) {
    const r = await db.from(t).select('*').limit(5);
    const n = r.data?.length || 0;
    if (n > 0 && !(ownId && OWN_OK.includes(t))) fail(`${label}: can READ ${t} (${n} rows)`);
  }
  const u1 = await db.from('categories').update({ sort_order: 1 }).eq('id', 1).select();
  if (u1.data?.length) fail(`${label}: UPDATE allowed on categories`);
  if (ownId) {
    const u2 = await db.from('profiles').update({ is_admin: false }).eq('id', ownId).select();
    if (u2.data?.length) fail(`${label}: direct UPDATE allowed on own profile (admin escalation possible)`);
  }
  const pub = await db.from('cities').select('id', { count: 'exact', head: true });
  const cat = await db.from('categories').select('id', { count: 'exact', head: true });
  console.log(`${label}: public read cities=${pub.count} categories=${cat.count}`);
}
await run('anon', mk());
if (process.env.PROBE_EMAIL) {
  const db = mk();
  const s = await db.auth.signInWithPassword({ email: process.env.PROBE_EMAIL, password: process.env.PROBE_PASS });
  if (s.error) console.log('signin failed', s.error.message); else await run('user', db, s.data.user.id);
}
console.log(bad ? `FAILED: ${bad} problem(s)` : 'RLS OK: no direct writes, no private reads');
process.exit(bad ? 1 : 0);
