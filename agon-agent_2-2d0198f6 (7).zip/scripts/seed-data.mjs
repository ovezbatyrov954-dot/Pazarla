// PAZARLA başvuru verileri: kategoriler, alt kategoriler, kategoriye özel filtreler ve Çin bölgeleri.
const sel = (key, label, options, only) => ({ key, label, type: 'select', options, ...(only ? { only } : {}) });
const num = (key, label, unit, min, max, only) => ({ key, label, type: 'number', ...(unit ? { unit } : {}), min, max, ...(only ? { only } : {}) });
const txt = (key, label, only) => ({ key, label, type: 'text', ...(only ? { only } : {}) });

const RENK = ['Beyaz', 'Siyah', 'Gri', 'Gümüş', 'Kırmızı', 'Mavi', 'Lacivert', 'Yeşil', 'Sarı', 'Turuncu', 'Kahverengi', 'Bej', 'Bordo', 'Mor', 'Pembe', 'Altın', 'Çok renkli', 'Diğer'];
const GARANTI = ['Garantili', 'Garantisi yok'];
const KIMDEN_ARAC = ['Sahibinden', 'Galeriden', 'Yetkili bayiden'];
const DEPOLAMA = ['16 GB', '32 GB', '64 GB', '128 GB', '256 GB', '512 GB', '1 TB', '2 TB ve üzeri'];
const RAM = ['2 GB', '3 GB', '4 GB', '6 GB', '8 GB', '12 GB', '16 GB', '32 GB', '64 GB ve üzeri'];
const VEH = [101, 102, 103, 104, 105, 106, 107, 109];
const MOTO = [201, 202, 203, 204];
const KONUT = [301, 302, 307];
const SHOE = [1001, 1002, 1003, 1004, 1005];
const BOOK = [1301, 1302, 1303, 1304, 1305, 1306, 1307];

export const CATEGORY_TREE = [
  [1, 'otomobil-arac', 'Otomobil ve Araçlar', 'Car', '#1447E6',
    ['Otomobil', 'Arazi, SUV ve Pickup', 'Minivan ve Panelvan', 'Ticari Araçlar', 'Kamyon ve Çekici', 'Otobüs ve Minibüs', 'Karavan', 'Deniz Araçları', 'Elektrikli Araçlar', 'Yedek Parça ve Aksesuar', 'Lastik ve Jant'],
    [sel('marka', 'Marka', ['Alfa Romeo', 'Audi', 'BMW', 'BYD', 'Chery', 'Chevrolet', 'Citroën', 'Cupra', 'Dacia', 'Fiat', 'Ford', 'Honda', 'Hyundai', 'Isuzu', 'Iveco', 'Jeep', 'Kia', 'Land Rover', 'MAN', 'Mazda', 'Mercedes-Benz', 'MG', 'Mini', 'Mitsubishi', 'Nissan', 'Opel', 'Peugeot', 'Porsche', 'Renault', 'Seat', 'Skoda', 'Subaru', 'Suzuki', 'Tesla', 'Tofaş', 'Togg', 'Toyota', 'Volkswagen', 'Volvo', 'Diğer'], VEH),
      num('yil', 'Model yılı', '', 1950, 2027, [...VEH, 108]), num('km', 'Kilometre', 'km', 0, 2000000, VEH),
      sel('yakit', 'Yakıt', ['Benzin', 'Dizel', 'LPG', 'Benzin + LPG', 'Hibrit', 'Elektrik'], VEH),
      sel('vites', 'Vites', ['Manuel', 'Otomatik', 'Yarı otomatik'], VEH),
      sel('kasa', 'Kasa tipi', ['Sedan', 'Hatchback', 'SUV', 'Station wagon', 'Coupe', 'Cabrio', 'MPV', 'Pickup'], [101, 102, 109]),
      sel('renk', 'Renk', RENK, VEH),
      sel('hasar', 'Hasar durumu', ['Hasar kaydı yok', 'Boyalı', 'Değişenli', 'Hasar kayıtlı'], VEH),
      sel('kimden', 'Kimden', KIMDEN_ARAC, [...VEH, 108])]],
  [2, 'motosiklet-bisiklet', 'Motosiklet ve Bisiklet', 'Bike', '#EA580C',
    ['Motosiklet', 'Scooter', 'ATV ve UTV', 'Elektrikli Motosiklet ve Scooter', 'Bisiklet', 'Elektrikli Bisiklet', 'Kask ve Sürüş Ekipmanı', 'Yedek Parça ve Aksesuar'],
    [sel('marka', 'Marka', ['Honda', 'Yamaha', 'Kawasaki', 'Suzuki', 'BMW', 'KTM', 'Ducati', 'Harley-Davidson', 'Triumph', 'Vespa', 'Piaggio', 'SYM', 'Kymco', 'Bajaj', 'TVS', 'CF Moto', 'Mondial', 'Kuba', 'RKS', 'Arora', 'Diğer'], MOTO),
      num('yil', 'Model yılı', '', 1950, 2027, MOTO), num('km', 'Kilometre', 'km', 0, 1000000, MOTO), num('motor_hacmi', 'Motor hacmi', 'cc', 0, 3000, MOTO),
      sel('bisiklet_tipi', 'Bisiklet tipi', ['Dağ', 'Yol', 'Şehir / Tur', 'Katlanır', 'BMX', 'Çocuk', 'Diğer'], [205, 206]),
      sel('jant', 'Jant', ['12"', '14"', '16"', '20"', '24"', '26"', '27.5"', '28"', '29"'], [205, 206])]],
  [3, 'emlak', 'Emlak, Ev ve Arsa', 'Building2', '#059669',
    ['Satılık Konut', 'Kiralık Konut', 'Satılık Arsa', 'Kiralık Arsa ve Tarla', 'Satılık İş Yeri', 'Kiralık İş Yeri', 'Günlük Kiralık', 'Devren Satılık ve Kiralık', 'Satılık Bina', 'Turistik Tesis'],
    [num('m2', 'Metrekare', 'm²', 1, 10000000),
      sel('oda', 'Oda sayısı', ['1+0', '1+1', '2+1', '3+1', '4+1', '5+1', '6+1 ve üzeri'], [...KONUT, 309]),
      sel('bina_yasi', 'Bina yaşı', ['0 (Yeni)', '1-5', '6-10', '11-20', '21 ve üzeri'], [301, 302, 305, 306, 307, 309]),
      sel('isitma', 'Isıtma', ['Doğalgaz (kombi)', 'Merkezi', 'Yerden ısıtma', 'Klima', 'Soba', 'Yok'], KONUT),
      sel('esyali', 'Eşyalı', ['Evet', 'Hayır'], KONUT),
      sel('imar', 'İmar durumu', ['Konut', 'Ticari', 'Tarla', 'Bağ - Bahçe', 'Sanayi', 'Turizm', 'Diğer'], [303, 304]),
      sel('tapu', 'Tapu durumu', ['Kat mülkiyeti', 'Kat irtifakı', 'Arsa tapulu', 'Hisseli tapu', 'Müstakil tapu'], [301, 303, 305, 309]),
      sel('kimden', 'Kimden', ['Sahibinden', 'Emlak ofisinden', 'İnşaat firmasından'])]],
  [4, 'telefon-tablet', 'Telefon ve Tablet', 'Smartphone', '#7C3AED',
    ['Cep Telefonu', 'Tablet', 'Akıllı Saat ve Bileklik', 'Kulaklık', 'Kılıf ve Aksesuar', 'Şarj Cihazı ve Powerbank', 'Yedek Parça', 'Sabit Telefon'],
    [sel('marka', 'Marka', ['Apple', 'Samsung', 'Xiaomi', 'Huawei', 'Oppo', 'Realme', 'Honor', 'Vivo', 'OnePlus', 'Google', 'Nokia', 'General Mobile', 'Reeder', 'Casper', 'Tecno', 'Infinix', 'Lenovo', 'Diğer']),
      sel('depolama', 'Dahili hafıza', DEPOLAMA, [401, 402]), sel('ram', 'RAM', RAM, [401, 402]), sel('renk', 'Renk', RENK), sel('garanti', 'Garanti', GARANTI)]],
  [5, 'bilgisayar-elektronik', 'Bilgisayar ve Elektronik', 'Laptop', '#0891B2',
    ['Dizüstü Bilgisayar', 'Masaüstü Bilgisayar', 'Bilgisayar Bileşenleri', 'Monitör', 'Yazıcı ve Tarayıcı', 'Televizyon', 'Ses ve Görüntü Sistemleri', 'Fotoğraf ve Kamera', 'Oyun Konsolu', 'Modem ve Ağ Ürünleri', 'Klavye, Mouse ve Çevre Birimleri', 'Drone'],
    [sel('marka', 'Marka', ['Apple', 'Asus', 'Acer', 'Dell', 'HP', 'Lenovo', 'MSI', 'Huawei', 'Samsung', 'LG', 'Sony', 'Philips', 'Toshiba', 'Monster', 'Casper', 'Canon', 'Nikon', 'Epson', 'Microsoft', 'Nintendo', 'Logitech', 'TP-Link', 'Vestel', 'Arçelik', 'DJI', 'Diğer']),
      sel('ram', 'RAM', RAM, [501, 502]), sel('depolama', 'Depolama', DEPOLAMA, [501, 502, 509]),
      num('ekran', 'Ekran boyutu', 'inç', 5, 120, [501, 504, 506]), sel('garanti', 'Garanti', GARANTI)]],
  [6, 'beyaz-esya', 'Beyaz Eşya', 'WashingMachine', '#0284C7',
    ['Buzdolabı', 'Çamaşır Makinesi', 'Bulaşık Makinesi', 'Kurutma Makinesi', 'Fırın ve Ocak', 'Derin Dondurucu', 'Klima', 'Kombi ve Isıtıcı', 'Mikrodalga Fırın', 'Aspiratör ve Davlumbaz', 'Su Sebili ve Arıtma'],
    [sel('marka', 'Marka', ['Arçelik', 'Beko', 'Bosch', 'Siemens', 'Vestel', 'Samsung', 'LG', 'Profilo', 'Altus', 'Regal', 'Grundig', 'Hotpoint', 'Electrolux', 'Miele', 'Daikin', 'Mitsubishi Electric', 'Baymak', 'Demirdöküm', 'Vaillant', 'Diğer']),
      sel('enerji', 'Enerji sınıfı', ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'A+', 'A++', 'A+++']), sel('garanti', 'Garanti', GARANTI)]],
  [7, 'mobilya-dekorasyon', 'Mobilya ve Ev Dekorasyonu', 'Sofa', '#B45309',
    ['Koltuk ve Kanepe', 'Yatak Odası', 'Yemek Odası', 'Genç ve Çocuk Odası', 'Ofis Mobilyası', 'TV Ünitesi', 'Masa ve Sandalye', 'Dolap ve Gardırop', 'Halı ve Kilim', 'Aydınlatma', 'Perde ve Ev Tekstili', 'Dekoratif Ürünler', 'Bahçe ve Balkon Mobilyası'],
    [sel('malzeme', 'Malzeme', ['Masif ahşap', 'MDF / Sunta', 'Metal', 'Cam', 'Plastik', 'Kumaş', 'Deri', 'Rattan / Hasır', 'Diğer']), sel('renk', 'Renk', RENK)]],
  [8, 'ev-mutfak', 'Ev ve Mutfak İhtiyaçları', 'CookingPot', '#DC2626',
    ['Küçük Ev Aletleri', 'Elektrikli Süpürge', 'Ütü', 'Tencere ve Tava', 'Sofra ve Servis', 'Mutfak Gereçleri', 'Banyo Ürünleri', 'Temizlik Gereçleri', 'Saklama ve Düzenleme', 'Nevresim ve Battaniye'],
    [txt('marka', 'Marka'), sel('garanti', 'Garanti', GARANTI, [801, 802, 803])]],
  [9, 'giyim', 'Giyim ve Kıyafet', 'Shirt', '#DB2777',
    ['Kadın Giyim', 'Erkek Giyim', 'Dış Giyim', 'Spor Giyim', 'Abiye ve Gelinlik', 'Takım Elbise', 'İç Giyim ve Pijama', 'Tesettür Giyim', 'Aksesuar', 'Saat ve Takı'],
    [sel('cinsiyet', 'Cinsiyet', ['Kadın', 'Erkek', 'Unisex']),
      sel('beden', 'Beden', ['XXS', 'XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL', '4XL', '34', '36', '38', '40', '42', '44', '46', '48', '50', 'Standart']),
      sel('renk', 'Renk', RENK), txt('marka', 'Marka')]],
  [10, 'ayakkabi-canta', 'Ayakkabı ve Çanta', 'ShoppingBag', '#C026D3',
    ['Kadın Ayakkabı', 'Erkek Ayakkabı', 'Spor Ayakkabı', 'Bot ve Çizme', 'Terlik ve Sandalet', 'Kadın Çanta', 'Erkek Çanta', 'Sırt Çantası', 'Valiz', 'Cüzdan'],
    [sel('cinsiyet', 'Cinsiyet', ['Kadın', 'Erkek', 'Unisex']),
      sel('numara', 'Numara', ['35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47'], SHOE),
      sel('renk', 'Renk', RENK), txt('marka', 'Marka')]],
  [11, 'bebek-cocuk', 'Bebek ve Çocuk Ürünleri', 'Baby', '#F59E0B',
    ['Bebek Arabası', 'Oto Koltuğu', 'Beşik ve Park Yatak', 'Mama Sandalyesi', 'Bebek Giyim', 'Çocuk Giyim', 'Çocuk Ayakkabı', 'Beslenme ve Emzirme', 'Bebek Bakım', 'Yürüteç ve Ana Kucağı', 'Çocuk Odası'],
    [sel('yas', 'Yaş grubu', ['0-6 ay', '6-12 ay', '1-3 yaş', '3-6 yaş', '6-9 yaş', '9-12 yaş', '12 yaş ve üzeri']),
      sel('cinsiyet', 'Cinsiyet', ['Kız', 'Erkek', 'Unisex']), txt('marka', 'Marka')]],
  [12, 'spor-outdoor', 'Spor ve Outdoor', 'Dumbbell', '#16A34A',
    ['Fitness ve Kondisyon', 'Kamp ve Doğa', 'Balıkçılık', 'Su Sporları', 'Kış Sporları', 'Futbol ve Takım Sporları', 'Tenis ve Raket Sporları', 'Koşu ve Yürüyüş', 'Yoga ve Pilates', 'Dağcılık ve Tırmanış', 'Kaykay, Paten ve Scooter'],
    [sel('cinsiyet', 'Kullanıcı', ['Kadın', 'Erkek', 'Unisex', 'Çocuk']), txt('marka', 'Marka')]],
  [13, 'kitap-kirtasiye', 'Kitap ve Kırtasiye', 'BookOpen', '#4F46E5',
    ['Roman ve Edebiyat', 'Sınav Hazırlık', 'Ders Kitapları', 'Çocuk Kitapları', 'Akademik ve Mesleki', 'Yabancı Dil', 'Dergi ve Çizgi Roman', 'Kırtasiye', 'Okul Çantası ve Malzemeleri', 'Ofis Malzemeleri'],
    [sel('dil', 'Dil', ['Türkçe', 'İngilizce', 'Almanca', 'Fransızca', 'Arapça', 'Rusça', 'Diğer'], BOOK), txt('yazar', 'Yazar', BOOK), txt('yayinevi', 'Yayınevi', BOOK)]],
  [14, 'hobi-oyuncak', 'Hobi ve Oyuncak', 'Puzzle', '#E11D48',
    ['Oyuncak', 'Kutu Oyunları ve Puzzle', 'Müzik Aletleri', 'Koleksiyon', 'Antika', 'El İşi ve Sanat Malzemeleri', 'Model ve Maket', 'Video Oyunları', 'Uzaktan Kumandalı Araçlar', 'Plak, Film ve Müzik'],
    [sel('yas_grubu', 'Yaş grubu', ['0-3 yaş', '3-6 yaş', '6-12 yaş', '12 yaş ve üzeri', 'Yetişkin'], [1401, 1402]),
      sel('platform', 'Platform', ['PlayStation 5', 'PlayStation 4', 'Xbox Series', 'Xbox One', 'Nintendo Switch', 'PC', 'Diğer'], [1408]), txt('marka', 'Marka')]],
  [15, 'bahce-yapi', 'Bahçe ve Yapı Malzemeleri', 'Hammer', '#65A30D',
    ['Bahçe Makineleri', 'Bitki, Tohum ve Fidan', 'El Aletleri', 'Elektrikli El Aletleri', 'İnşaat Malzemeleri', 'Boya ve Badana', 'Hırdavat', 'Elektrik ve Aydınlatma', 'Tesisat ve Banyo', 'Kapı ve Pencere', 'Isıtma ve Soğutma'],
    [txt('marka', 'Marka'), sel('garanti', 'Garanti', GARANTI, [1501, 1504])]],
  [16, 'yiyecek-icecek', 'Yiyecek ve İçecek', 'Apple', '#CA8A04',
    ['Yöresel Ürünler', 'Bal ve Reçel', 'Zeytin ve Zeytinyağı', 'Kuruyemiş ve Kuru Meyve', 'Süt Ürünleri ve Peynir', 'Bakliyat ve Tahıl', 'Baharat ve Sos', 'Çay ve Kahve', 'Ev Yapımı Ürünler', 'Organik Ürünler', 'Tatlı ve Şekerleme'],
    [sel('uretim', 'Üretim', ['Ev yapımı', 'Üreticiden', 'Markalı ürün']), sel('organik', 'Organik', ['Evet', 'Hayır'])]],
  [17, 'kozmetik-bakim', 'Kozmetik ve Kişisel Bakım', 'Sparkles', '#9333EA',
    ['Parfüm ve Deodorant', 'Makyaj', 'Cilt Bakımı', 'Saç Bakımı', 'Saç Şekillendirme Cihazları', 'Tıraş ve Epilasyon', 'Ağız ve Diş Bakımı', 'Kişisel Bakım Cihazları', 'Güneş Ürünleri'],
    [sel('cinsiyet', 'Cinsiyet', ['Kadın', 'Erkek', 'Unisex']), sel('ambalaj', 'Ambalaj', ['Açılmamış', 'Açılmış']), txt('marka', 'Marka')]],
  [18, 'hayvan-urunleri', 'Hayvan Ürünleri', 'PawPrint', '#0D9488',
    ['Kedi Ürünleri', 'Köpek Ürünleri', 'Kuş Ürünleri', 'Akvaryum ve Balık Ürünleri', 'Kemirgen ve Sürüngen Ürünleri', 'Mama ve Ödül', 'Kafes, Taşıma ve Yuva', 'Tasma ve Aksesuar', 'Çiftlik Hayvanı Ekipmanları'],
    [sel('hayvan', 'Hayvan türü', ['Kedi', 'Köpek', 'Kuş', 'Balık', 'Kemirgen', 'Sürüngen', 'Çiftlik hayvanı', 'Diğer']), txt('marka', 'Marka')]],
  [19, 'is-makineleri-sanayi', 'İş Makineleri ve Sanayi', 'Tractor', '#475569',
    ['İş Makineleri', 'Tarım Makineleri', 'Traktör', 'Forklift ve İstif Makineleri', 'Jeneratör', 'Kompresör', 'Kaynak Makineleri', 'Torna, Freze ve CNC', 'Gıda Makineleri', 'Tekstil Makineleri', 'Ambalaj Makineleri', 'Endüstriyel Mutfak', 'Sanayi Malzemeleri'],
    [txt('marka', 'Marka'), num('yil', 'Model yılı', '', 1950, 2027), num('calisma_saati', 'Çalışma saati', 'saat', 0, 200000)]],
  [20, 'diger', 'Diğer Ürünler', 'Package', '#64748B',
    ['Hediyelik Eşya', 'Parti ve Organizasyon', 'Medikal Ürünler', 'Toptan Ürünler', 'Takas', 'Diğer'],
    []],
];

export const slugify = (s) => s.replace(/İ/g, 'i').replace(/I/g, 'i').toLowerCase()
  .replace(/ç/g, 'c').replace(/ğ/g, 'g').replace(/ı/g, 'i').replace(/ö/g, 'o').replace(/ş/g, 's').replace(/ü/g, 'u')
  .replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

export function categoryRows() {
  const rows = [];
  for (const [id, slug, name, icon, color, subs, filters] of CATEGORY_TREE) {
    rows.push({ id, parent_id: null, slug, name, icon, color, sort_order: id, filters });
    subs.forEach((s, i) => rows.push({ id: id * 100 + i + 1, parent_id: id, slug: slugify(s), name: s, icon: null, color: null, sort_order: i + 1, filters: null }));
  }
  return rows;
}

export const COUNTRIES = [
  { code: 'TR', name: 'Türkiye', currency: 'TRY', currency_symbol: '₺', phone_prefix: '+90', region_label: 'İl', district_label: 'İlçe', is_active: true, sort_order: 1 },
  { code: 'CN', name: 'Çin', currency: 'CNY', currency_symbol: '¥', phone_prefix: '+86', region_label: 'Eyalet / Bölge', district_label: 'Şehir / Bölge', is_active: true, sort_order: 2 },
];

export const CHINA = {
  'Pekin': ['Chaoyang', 'Haidian', 'Dongcheng', 'Xicheng', 'Fengtai', 'Tongzhou', 'Daxing', 'Changping', 'Shunyi'],
  'Şanghay': ['Pudong', 'Huangpu', 'Xuhui', "Jing'an", 'Minhang', 'Baoshan', 'Jiading', 'Songjiang', 'Changning'],
  'Tianjin': ['Heping', 'Hexi', 'Nankai', 'Hedong', 'Binhai', 'Xiqing'],
  'Chongqing': ['Yuzhong', 'Jiangbei', "Nan'an", 'Shapingba', 'Yubei', 'Jiulongpo'],
  'Guangdong': ['Guangzhou', 'Shenzhen', 'Dongguan', 'Foshan', 'Zhuhai', 'Zhongshan', 'Huizhou', 'Shantou', 'Jiangmen'],
  'Zhejiang': ['Hangzhou', 'Ningbo', 'Wenzhou', 'Yiwu', 'Shaoxing', 'Jiaxing', 'Taizhou', 'Jinhua'],
  'Jiangsu': ['Nanjing', 'Suzhou', 'Wuxi', 'Changzhou', 'Nantong', 'Xuzhou', 'Yangzhou'],
  'Shandong': ['Jinan', 'Qingdao', 'Yantai', 'Weifang', 'Linyi', 'Zibo'],
  'Fujian': ['Fuzhou', 'Xiamen', 'Quanzhou', 'Zhangzhou', 'Putian'],
  'Sichuan': ['Chengdu', 'Mianyang', 'Deyang', 'Leshan', 'Yibin'],
  'Hubei': ['Wuhan', 'Yichang', 'Xiangyang', 'Jingzhou'],
  'Hunan': ['Changsha', 'Zhuzhou', 'Xiangtan', 'Hengyang'],
  'Henan': ['Zhengzhou', 'Luoyang', 'Kaifeng', 'Xinxiang'],
  'Hebei': ['Shijiazhuang', 'Tangshan', 'Baoding', 'Handan', 'Langfang'],
  'Anhui': ['Hefei', 'Wuhu', 'Bengbu', 'Anqing'],
  'Jiangxi': ['Nanchang', 'Ganzhou', 'Jiujiang', 'Jingdezhen'],
  'Liaoning': ['Shenyang', 'Dalian', 'Anshan', 'Jinzhou'],
  'Jilin': ['Changchun', 'Jilin', 'Siping'],
  'Heilongjiang': ['Harbin', 'Daqing', 'Qiqihar'],
  'Shaanxi': ["Xi'an", 'Baoji', 'Xianyang'],
  'Shanxi': ['Taiyuan', 'Datong', 'Changzhi'],
  'Yunnan': ['Kunming', 'Dali', 'Lijiang', 'Qujing'],
  'Guizhou': ['Guiyang', 'Zunyi'],
  'Guangxi': ['Nanning', 'Guilin', 'Liuzhou'],
  'Hainan': ['Haikou', 'Sanya'],
  'Gansu': ['Lanzhou', 'Tianshui'],
  'Qinghai': ['Xining', 'Haidong'],
  'İç Moğolistan': ['Hohhot', 'Baotou', 'Ordos'],
  'Ningxia': ['Yinchuan', 'Shizuishan'],
  'Sincan (Xinjiang)': ['Urumçi', 'Kaşgar', 'Turfan', 'Karamay'],
  'Tibet': ['Lhasa', 'Shigatse'],
  'Hong Kong': ['Hong Kong Adası', 'Kowloon', 'Yeni Bölgeler'],
  'Makao': ['Makao Yarımadası', 'Taipa', 'Coloane'],
};

export const SETTINGS = {
  free_listing_count: 3, paid_listings_enabled: false, listing_fee: 0,
  featured_sales_enabled: false, featured_fee: 0, featured_days: 7,
  showcase_sales_enabled: false, showcase_fee: 0, showcase_days: 7,
  moderation_enabled: false, max_photos: 12,
  ads: { enabled: false, client: '', slots: {} },
  company_name: '', company_address: '', contact_email: '', contact_phone: '',
};
