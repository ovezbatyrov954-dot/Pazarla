#!/usr/bin/env python3
"""Kaynak kod paketini (zip) üretir: public/indir/pazarla-kaynak-<rastgele>.zip
Pakete gizli bilgi (.env), bu platforma özgü ayarlar ve derleme çıktıları girmez. Kullanım: python3 scripts/make-zip.py"""
import json, os, re, secrets, zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LINK = os.path.join(ROOT, 'api', '_source-link.js')
SKIP_DIRS = {'node_modules', 'dist', '.git', '.agon-env', '.agon-writes', '.vercel', '_shots', 'uploads', os.path.join('public', 'indir'),
             os.path.join('android', 'keys'), os.path.join('android', '.gradle'), os.path.join('android', 'build'), os.path.join('android', 'app', 'build')}
SKIP_FILES = {'.env', '.vite-source-tags.js', os.path.join('scripts', 'make-zip.py'), os.path.join('scripts', 'make-android-zip.py'), os.path.join('android', 'local.properties'), os.path.join('scripts', 'seed.mjs')}
current = open(LINK, encoding='utf-8').read()
m = re.search(r"SOURCE_ZIP = '(/indir/[\w.-]+\.zip)'", current)

def blank(text):  # kaynak paketine giren kopyada indirme bağlantıları boş bırakılır
    text = re.sub(r"(ANDROID_ZIP|SOURCE_ZIP) = '[^']*'", r"\1 = ''", text)
    text = re.sub(r"ANDROID_INFO = .*;", "ANDROID_INFO = {};", text)
    return re.sub(r"ANDROID_FILES = .*;", "ANDROID_FILES = [];", text)

BLANK_LINK = blank(current)
assert '/indir/' not in BLANK_LINK
name = os.path.basename(m.group(1)) if m else f'pazarla-kaynak-{secrets.token_hex(16)}.zip'
out_dir = os.path.join(ROOT, 'public', 'indir')
os.makedirs(out_dir, exist_ok=True)
for old in os.listdir(out_dir):
    if old.startswith('pazarla-kaynak-'):
        os.remove(os.path.join(out_dir, old))

def transform(rel, data):
    if rel == 'vercel.json':  # platforma ait ortam değişkenleri pakete girmez
        d = json.loads(data)
        d.pop('env', None)
        return (json.dumps(d, indent=2, ensure_ascii=False) + '\n').encode()
    if rel == 'index.html':  # önizleme platformunun eklediği betikler (seçici, oturum kaydı) çıkarılır
        text = re.sub(r'\s*<script data-(?:element-picker|arena-[\w-]+)[^>]*>.*?</script>', '', data.decode('utf-8'), flags=re.S)
        assert text.count('<script') == 1, 'index.html içinde beklenmeyen betik var'
        return text.encode()
    if rel == os.path.join('api', '_source-link.js'):
        return BLANK_LINK.encode()
    if rel == os.path.join('api', '_lib.js'):  # ilk kurulumun sahibi pakete girmez; yönetici OWNER_USER_ID ile belirlenir
        text, n = re.subn(r"const FIRST_SITE_OWNER = [^\n]+;", "const FIRST_SITE_OWNER = '';", data.decode('utf-8'))
        assert n == 1
        return text.encode()
    if rel == os.path.join('api', '_android-key.js'):  # anahtar şifresi kaynak paketine girmez
        return b"// Android yukleme anahtarinin (.jks) sifresi. Yalnizca yoneticiye, sunucu uzerinden gosterilir.\nexport const ANDROID_KEY_PASSWORD = '';\n"
    if rel == 'package.json':
        d = json.loads(data)
        d['name'] = 'pazarla'
        return (json.dumps(d, indent=2, ensure_ascii=False) + '\n').encode()
    return data

count = 0
with zipfile.ZipFile(os.path.join(out_dir, name), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for base, dirs, files in os.walk(ROOT):
        rel_base = os.path.relpath(base, ROOT)
        dirs[:] = sorted(d for d in dirs if os.path.normpath(os.path.join(rel_base, d)) not in SKIP_DIRS)
        for f in sorted(files):
            rel = os.path.normpath(os.path.join(rel_base, f))
            if rel in SKIP_FILES or f.endswith('.zip') or f.startswith('_') and rel_base == '.':
                continue
            z.writestr(os.path.join('pazarla', rel).replace(os.sep, '/'), transform(rel, open(os.path.join(base, f), 'rb').read()))
            count += 1

open(LINK, 'w', encoding='utf-8').write(re.sub(r"SOURCE_ZIP = '[^']*'", f"SOURCE_ZIP = '/indir/{name}'", current))
print(f'{count} files -> public/indir/{name[:16]}….zip ({os.path.getsize(os.path.join(out_dir, name)) // 1024} KB)')
