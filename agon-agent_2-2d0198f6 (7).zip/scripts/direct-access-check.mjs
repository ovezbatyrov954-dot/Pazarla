// Herkese açık anahtarla (giriş yapmamış ve — verilirse — giriş yapmış üye olarak) veritabanına DOĞRUDAN erişim denemeleri.
// Hiçbir gerçek satıra dokunmaz: yazma denemeleri var olmayan kayıtları hedefler ya da "dogrudan-erisim-denemesi" işaretli satır ekler
// ve eklenebildiyse hemen geri siler. Kullanım: node scripts/direct-access-check.mjs [tablo ...]   (PROBE_EMAIL / PROBE_PASS isteğe bağlı)
import { createClient } from '@supabase/supabase-js';
import fs from 'fs';
const env = Object.fromEntries(fs.readFileSync('.env', 'utf8').split('\n').filter((l) => l.includes('=')).map((l) => [l.slice(0, l.indexOf('=')), l.slice(l.indexOf('=') + 1).replace(/^["']|["']$/g, '')]));
const mk = () => createClient(env.VITE_SUPABASE_URL, env.VITE_SUPABASE_ANON_KEY, { auth: { persistSession: false } });
const uid = '00000000-0000-4000-8000-000000000001';
const MARK = 'dogrudan-erisim-denemesi';
// tablo: [eklenecek deneme satırı, o satırı bulan filtre sütunu]
const TABLES = {
  app_secrets: [{ key: MARK, value: 'x' }, 'key'], rate_limits: [{ key: MARK, count: 0 }, 'key'], settings: [{ key: MARK, value: 1 }, 'key'],
  profiles: [{ id: uid, full_name: MARK }, 'full_name'], listings: [{ user_id: uid, title: MARK, price: 1, status: 'rejected' }, 'title'],
  favorites: [null, null], conversations: [{ buyer_id: uid, seller_id: uid, listing_title: MARK }, 'listing_title'], messages: [null, null],
  reports: [{ reporter_id: uid, reason: MARK, status: 'dismissed' }, 'reason'], payments: [{ merchant_oid: MARK, user_id: uid, type: 'featured', amount: 1, amount_kurus: 100, status: 'failed' }, 'merchant_oid'],
  banners: [{ title: MARK, is_active: false }, 'title'], categories: [{ id: 99999, slug: MARK, name: MARK, parent_id: 99998 }, 'slug'], countries: [{ code: 'XX', name: MARK, currency: 'X', is_active: false }, 'name'],
  cities: [{ id: 99999, country_code: 'TR', name: MARK }, 'name'], districts: [{ id: 9999999, city_id: 1, name: MARK }, 'name'], notifications: [{ user_id: uid, data: MARK }, 'data'],
  pz_diag: [{ who: MARK }, 'who'],
};
const only = process.argv.slice(2);
const names = only.length ? only : Object.keys(TABLES).filter((t) => t !== 'pz_diag');
let open = 0;
async function run(label, db) {
  const bad = [];
  for (const t of names) {
    const [row, col] = TABLES[t];
    const r = await db.from(t).select('*').limit(1);
    if (!r.error) bad.push(`${t}: READ (${r.data.length} row)`);
    if (row) {
      const i = await db.from(t).insert(row).select();
      if (!i.error) { bad.push(`${t}: INSERT`); await db.from(t).delete().eq(col, MARK); }
      const i2 = await db.from(t).insert(row);                       // geri okuma olmadan ekleme
      if (!i2.error) { bad.push(`${t}: INSERT (no return)`); await db.from(t).delete().eq(col, MARK); }
      const u = await db.from(t).update({ [col]: MARK }).eq(col, `${MARK}-yok`).select();   // hiçbir satırla eşleşmez
      if (!u.error) bad.push(`${t}: UPDATE accepted`);
      const d = await db.from(t).delete().eq(col, `${MARK}-yok`).select();                  // hiçbir satırla eşleşmez
      if (!d.error) bad.push(`${t}: DELETE accepted`);
    }
  }
  open += bad.length;
  console.log(`${label}: ${names.length} tables tried, ${bad.length} direct operation(s) still possible${bad.length ? '\n   ' + bad.slice(0, 60).join('\n   ') : ''}`);
}
await run('not logged in  ', mk());
if (process.env.PROBE_EMAIL) {
  const db = mk();
  const s = await db.auth.signInWithPassword({ email: process.env.PROBE_EMAIL, password: process.env.PROBE_PASS });
  if (s.error) console.log('sign-in failed:', s.error.message); else await run('logged-in member', db);
}
console.log(open ? `OPEN: ${open} direct operation(s) possible` : 'CLOSED: every direct read and write was refused');
process.exit(open ? 1 : 0);
